# 🔬 REPORTE QA — BOOTCAMP SEMANA 12

> Documento interno de auditoría. No es material de estudio.

---

```
ACTA DE GENERACIÓN
Fecha de generación: julio 2026
Semana en curso de Óscar al generar: 04 (PS-1 en curso)
Distancia estimada hasta el uso: ~7 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 7, 8
Versión de referencia: Next.js 16.2.x
Bloque perecedero: ALTO RIESGO — ver advertencia final
Constitución aplicada: v1.3 (enmiendas 1-10)
```

---

## FASE 0 — DELIMITACIÓN CURRICULAR

### Dentro del alcance

```
- App Router: convenciones de archivo (page, layout, loading, error, not-found)
- Layouts anidados y persistencia entre navegaciones
- Server Components por defecto y Client Components con "use client"
- La frontera: qué la cruza, en qué dirección, y por qué va abajo
- Obtención de datos en Server Components con async/await
- Rutas dinámicas [id] y params/searchParams como Promises
- notFound(), redirect()
- Navegación con Link y useRouter de next/navigation
- Metadatos estáticos y generateMetadata
- Server Actions con "use server" y revalidatePath
```

### Fuera del alcance, con razón documentada

| Excluido | Razón |
|---|---|
| Base de datos, Prisma, PostgreSQL | Los datos siguen en archivos. Es un mes propio del roadmap. |
| Autenticación | Mes propio. |
| Route handlers (`route.ts`) | Se mencionan como alternativa a Server Actions, no se enseñan. Sin necesidad real (no hay cliente externo) el concepto queda abstracto. |
| `proxy.ts` (ex middleware) | Requiere casos de auth o i18n que aún no existen. |
| Rutas paralelas e interceptoras | Resuelven problemas de UI avanzada que el proyecto no tiene. |
| `generateStaticParams`, ISR, PPR | Optimización de despliegue. Corresponde a PS-5 o al mes de producción. |
| Caché en profundidad | Se explica que es opt-in en 16.x y cómo pedirlo. La teoría completa es tema propio. |
| Streaming y `<Suspense>` manual | `loading.tsx` lo cubre implícitamente. La API manual es refinamiento. |
| `next/image`, fuentes, optimización | Tema de la semana de producción. |
| Tailwind | Se desactiva en el setup. Ver hallazgo abierto 1. |
| Deploy en Vercel | Es la capacidad nueva de PS-5. |
| `useActionState`, `useFormStatus` | Refinamiento de Server Actions. Con el formulario básico funcionando, se agregan después. |

### Prerrequisitos

```
Semana 6  → async/await, promesas, fetch          ✔ verificado
Semana 8  → HTML semántico, CSS                    ✔ verificado
Semana 09 → tipos, genéricos (Promise<{...}>)      ✔ verificado
Semana 10 → componentes, props, estado, useEffect  ✔ verificado
Semana 11 → composición, use(), custom hooks       ✔ verificado
PS-4      → aplicación con escritura de datos      ⚠ no generado (ver hallazgo 3)
```

**Dependencia pagada:** el hook `use()` se introdujo en la Semana 11 como sintaxis
LIGERA "de reconocimiento, no la necesitas esta semana". Aquí aparece su caso
real: leer `params` en un Client Component, donde `await` no es posible porque
los componentes cliente no pueden ser `async`. La deuda se salda.

---

## FASE 1 — INVESTIGACIÓN (tecnología viva de alto riesgo)

Next.js es la tecnología con mayor tasa de cambio del stack. Búsqueda obligatoria
y extensa.

| Afirmación | Fuente | Verificado | Impacto en el contenido |
|---|---|---|---|
| Next.js 16.2.x es la versión vigente | docs oficiales | julio 2026 | Versión de referencia del bloque perecedero |
| `params` y `searchParams` son **Promises** desde la 15; hay que `await` | docs oficiales + Vercel Academy | julio 2026 | **Reescribió el Día 3 completo.** Todos los ejemplos de rutas dinámicas |
| En Client Components se usa `use(params)` porque no pueden ser `async` | docs oficiales | julio 2026 | Conecta con la Semana 11 y justifica su inclusión |
| Turbopack es el bundler por defecto en `dev` y `build` | docs oficiales | julio 2026 | Bloque de setup |
| El caché pasó de opt-out a **opt-in** en la 16 | notas de versión | julio 2026 | Sección de datos del Día 3; evita enseñar el modelo de la 14 |
| `middleware.ts` se renombró a `proxy.ts` | notas de versión | julio 2026 | Solo tabla de cambios; el tema está fuera de alcance |
| El Pages Router está en modo mantenimiento | docs + fuentes secundarias | julio 2026 | Se ignora por completo; se advierte sobre `next/router` |
| La plantilla por defecto activa Tailwind | docs oficiales | julio 2026 | Obliga a decisión explícita en el setup — ver hallazgo 1 |
| El layout raíz debe contener `<html>` y `<body>` | docs oficiales | julio 2026 | Día 1 |
| `error.tsx` debe ser Client Component | docs oficiales | julio 2026 | Día 4 |

### Qué habría salido mal sin esta fase

Escribiendo de memoria habría producido, con alta probabilidad:

```
✗ params.id sin await          → todos los ejemplos de rutas dinámicas rotos
✗ modelo de caché de Next 14   → conceptualmente invertido
✗ middleware.ts                → archivo que ya no existe con ese nombre
✗ webpack como bundler         → desactualizado
```

El primero es el más grave: habría roto **todos** los ejemplos del Día 3 y del
proyecto, con un error que el alumno no puede diagnosticar sin saber del cambio.

Es exactamente el fallo de la Semana 09 con `ts-node`, en una tecnología que
cambia mucho más rápido.

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ Una carpeta sin page.tsx no genera ruta
✔ El layout raíz es obligatorio y contiene html y body
✔ Los layouts no se remontan al navegar entre rutas hermanas
✔ Todo componente en app/ es Server Component por defecto
✔ "use client" debe ir en la primera línea, antes de los imports
✔ "use client" se propaga a todo lo que el módulo importe
✔ Server → Client solo admite props serializables (no funciones)
✔ Client no puede importar Server, pero sí recibirlo como children
✔ params y searchParams son Promises; await en servidor, use() en cliente
✔ notFound() y redirect() operan lanzando una excepción interna
✔ error.tsx requiere "use client"
✔ generateMetadata recibe params como Promise
✔ revalidatePath solo funciona en servidor
✔ useRouter se importa de next/navigation, no de next/router
```

### Corrección aplicada durante esta fase

```
Formulación incorrecta (borrador):
  "'use client' convierte el archivo en un Client Component"

Por qué era incorrecta:
  Sugiere alcance de archivo. El alumno con ese modelo pone la directiva
  en cada archivo "por si acaso", incluidos layouts, y termina con la
  aplicación entera en el cliente sin entender por qué perdió el beneficio.

Formulación corregida:
  "'use client' no marca un archivo. Marca una frontera." Con el diagrama
  del árbol mostrando la propagación hacia abajo, y la regla de colocarla
  lo más abajo posible.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ Terminología estable: "servidor", "cliente", "frontera", "ruta", "acción"
✔ El Día 1 establece rutas; el Día 3 las hace dinámicas
✔ El Día 2 define la frontera; los Días 3-5 la aplican
✔ La composición de la Semana 11 se retoma dos veces (layouts, children a través
   de la frontera) señalada explícitamente
✔ El useEffect de la Semana 10 se contrasta dos veces: datos (D3) y título (D4)
✔ Cada día abre con un dolor concreto del proyecto anterior
```

### Ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — esqueleto, layout raíz, layout anidado | Proyecto D6 |
| D1 — Link vs `<a>` | Ninguno. **Justificado:** demostración |
| D2 — migrar catálogo, frontera mínima | Proyecto D6 |
| D2 — inspeccionar HTML inicial | Criterio de aprobación del D6 |
| D2 — romper la frontera a propósito | Ninguno. **Justificado:** experiencia |
| D3 — ruta dinámica, enlazar, notFound, searchParams | Proyecto D6 |
| D4 — loading, error, metadatos | Proyecto D6 |
| D4 — jerarquía de loading | Ninguno. **Justificado:** deducción de regla |
| D5 — crear, validar, cancelar | Proyecto D6 (crear y validar) |
| D5 — provocar el bug de revalidatePath | Ninguno. **Justificado:** reconocer síntoma |

**Nota:** el ejercicio 3 del D5 (cancelar reserva) no entra en el proyecto D6, que
pide una sola mutación. Va a PS-5, que pide todas. Marcado en la sección de
delimitación.

---

## FASE 6b — CONFORMIDAD

```
□✔ Constitución Parte 3 — punto y coma, ===, nombres en español, toLocaleString
□✔ .prettierrc — semi true, tabWidth 2, comillas dobles, sin trailing comma
□✔ ESTADO_ROADMAP — Semana 12 definida por el pie de la Semana 11: coincide
□✔ NEXUS_PROYECTO_NARRATIVA — el módulo corresponde a "Aplicación Nexus v1";
     anclado a PS-5, sin referencias a mes calendario
□✔ Decisiones arquitectónicas — proyecto nuevo, se heredan datos y reglas, no
     código; la migración es trabajo del alumno
□✔ Bootcamps adyacentes — el pie de la Semana 11 anuncia Next.js: coincide.
     El pie de esta anuncia Semana 13 = Tailwind + shadcn/ui
```

**Coherencia con la Semana 10 verificada:** aquella advertía explícitamente contra
`useEffect` + `fetch` "porque lo resuelven los Server Components de Next.js". Esta
semana cumple esa promesa y lo señala. Sin esa continuidad, la advertencia de la
Semana 10 habría quedado sin cobrar.

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS

```
RECHAZADA 1: "Los Server Components son más rápidos"

Razón: vago y a veces falso. No explica el mecanismo, y el alumno con
ese modelo no puede decidir dónde poner la frontera — solo sabe que una
opción es "mejor".

Reemplazo: el mecanismo concreto (el JS no viaja, el HTML llega armado,
los secretos no se exponen) y el criterio operativo: "Server = lo que el
usuario ve; Client = lo que el usuario toca".
```

```
RECHAZADA 2: "'use client' convierte el archivo en Client Component"

Razón: ver Fase 4. Modelo de alcance equivocado.

Reemplazo: frontera con propagación, con diagrama y regla de colocación.
```

```
RECHAZADA 3: "Las Server Actions reemplazan a las APIs"

Razón: falso en general. Las APIs siguen siendo necesarias para clientes
externos, móviles y webhooks. Un alumno con ese modelo no sabría qué
hacer cuando aparezca un consumidor externo.

Reemplazo: "Server Actions para escribir, Server Components para leer",
más la sección explícita de cuándo NO usarlas.
```

```
RECHAZADA 4: "params ahora es asíncrono por rendimiento"

Razón: cierto pero inútil. No ayuda a recordarlo ni a diagnosticar el
error, que es lo que el alumno va a necesitar cuando copie un ejemplo
viejo.

Reemplazo: presentarlo como "la trampa más importante de la semana", con
el código incorrecto al lado del correcto, el mensaje de error literal, y
la advertencia de que casi todo el material que encuentre está
desactualizado.
```

### Ataques intentados sin hallazgo

```
✔ ¿Se enseña algún patrón del Pages Router? No. Se advierte sobre next/router
✔ ¿Se enseña el modelo de caché de Next 14? No. Se corrigió tras la Fase 1
✔ ¿Algún ejemplo usa params sin await? Revisados todos: ninguno
✔ ¿La semana justifica el cambio de herramienta? El Día 1 abre con tres
  limitaciones concretas del proyecto anterior
✔ ¿Se adelanta contenido de meses posteriores? Base de datos, auth y deploy
  quedan fuera con razón documentada
```

---

## VERIFICACIÓN DE LA ENMIENDA 10 — SINTAXIS NUEVA

| Sintaxis | Peso | Tratamiento |
|---|---|---|
| `"use client"` | **MEDIA** | Se enseña en el cuerpo del Día 2 como concepto central, no de contrabando |
| `"use server"` | **MEDIA** | Cuerpo del Día 5 |
| `await params` | **MEDIA** | Cuerpo del Día 3, marcado como la trampa principal |
| `notFound()` / `redirect()` | LIGERA | Definición + ejemplo + trampa (lanzan excepción) |
| `revalidatePath()` | LIGERA | Definición + ejemplo + trampa (bug número uno) |
| `generateMetadata` | LIGERA | Día 4, con la nota del `await` |

```
✔ Ninguna PESADA de contrabando
✔ Las tres MEDIA se enseñan en el cuerpo del día, con su dolor previo
✔ Las LIGERAS llevan definición, ejemplo y trampa
✔ Ninguna en el Día 1
```

**Nota de calibración:** es la semana con más sintaxis nueva de todo el material
generado. Se justifica porque cambiar de framework *es* aprender su vocabulario.
Bajo la Enmienda 9 original habría sido inviable; bajo el criterio por peso de la
Enmienda 10 es defendible, porque ninguna es PESADA y las tres MEDIA son el
contenido de la semana, no un extra.

---

## VERIFICACIÓN INDEPENDIENTE — 2026-07-31

El material se revisó contra una búsqueda nueva, posterior a su generación, para
comprobar que la Fase 1 se había ejecutado de verdad y no solo declarado (Error 6
de la Constitución).

**Confirmado correcto:**

```
✔ Next.js 16.x es la versión vigente (16.2.x)
✔ params y searchParams son Promesas; el acceso síncrono se ELIMINÓ en la 16
  (en la 15 existía compatibilidad temporal, en la 16 ya no)
✔ Turbopack es el bundler por defecto en dev y en build
✔ middleware.ts fue renombrado a proxy.ts, y la función exportada debe llamarse
  proxy. El runtime es Node.js, no edge
✔ El modelo de caché es opt-in
✔ next/navigation es el import correcto; next/router es del Pages Router
```

**Dos omisiones detectadas y CORREGIDAS en esta revisión:**

```
1. No figuraba el requisito de Node.js 20.9 o superior. Es un fallo práctico:
   con una versión anterior, create-next-app falla en la instalación y el
   mensaje de error no siempre es claro. AÑADIDO al bloque perecedero.

2. No se mencionaba que next lint fue eliminado en la 16. Riesgo real: hay
   mucho material que lo usa, y su ausencia no produce error de build — el
   pipeline puede reportar verde sin haber linteado nada. AÑADIDO.
```

**Matiz sobre el modelo de caché:** el material lo describe correctamente como
opt-in, pero no lo nombra. En la 16 el mecanismo se llama **Cache Components** y
se activa con la bandera `cacheComponents` más la directiva `"use cache"`. No se
añade al contenido porque está fuera del alcance declarado de la semana; queda
registrado por si al regenerar el bloque perecedero conviene mencionarlo.

---

## HALLAZGOS ABIERTOS

### 1. Tailwind desactivado contra la plantilla por defecto

`create-next-app` activa Tailwind por defecto. El material indica responder "No".

**A favor:** la semana ya cambia dónde se ejecuta el código; sumar un sistema de
estilos duplica la carga. La Semana 13 lo introduce sobre una base que funciona.

**En contra:** se pelea con el flujo por defecto, y en un equipo real nadie lo
desactiva. El proyecto se verá pobre, tercera semana consecutiva.

**Alternativa no aplicada:** aceptar Tailwind en el setup sin enseñarlo, usándolo
mínimamente. Se descartó porque tener una herramienta instalada y no explicada
genera más confusión que no tenerla.

Recomendación: mantener. Revisar si el impacto en motivación resulta mayor de lo
estimado.

### 2. El límite de 3 componentes cliente es arbitrario

El proyecto exige máximo 3 `"use client"`. El número no sale de ninguna regla:
sale de estimar que el catálogo necesita filtro, formulario y quizá un panel.

**Riesgo:** si al construir resultan necesarios 4 por una razón legítima, el
requisito genera frustración en vez de criterio.

**Mitigación aplicada:** el material dice *"si necesitas un cuarto, casi seguro
estás poniendo la frontera más arriba de lo necesario"* — deja abierta la
discusión en vez de prohibir.

Sugerencia: si en la validación aparece un cuarto justificado, aceptarlo y
registrar el caso.

### 3. PS-4 sigue sin generarse

Ya registrado en el QA de la Semana 11. Aquí vuelve a aparecer: el material asume
un formulario de reserva y una aplicación con escritura previa.

**Ahora es más urgente:** hay dos semanas (11 y 12) que dependen de PS-4. Debería
generarse antes que la Semana 13.

### 4. La migración desde Vite no está guiada

El proyecto pide crear una aplicación nueva y traer el código anterior, pero el
material no aborda qué se puede reutilizar tal cual (lógica pura, tipos, datos) y
qué hay que reescribir (todo lo que asume navegador).

Se dejó deliberadamente como parte del desafío. Registrado por si en la validación
resulta ser un obstáculo mayor de lo previsto.

---

## ADVERTENCIA SOBRE LA VIGENCIA — LA MÁS SERIA DE TODO EL MATERIAL

Generado en julio de 2026 para usarse hacia febrero de 2027. Next.js publica
versiones mayores aproximadamente cada seis meses.

```
MUY ALTO → comando y preguntas de create-next-app
MUY ALTO → si params sigue siendo Promise, o cambia otra vez
ALTO     → modelo de caché (cambió entre 14 y 16; puede volver a cambiar)
ALTO     → nombres de archivos convencionales (middleware→proxy ya ocurrió)
MEDIO    → API de Server Actions y revalidatePath
MEDIO    → estado del Pages Router
BAJO     → concepto de Server/Client Components, routing por carpetas, layouts
```

**Regenerar el bloque perecedero es obligatorio, no recomendable.** Y antes de
usar la semana conviene verificar específicamente el comportamiento de `params`:
es el punto del que dependen más ejemplos.

Este documento es la mejor ilustración del principio de la Enmienda 2: los
conceptos (qué es un Server Component, por qué existe la frontera, por qué la URL
es estado) van a seguir siendo válidos. Los comandos y las firmas, probablemente
no.

---

*Verificación independiente: 2026-07-31 — Fase 1 confirmada, dos omisiones corregidas*

*Reporte QA Semana 12 — julio 2026*
*Constitución v1.3 · Fases 0-8 incluyendo 6b*
