# 📄 CHEAT SHEET — SEMANA 12
## Next.js · App Router · Server y Client Components · Rutas · Server Actions

> Léela completa antes de empezar el Día 1.
> Esta semana cambia dónde se ejecuta tu código. Es el cambio de modelo mental
> más grande desde que empezaste con React.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado y verificado: julio 2026
Versión de referencia: Next.js 16.2.x
Next.js cambia rápido. REGENERAR este bloque antes de empezar la semana.
```

```bash
npx create-next-app@latest nexus-web
```

Responde a las preguntas:

```
TypeScript          → Yes
ESLint              → Yes
Tailwind CSS        → No     ← Tailwind entra en la Semana 13
App Router          → Yes
Turbopack           → Yes
import alias (@/*)  → Yes
```

```bash
cd nexus-web
npm run dev
```

⚠ Las preguntas del asistente cambian entre versiones. Si alguna no aparece o
aparece otra nueva, guíate por el criterio: TypeScript y App Router sí, Tailwind
no hasta la Semana 13.

**Requisitos y valores por defecto de Next.js 16:**

```
Node.js 20.9 o superior — OBLIGATORIO. Con una versión anterior falla la
                          instalación. Verifica con: node --version
Turbopack               es el bundler por defecto, en desarrollo y en build
React 19.2              viene incluido
next lint               fue ELIMINADO. El linting se configura con ESLint
                        directamente; si ves un tutorial que usa "next lint",
                        es de una versión anterior
```

**Lo que cambió en Next.js 16 y aún verás mal en tutoriales:**

| Antes (Next.js 14) | Ahora (16.x) |
|---|---|
| `params` era un objeto | `params` es una **Promise** — hay que `await` |
| Webpack por defecto | **Turbopack** por defecto |
| Caché agresivo por defecto | Caché **opt-in** — pides lo que quieras cachear |
| `middleware.ts` | `proxy.ts` |
| Pages Router vigente | Pages Router en mantenimiento |

Si un tutorial escribe `params.id` sin `await`, es de antes de la 15.

---

## 1. EL ROUTER BASADO EN ARCHIVOS

**Qué es:** En Next.js las rutas no se declaran en código: se declaran creando
carpetas.

```
app/
├── layout.tsx              ← envuelve TODO (obligatorio)
├── page.tsx                ← ruta /
├── expediciones/
│   ├── page.tsx            ← ruta /expediciones
│   └── [id]/
│       └── page.tsx        ← ruta /expediciones/EXP001
└── reservas/
    └── page.tsx            ← ruta /reservas
```

**Las convenciones de nombre que importan:**

| Archivo | Qué hace |
|---|---|
| `page.tsx` | Hace que la carpeta sea una ruta accesible |
| `layout.tsx` | Envuelve la página y todo lo que hay debajo |
| `loading.tsx` | Se muestra mientras la página carga |
| `error.tsx` | Se muestra si la página lanza un error |
| `not-found.tsx` | Se muestra al llamar `notFound()` |

**Regla:** una carpeta sin `page.tsx` **no es una ruta**. Sirve para organizar,
pero no responde a ninguna URL.

**Error típico:** crear `app/expediciones/index.tsx` esperando que funcione. El
nombre es `page.tsx`, siempre.

---

## 2. LAYOUTS

**Qué es:** Un componente que envuelve a sus rutas hijas y **no se vuelve a
renderizar** al navegar entre ellas.

```tsx
// app/layout.tsx — el layout raíz es obligatorio
export default function RootLayout({
  children
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>
        <nav>...</nav>
        {children}
      </body>
    </html>
  );
}
```

El layout raíz **debe** incluir `<html>` y `<body>`. Es el único lugar de tu
aplicación donde escribes esas etiquetas.

**Los layouts se anidan:**

```
app/layout.tsx                    → envuelve todo
app/expediciones/layout.tsx       → envuelve solo /expediciones/*
```

Al navegar de `/expediciones` a `/expediciones/EXP001`, los dos layouts se
mantienen montados. Solo cambia el `page.tsx`. Por eso un menú lateral en un
layout conserva su scroll y su estado.

---

## 3. SERVER COMPONENTS Y CLIENT COMPONENTS

**El concepto central de la semana.**

> **Todo componente dentro de `app/` es un Server Component por defecto.**
> Se ejecuta en el servidor. Su JavaScript nunca llega al navegador.

```tsx
// Server Component (por defecto — no lleva nada especial)
export default async function PaginaExpediciones() {
  const expediciones = await obtenerExpediciones();  // puede ser async
  return <Lista datos={expediciones} />;
}
```

**Client Component** — lleva la directiva en la primera línea del archivo:

```tsx
"use client";

import { useState } from "react";

export default function Filtro() {
  const [tipo, setTipo] = useState("todos");
  return <button onClick={() => setTipo("kayak")}>Kayak</button>;
}
```

### Qué puede cada uno

| | Server Component | Client Component |
|---|---|---|
| `async` / `await` | ✅ | ❌ |
| Leer base de datos, variables de entorno | ✅ | ❌ |
| `useState`, `useEffect`, `useContext` | ❌ | ✅ |
| `onClick`, `onChange` y demás eventos | ❌ | ✅ |
| APIs del navegador (`window`, `localStorage`) | ❌ | ✅ |
| Enviar JS al navegador | No | Sí |

**La regla práctica:** ¿necesita interactividad o estado? Client. ¿Solo muestra
datos? Server.

**`"use client"` marca una frontera, no un archivo.** Todo lo que ese componente
importe pasa a ser cliente también. Por eso la directiva va **lo más abajo
posible** en el árbol: si la pones en el layout raíz, toda la aplicación se
vuelve cliente y pierdes la ventaja entera.

**Error típico:**

```tsx
// ❌ un Server Component no puede tener onClick
export default function Boton() {
  return <button onClick={() => alert("hola")}>Clic</button>;
}
```

El error dice que los event handlers no se pueden pasar a Client Components.
Traducción: este componente necesita `"use client"`.

**Lo que sí se puede:** un Server Component puede **renderizar** un Client
Component y pasarle datos por props. Al revés no: un Client Component no puede
importar un Server Component, pero sí recibirlo como `children`.

---

## 4. OBTENER DATOS

En un Server Component se pide datos directamente. Sin `useEffect`, sin estado
de carga, sin `fetch` en el cliente.

```tsx
export default async function Pagina() {
  const datos = await fetch("https://api.ejemplo.cl/expediciones");
  const expediciones = await datos.json();

  return <Lista datos={expediciones} />;
}
```

**Esto es lo que reemplaza al patrón que en la Semana 10 te dije que no
aprendieras.** El `useEffect` + `fetch` + `useState` de carga y error se
convierte en tres líneas que corren en el servidor.

**Caché en Next.js 16:** el caché es **opt-in**. Por defecto los datos se piden
de nuevo. Si quieres cachear, lo pides explícitamente:

```tsx
fetch(url, { next: { revalidate: 3600 } });   // revalidar cada hora
```

En Next.js 14 era al revés y causaba mucha confusión. Si lees un tutorial que
habla de "desactivar el caché", es de esa época.

---

## 5. RUTAS DINÁMICAS Y `await params`

Una carpeta entre corchetes captura un segmento variable de la URL:

```
app/expediciones/[id]/page.tsx    →  /expediciones/EXP001
```

```tsx
export default async function PaginaExpedicion({
  params
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const expedicion = await obtenerExpedicion(id);

  if (!expedicion) {
    notFound();
  }

  return <h1>{expedicion.nombre}</h1>;
}
```

> ⚠ **La trampa más importante de la semana.** Desde Next.js 15, `params` y
> `searchParams` son **Promises**. Hay que esperarlas.
>
> ```tsx
> const id = params.id;          // ❌ params es una Promise
> const { id } = await params;   // ✅
> ```
>
> Prácticamente todos los tutoriales anteriores a 2025 tienen la forma vieja.
> El error en consola dice que `params` debe desenvolverse con `await` o
> `React.use()`.

**En un Client Component** no puedes usar `await` (no pueden ser `async`). Ahí
se usa el hook `use()` que viste en la Semana 11:

```tsx
"use client";
import { use } from "react";

export default function Componente({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
}
```

Ese es el caso real donde `use()` importa, y por qué se mencionó antes.

---

## 6. NAVEGACIÓN

```tsx
import Link from "next/link";

<Link href="/expediciones">Ver catálogo</Link>
<Link href={`/expediciones/${expedicion.id}`}>Detalle</Link>
```

**Nunca uses `<a href>` para rutas internas.** El `<a>` recarga la página entera
y pierde el estado; `<Link>` navega sin recargar y precarga la ruta destino.

**Navegación desde código** (solo en Client Components):

```tsx
"use client";
import { useRouter } from "next/navigation";

const router = useRouter();
router.push("/expediciones");
```

> ⚠ **Trampa:** debe importarse de `next/navigation`, no de `next/router`.
> Ese segundo es del Pages Router y no funciona aquí. Es un error de importación
> muy común porque los tutoriales viejos usan el otro.

---

## 7. ESTADOS DE CARGA Y ERROR

Archivos con nombre reservado, sin configuración:

```tsx
// app/expediciones/loading.tsx
export default function Cargando() {
  return <p>Cargando expediciones...</p>;
}
```

```tsx
// app/expediciones/error.tsx
"use client";                              // error.tsx SIEMPRE es cliente

export default function Error({
  error,
  reset
}: {
  error: Error;
  reset: () => void;
}) {
  return (
    <div>
      <p>Algo salió mal: {error.message}</p>
      <button onClick={reset}>Reintentar</button>
    </div>
  );
}
```

```tsx
// app/not-found.tsx  — se muestra al llamar notFound()
import { notFound } from "next/navigation";
```

**`error.tsx` debe llevar `"use client"` obligatoriamente.** Necesita el botón de
reintentar, y eso es interactividad.

---

## 8. SERVER ACTIONS

**Qué es:** Una función que se ejecuta en el servidor pero se llama desde el
cliente, sin escribir una API.

```tsx
// app/acciones.ts
"use server";

export async function crearReserva(datos: FormData) {
  const cliente = datos.get("cliente");
  await guardarEnBaseDeDatos({ cliente });
  revalidatePath("/reservas");
}
```

```tsx
// Uso desde un formulario
import { crearReserva } from "./acciones";

<form action={crearReserva}>
  <input name="cliente" />
  <button type="submit">Reservar</button>
</form>
```

Fíjate: el formulario llama a `action={crearReserva}` directamente. No hay
`fetch`, no hay endpoint, no hay `onSubmit`.

> ⚠ **Trampa:** después de modificar datos hay que llamar a `revalidatePath()` o
> `revalidateTag()`. Si no, la página sigue mostrando los datos anteriores y
> parece que la acción no funcionó.

**`"use server"` no es lo contrario de `"use client"`.** `"use client"` marca la
frontera hacia el navegador; `"use server"` marca funciones que se ejecutan en el
servidor aunque las invoque el cliente. Son cosas distintas con nombres
desafortunadamente simétricos.

---

## 9. SINTAXIS NUEVA DE ESTA SEMANA

### `notFound()` y `redirect()` · peso LIGERO

```tsx
import { notFound, redirect } from "next/navigation";

if (!expedicion) notFound();      // muestra not-found.tsx
if (!sesion) redirect("/login");  // navega a otra ruta
```

> ⚠ **Trampa:** las dos lanzan una excepción internamente para cortar el
> renderizado. No pongas código después esperando que se ejecute, y no las metas
> dentro de un `try/catch` genérico — atraparías la señal de Next.js y romperías
> el mecanismo.

### `revalidatePath()` · peso LIGERO

```tsx
import { revalidatePath } from "next/cache";
revalidatePath("/reservas");
```

Le dice a Next.js que los datos de esa ruta cambiaron.

> ⚠ **Trampa:** solo funciona en el servidor (Server Actions o route handlers).
> Y la ruta se escribe tal como está en `app/`, no la URL final.

---

## 10. TABLA DE DECISIÓN

| Necesito... | Uso |
|---|---|
| Mostrar datos que vienen del servidor | Server Component + `await` |
| Un botón, un input, un filtro | Client Component (`"use client"`) |
| Que la URL identifique un recurso | Ruta dinámica `[id]` + `await params` |
| Guardar o modificar datos | Server Action (`"use server"`) |
| Que algo se comparta entre rutas | `layout.tsx` |
| Mostrar algo mientras carga | `loading.tsx` |

---

*Cheat Sheet Semana 12 — Next.js App Router*
*Prerrequisitos: Semana 6 (async/await) · Semana 8 (HTML/CSS) · Semana 09 (TypeScript) · Semanas 10-11 (React)*
