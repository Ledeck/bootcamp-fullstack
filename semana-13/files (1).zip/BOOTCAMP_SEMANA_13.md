# 📘 BOOTCAMP SEMANA 13
## Tailwind CSS v4 · shadcn/ui · Sistema de diseño

---

```
ACTA DE GENERACIÓN
Fecha de generación: julio 2026
Semana en curso de Óscar al generar: 04 (PS-1 en curso)
Distancia estimada hasta el uso: ~8 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 7, 8
Fase 1 — fuentes: documentación oficial de Tailwind CSS v4 y de shadcn/ui
         (CLI v4, guía de Tailwind v4), consultadas en julio 2026
Referencias: Tailwind CSS v4.x · shadcn/ui CLI v4
Bloque perecedero: ALTO RIESGO — regenerar antes de usar
Constitución aplicada: v1.3 (enmiendas 1-10)
```

---

> **Antes de empezar:** Lee la `CHEATSHEET_SEMANA_13.md` completa.
> **Recuerda:** cuando termines cada día, avísame para validar antes de continuar.

---

## ⏱ BLOQUE PERECEDERO — REGENERAR ANTES DE USAR

```
Verificado: julio 2026 · Tailwind v4.x · shadcn CLI v4
```

Trabajas sobre el proyecto de la Semana 12, que se creó **sin** Tailwind. Ahora
lo agregas.

```bash
npm install tailwindcss @tailwindcss/postcss
```

En `app/globals.css`, borra todo y deja:

```css
@import "tailwindcss";
```

Inicializa shadcn/ui:

```bash
npx shadcn@latest init
```

Responde: color base → **Neutral**. El resto, valores por defecto.

```bash
npm run dev
```

**Verificar antes de usar:** que Tailwind siga sin `tailwind.config.js`, que
`@import "tailwindcss"` siga siendo la forma de importarlo, y que el CLI de
shadcn siga usando `init` y `add`.

---

## ⚠️ NOTAS DE ALCANCE

### Esta semana no enseña CSS

Enseña otra forma de escribir el CSS de la Semana 8. `flex items-center` **es**
`display: flex; align-items: center`. Si en algún momento no entiendes qué hace
una utilidad, la pregunta correcta es "¿qué propiedad CSS aplica?", y la
respuesta siempre existe.

Quien aprende Tailwind sin saber CSS termina memorizando clases sin entender el
resultado. Tú tienes la Semana 8; úsala.

### Por fin algo que se ve

Tres semanas seguidas (10, 11, 12) el proyecto quedó feo a propósito. Esta es la
que lo arregla, y no es casualidad que llegue al final: estilar algo que funciona
es mucho más rápido que estilar algo que todavía cambia.

### Trabajas sobre lo que ya existe

No se crea un proyecto nuevo. Se rediseña Nexus Web sin tocar su lógica. Que se
pueda cambiar la capa visual sin romper nada es, en sí mismo, la prueba de que
estaba bien separada.

---

## 🗓 DÍA 1 — UTILIDADES

### 🎯 Objetivo
Entender por qué existen las utilidades y traducir tu CSS actual.

---

### 📖 El problema real

Nexus Web funciona pero se ve pobre. Tienes CSS de la Semana 8 repartido en
archivos, y cada vez que agregas un componente enfrentas la misma pregunta: cómo
llamar a la clase.

`.tarjeta`, `.tarjeta-destacada`, `.tarjeta-detalle`, `.tarjeta-detalle-compacta`.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Con lo de la Semana 8: una hoja de estilos, clases con nombres descriptivos,
quizá una convención tipo BEM para no perderte.

---

### 📖 Por qué esa solución se rompe al crecer

Tres problemas que aparecen sobre las 2.000 líneas de CSS.

**Nombrar cuesta más que estilar.** Cada elemento necesita un nombre único y
descriptivo. Discutes con tu yo del futuro si esto es `.panel-lateral` o
`.barra-navegacion`.

**Nadie borra CSS.** Cuando eliminas un componente, sus estilos quedan. Nadie se
atreve a borrarlos porque no sabe quién más los usa. El archivo solo crece.

**Los estilos actúan a distancia.** Cambias `.tarjeta` para arreglar el catálogo y
rompes la vista de reservas, que la usaba sin que lo supieras. El daño está lejos
del cambio.

---

### 📖 Las utilidades como solución

```html
<div class="flex items-center gap-4 p-6 rounded-lg bg-white shadow">
```

Cada clase aplica una propiedad. El estilo vive donde está el elemento.

Los tres problemas desaparecen: no hay nombres que inventar, borrar el HTML borra
el estilo, y modificar un elemento no puede afectar a otro.

---

### 📖 Cómo funciona

Tailwind escanea tus archivos, encuentra las clases que usas, y genera **solo
esas**. Si nunca escribes `bg-purple-700`, esa regla no existe en el CSS final.

En v4 el escaneo es automático: no hay que declarar rutas en ninguna
configuración.

---

### 📖 La objeción evidente

*"Esto es como los estilos en línea, que aprendí que están mal."*

Es la objeción correcta y hay que responderla:

```
✓ Los estilos en línea no soportan :hover ni media queries. Las utilidades sí.
✓ Los estilos en línea aceptan cualquier valor; aquí hay una escala fija.
  No puedes poner 13px porque sí, y esa restricción produce coherencia.
✓ El CSS final es un archivo compartido y cacheado.
```

**Lo que sí pierdes:** el HTML se lee peor. Es un intercambio real. La respuesta
de Tailwind es que si un bloque de clases se repite, eso es un componente — y
componentes ya sabes hacer.

---

### 📖 Traducir lo que ya sabes

| CSS (Semana 8) | Tailwind |
|---|---|
| `display: flex` | `flex` |
| `flex-direction: column` | `flex-col` |
| `justify-content: space-between` | `justify-between` |
| `align-items: center` | `items-center` |
| `gap: 1rem` | `gap-4` |
| `padding: 1.5rem` | `p-6` |
| `display: grid` | `grid` |
| `grid-template-columns: repeat(3, 1fr)` | `grid-cols-3` |
| `font-weight: 700` | `font-bold` |
| `border-radius: 0.5rem` | `rounded-lg` |

**La escala:** el número no son píxeles. `1` = `0.25rem` = 4px. Así que `p-4` son
16px y `gap-2` son 8px.

---

### 📖 Errores frecuentes

```
❌ p-16 esperando 16px          → son 64px. La escala no es en píxeles
❌ inventar clases (bg-azul)    → si no existe, no genera nada y no avisa
❌ construir clases con strings  → `bg-${color}-500` no lo detecta el escáner
❌ mezclar CSS propio y utilidades para lo mismo → gana quien tenga más
   especificidad, y eso ya no es evidente
```

El tercero merece atención: Tailwind busca **cadenas completas** en tu código. Una
clase armada por concatenación no aparece como texto y no se genera.

---

### 📖 Mini-ejercicio de comprensión

Traduce a utilidades:

```css
.panel {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  padding: 1rem;
  background-color: white;
  border-radius: 0.5rem;
}
```

---

### 🛠 EJERCICIOS DÍA 1

**Ejercicio 1** — setup

Instala Tailwind en el proyecto de la Semana 12 y comprueba que funciona
aplicando `text-3xl font-bold text-blue-600` a un título.

**Ejercicio 2** — traducir la tarjeta

Convierte `TarjetaExpedicion` a utilidades. Borra su CSS anterior. Debe quedar
visualmente igual o mejor.

**Ejercicio 3** — el catálogo

Convierte la lista a `grid` con Tailwind. Tres columnas fijas por ahora.

**Ejercicio 4** — prueba el escáner

Escribe `<div className="bg-red-500">` y comprueba que funciona. Luego prueba:

```tsx
const color = "red";
<div className={`bg-${color}-500`}>
```

Documenta qué pasó y por qué, con el mecanismo del día.

---

**Cuando termines avísame — valido el Día 1.** ✅

---

## 🗓 DÍA 2 — RESPONSIVE, ESTADOS Y MODO OSCURO

### 🎯 Objetivo
Aplicar variantes sin escribir una sola media query.

---

### 📖 El problema real

El catálogo tiene tres columnas fijas. En un teléfono, las tarjetas quedan
ilegibles. Y ningún botón reacciona al pasar el puntero.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Con la Semana 8: media queries y pseudoclases.

```css
.catalogo { grid-template-columns: 1fr; }

@media (min-width: 768px) {
  .catalogo { grid-template-columns: repeat(2, 1fr); }
}

.boton:hover { background-color: #1d4ed8; }
```

Funciona perfecto. No es un mal enfoque.

---

### 📖 Qué cambia con las variantes

```html
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
<button class="bg-blue-500 hover:bg-blue-600">
```

El mismo comportamiento, sin salir del elemento. Ya no tienes que buscar en otro
archivo qué le pasa a este bloque en pantallas medianas.

**Y es mobile-first, igual que lo de la Semana 8:** la clase sin prefijo es la
base, los prefijos sobrescriben hacia arriba.

| Prefijo | Desde |
|---|---|
| *(ninguno)* | siempre |
| `sm:` | 640px |
| `md:` | 768px |
| `lg:` | 1024px |
| `xl:` | 1280px |

> ⚠ **Error típico:** creer que `md:grid-cols-2` aplica *solo* en pantallas
> medianas. Aplica desde 768px hacia arriba, incluidas las grandes. No hay
> prefijo para "solo móvil" — esa es la clase base.

---

### 📖 Estados

```html
<button class="bg-blue-500 hover:bg-blue-600 focus:ring-2 disabled:opacity-50">
```

| Prefijo | Cuándo |
|---|---|
| `hover:` | puntero encima |
| `focus:` | enfocado (teclado incluido) |
| `active:` | mientras se presiona |
| `disabled:` | atributo disabled |
| `group-hover:` | al pasar sobre un ancestro con clase `group` |

`group` resuelve algo que en CSS plano es incómodo: reaccionar al hover del
padre.

```html
<div class="group">
  <h3 class="group-hover:text-blue-600">Torres del Paine</h3>
</div>
```

**Sobre `focus:`** — no es decorativo. Es cómo se navega con teclado. Quitar el
anillo de foco sin poner otra señal deja tu aplicación inutilizable para quien no
usa ratón.

---

### 📖 Modo oscuro

```html
<div class="bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100">
```

Sin librerías, sin configuración: sigue la preferencia del sistema operativo.

Un botón para cambiar el tema a mano necesita estado de cliente y una librería
(`next-themes`). Queda fuera de esta semana.

---

### 📖 Se combinan

```html
<div class="md:hover:bg-gray-100 dark:md:hover:bg-gray-800">
```

Se leen de izquierda a derecha como condiciones acumuladas.

---

### 📖 Mini-ejercicio de comprensión

```html
<div class="grid grid-cols-2 md:grid-cols-1 lg:grid-cols-4">
```

¿Cuántas columnas se ven en 400px, 800px y 1400px? Justifica.

---

### 🛠 EJERCICIOS DÍA 2

**Ejercicio 1** — catálogo responsive

Una columna en móvil, dos desde `md`, tres desde `lg`. Comprueba con las DevTools.

**Ejercicio 2** — estados

Todos los elementos interactivos deben tener `hover:` y `focus:` visibles. Navega
la aplicación entera solo con Tab y verifica que siempre sabes dónde estás.

**Ejercicio 3** — tarjeta con group

Al pasar el puntero por la tarjeta, el título cambia de color y aparece una
flecha. Con `group`, sin JavaScript.

**Ejercicio 4** — modo oscuro

Aplica `dark:` a toda la aplicación. Cambia la preferencia del sistema y
comprueba. Anota qué contraste te costó más resolver.

---

**Cuando termines avísame — valido el Día 2.** ✅

---

## 🗓 DÍA 3 — `@theme` Y TOKENS DE DISEÑO

### 🎯 Objetivo
Personalizar el sistema desde CSS y entender qué es un token de diseño.

---

### 📖 El problema real

Nexus necesita su propio color de marca. `blue-600` es el azul de Tailwind, no el
de la empresa. Y lo estás repitiendo en veinte sitios.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Con variables CSS de la Semana 8:

```css
:root {
  --color-nexus: #2563eb;
}

.boton {
  background-color: var(--color-nexus);
}
```

Correcto, y la intuición es la buena. Pero no genera ninguna utilidad: seguirías
escribiendo CSS suelto para cada uso.

---

### 📖 `@theme` como solución

```css
@import "tailwindcss";

@theme {
  --color-nexus: oklch(62% 0.19 264);
  --color-alerta: oklch(65% 0.22 25);
  --font-display: "Inter", sans-serif;
  --radius-tarjeta: 0.75rem;
}
```

Con eso, Tailwind **genera** `bg-nexus`, `text-nexus`, `border-nexus`,
`font-display`, `rounded-tarjeta`.

Es tu intuición de variables CSS, más la generación automática de utilidades.

---

### 📖 Cómo funciona

El **prefijo** de la variable le dice a Tailwind qué familia generar:

| Prefijo | Genera |
|---|---|
| `--color-*` | `bg-*`, `text-*`, `border-*`, `ring-*` |
| `--font-*` | `font-*` |
| `--spacing-*` | `p-*`, `m-*`, `gap-*` |
| `--radius-*` | `rounded-*` |
| `--breakpoint-*` | prefijos responsive |

> ⚠ **La trampa del día:** `@theme` y `:root` no son intercambiables. Las dos
> definen variables CSS, pero solo `@theme` genera clases. Si defines
> `--color-nexus` dentro de `:root`, la variable existe pero `bg-nexus` **no
> existe** — y no da error, simplemente no aplica nada.

**Y al revés funciona:** todo lo definido en `@theme` queda disponible como
variable CSS normal, así que puedes usarlo con `var(--color-nexus)` en CSS suelto.

---

### 📖 Este es el cambio más grande de la v4

En Tailwind v3 todo esto vivía en `tailwind.config.js`:

```javascript
// v3 — ya no existe
module.exports = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: { extend: { colors: { nexus: "#2563eb" } } }
};
```

En v4 no hay archivo de configuración JavaScript. Si un tutorial te hace crearlo,
es de v3.

**Por qué cambió:** los tokens de diseño son valores, no lógica. Vivían en JS solo
porque en 2017 el CSS no tenía variables suficientemente buenas. Ahora las tiene.

---

### 📖 Qué es un token de diseño

Un valor con nombre que representa una **decisión**, no una apariencia.

```
❌ --color-azul-claro     nombra lo que se ve
✅ --color-primario       nombra para qué sirve
✅ --color-peligro
```

La diferencia importa el día que la marca cambia a verde: con el primer nombre
acabas con `--color-azul-claro: verde`.

---

### 📖 Mini-ejercicio de comprensión

Alguien define esto y `bg-marca` no funciona. ¿Por qué?

```css
:root {
  --color-marca: #2563eb;
}
```

---

### 🛠 EJERCICIOS DÍA 3

**Ejercicio 1** — paleta de Nexus

Define en `@theme` los colores de marca, uno de alerta y uno de éxito. Úsalos en
la aplicación.

**Ejercicio 2** — tokens semánticos

Nombra los colores por función, no por apariencia. Escribe en un comentario qué
decisión representa cada uno.

**Ejercicio 3** — colores por dificultad

Un token para cada nivel de dificultad. `EtiquetaDificultad` los usa.

**Ejercicio 4** — comprueba la trampa

Define un color en `:root` e intenta usarlo como utilidad. Muévelo a `@theme` y
compara. Documenta la diferencia.

---

**Cuando termines avísame — valido el Día 3.** ✅

---

### ⚠️ EL PUENTE: `@theme inline` — léelo antes del Día 4

Acabas de ver que `@theme` genera clases y `:root` no. Mañana instalas shadcn/ui,
y ahí esos dos mundos chocan.

**El problema:** shadcn/ui define sus colores como variables en `:root`, porque
necesita cambiarlos en tiempo de ejecución para el modo oscuro:

```css
:root {
  --primary: oklch(0.21 0.006 285.885);
  --foreground: oklch(0.141 0.005 285.823);
}

.dark {
  --primary: oklch(0.92 0.004 286.32);
  --foreground: oklch(0.985 0 0);
}
```

Por lo que aprendiste hoy, esas variables **no generan ninguna clase**. Escribes
`bg-primary` y no pasa nada. Sin error, sin advertencia: el elemento sale sin
fondo.

**La solución** es un `@theme` que no *define* valores, sino que *apunta* a las
variables de `:root`:

```css
@theme inline {
  --color-primary: var(--primary);
  --color-foreground: var(--foreground);
}
```

Ahora `bg-primary` existe como clase, y su valor sale de `--primary`, que cambia
solo al activar el modo oscuro.

**Qué hace la palabra `inline`:** sin ella, Tailwind resuelve el valor de la
variable en tiempo de compilación y lo congela — el modo oscuro dejaría de
funcionar. Con `inline`, deja la referencia `var(--primary)` viva en el CSS final,
de modo que se evalúa en el navegador.

```
@theme         → congela el valor    → el modo oscuro NO funciona
@theme inline  → mantiene var(...)   → el modo oscuro SÍ funciona
```

**Por qué te lo cuento ahora y no mañana:** `npx shadcn@latest init` genera este
bloque por ti. Si todo va bien, no lo vas a escribir nunca. Pero es la causa número
uno de "instalé shadcn y los colores no se aplican", y el fallo es **silencioso**.
Cuando te pase —a ti o a un compañero— vas a saber dónde mirar.

---

## 🗓 DÍA 4 — shadcn/ui

### 🎯 Objetivo
Entender qué es shadcn/ui y por qué no es una librería.

---

### 📖 El problema real

Nexus necesita un diálogo de confirmación antes de cancelar una reserva. Suena
simple: un cuadro con dos botones.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Un `useState` para abierto/cerrado, un div posicionado encima, un fondo oscuro.
Media hora.

---

### 📖 Por qué eso no alcanza

Un diálogo accesible necesita, además de verse:

```
· Atrapar el foco dentro mientras está abierto
· Devolver el foco al botón que lo abrió al cerrarse
· Cerrarse con Escape
· Bloquear el scroll del fondo
· Anunciarse correctamente a un lector de pantalla
· Los atributos ARIA correctos y sincronizados
```

Nada de eso se ve, y todo eso es la diferencia entre una aplicación usable y una
que excluye gente. Implementarlo bien es un día de trabajo y hay muchas formas
sutiles de equivocarse.

---

### 📖 shadcn/ui como solución

```bash
npx shadcn@latest add dialog
```

Y ahora lo importante:

> **shadcn/ui no es una librería. Es código que copias a tu proyecto.**

Ese comando **crea el archivo** `components/ui/dialog.tsx` dentro de tu
repositorio. No hay dependencia nueva. El archivo es tuyo: lo abres, lo lees, lo
modificas.

```
Librería tradicional (MUI, Chakra)   shadcn/ui
──────────────────────────────────   ────────────────────────────────
import { Button } from "libreria"    el archivo está en tu repositorio
lo actualiza npm                     lo actualizas tú si quieres
personalizar = pelear con la API     personalizar = editar el archivo
```

**El intercambio:** actualizar es manual. Si el proyecto arregla un bug, tienes
que traerlo tú. A cambio, ninguna actualización te rompe nada.

---

### 📖 Qué crea `init`

```
components.json      configuración del CLI
lib/utils.ts         la función cn()
app/globals.css      variables de color del tema
components/ui/       aquí van los componentes que agregues
```

---

### 📖 `cn()` — la función que vas a usar siempre

```typescript
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

Combina clases condicionalmente **y resuelve conflictos**:

```tsx
// ❌ quedan las dos clases; cuál gana depende del orden del CSS generado
className={`p-4 bg-white ${destacada ? "bg-yellow-100" : ""}`}

// ✅ cn detecta que las dos son background y deja la última
className={cn("p-4 bg-white", destacada && "bg-yellow-100")}
```

> ⚠ **Trampa:** `cn()` solo resuelve conflictos entre clases **de Tailwind**. Con
> clases propias de nombre arbitrario no puede saber que compiten.

Es también lo que permite personalizar un componente de shadcn desde fuera: le
pasas `className` y `cn()` decide bien.

---

### 📖 Léelos, no los uses a ciegas

Abre `components/ui/button.tsx`. Vas a reconocer casi todo: props tipadas, `cn()`
combinando clases, variantes por prop.

**Ese archivo es material de estudio.** Es código profesional resolviendo un
problema que ya entiendes, y está en tu repositorio para que lo leas.

---

### 📖 Mini-ejercicio de comprensión

¿Por qué shadcn/ui puede permitirse no tener versiones ni notas de cambios,
cuando cualquier librería normal las necesita?

---

### 🛠 EJERCICIOS DÍA 4

**Ejercicio 1** — inicializar

Corre `init` y agrega `button`, `card`, `badge`, `input`. Explora los archivos
que aparecieron.

**Ejercicio 2** — leer el código

Abre `button.tsx`. Escribe un comentario explicando cómo funcionan las variantes
y dónde aparece `cn()`.

**Ejercicio 3** — usar

Reemplaza los botones y tarjetas propios por los de shadcn. Compara el resultado
con lo que tenías.

**Ejercicio 4** — modificar

Agrega una variante propia al botón —por ejemplo `nexus`, con el color de marca
del Día 3— editando directamente el archivo.

Eso es lo que una librería tradicional no te deja hacer.

---

**Cuando termines avísame — valido el Día 4.** ✅

---

## 🗓 DÍA 5 — COMPONER Y DECIDIR

### 🎯 Objetivo
Combinar componentes en pantallas completas y decidir cuándo usarlos y cuándo no.

---

### 📖 El problema real

Ya tienes piezas sueltas. Falta que el catálogo, el detalle y el formulario se
vean como un mismo producto y no como tres pantallas de tres personas distintas.

---

### 📖 Composición, otra vez

Los componentes de shadcn están hechos para componerse — es lo de la Semana 11
aplicado a interfaz:

```tsx
<Card>
  <CardHeader>
    <CardTitle>{expedicion.nombre}</CardTitle>
    <CardDescription>{expedicion.tipo}</CardDescription>
  </CardHeader>
  <CardContent>
    <p>${expedicion.precioBase.toLocaleString("es-CL")}</p>
  </CardContent>
  <CardFooter>
    <Button>Ver detalle</Button>
  </CardFooter>
</Card>
```

No hay props booleanas tipo `mostrarPie`. Hay piezas que decides usar o no. Es
exactamente el patrón que en la Semana 11 aparecía como "código real".

---

### 📖 La frontera servidor/cliente sigue vigente

Un componente de shadcn que usa estado lleva `"use client"` **en su propio
archivo**. Eso significa que usarlo dentro de un Server Component está bien: la
frontera queda donde debe.

```tsx
// Server Component
export default async function Pagina() {
  const expediciones = await obtener();
  return (
    <div>
      {expediciones.map(function (expedicion) {
        return (
          <Card key={expedicion.id}>          {/* servidor, no tiene estado */}
            <CardContent>{expedicion.nombre}</CardContent>
          </Card>
        );
      })}
      <DialogoConfirmacion />                  {/* cliente, lo dice su archivo */}
    </div>
  );
}
```

Abre un componente de shadcn y mira si tiene `"use client"`. Eso te dice de qué
lado cae.

---

### 📖 Cuándo NO usar shadcn

```
✗ Para algo que resuelves con un div y tres utilidades
✗ Cuando necesitas exactamente un comportamiento distinto — modificar el archivo
  hasta que no se parezca al original tiene menos valor que escribirlo tú
✗ Agregar veinte componentes "por si acaso" — cada uno es código que mantienes
```

**La regla:** shadcn para lo que es difícil de hacer bien —accesibilidad,
teclado, foco, comportamiento de diálogos y selects—. Para lo demás, utilidades y
tus propios componentes.

---

### 📖 Consistencia visual

Tres cosas que hacen que un producto parezca uno solo:

```
· Espaciado de la misma escala en todas partes (no 13px aquí y 15px allá)
· Los mismos colores para las mismas funciones
· Tipografía con jerarquía clara: título, subtítulo, cuerpo, apoyo
```

Los tokens del Día 3 existen para esto. Si cada pantalla elige sus valores, no hay
sistema.

---

### 📖 Mini-ejercicio de comprensión

Necesitas un contenedor con borde y sombra para agrupar tres cifras del resumen.
¿`Card` de shadcn o un `div` con utilidades? Justifica con la regla de arriba.

---

### 🛠 EJERCICIOS DÍA 5

**Ejercicio 1** — catálogo con Card

Rehaz las tarjetas del catálogo componiendo `Card` y sus partes.

**Ejercicio 2** — diálogo de confirmación

`npx shadcn@latest add dialog`. Confirmación antes de cancelar una reserva.
Pruébalo solo con teclado: abrir, moverte, cerrar con Escape.

**Ejercicio 3** — formulario

Reconstruye el formulario de reserva con `Input`, `Label`, `Select` y `Button`.
Mantén la Server Action de la Semana 12 funcionando.

**Ejercicio 4** — decide y justifica

Lista cinco elementos de tu interfaz. Para cada uno decide shadcn o utilidades
propias, con una línea de justificación.

---

**Cuando termines avísame — valido el Día 5.** ✅

---

## 🗓 DÍA 6 — PROYECTO DE LA SEMANA

### 🏆 Nexus — Rediseño completo

> Nexus funciona: rutas, datos del servidor, mutaciones. Y se ve como un
> prototipo.
>
> Esta semana no agrega ni una función. Cambia solo la capa visual — y que eso
> sea posible sin tocar la lógica es la prueba de que estaba bien separada.

---

### 📋 Lo que debe hacer

**1. Sistema de diseño**
- Paleta de Nexus en `@theme`, con nombres semánticos
- Tokens de tipografía y radios
- Los mismos valores en toda la aplicación

**2. Todas las pantallas rediseñadas**
- Inicio, catálogo, detalle, reservas, operaciones
- Coherencia visual entre todas

**3. Responsive de verdad**
- Usable en 375px, 768px y 1440px
- El menú se adapta en móvil
- Ninguna tabla ni tarjeta se desborda

**4. Estados completos**
- `hover:` y `focus:` en todo lo interactivo
- Estado deshabilitado en el formulario mientras envía
- `loading.tsx` con esqueletos, no con texto

**5. shadcn donde aporta**
- Formulario con sus componentes
- Diálogo de confirmación para cancelar
- Al menos un componente con una variante propia añadida por ti

**6. Modo oscuro**
- Toda la aplicación, siguiendo la preferencia del sistema
- Contraste legible en ambos modos

---

### 📋 Requisitos técnicos

```
✅ Cero archivos .css propios más allá de globals.css
✅ Los colores de marca vienen de @theme, nunca escritos a mano
✅ Ningún valor arbitrario tipo w-[437px] sin justificación en comentario
✅ cn() para toda clase condicional
✅ Contraste suficiente en modo claro y oscuro
✅ La aplicación completa se puede navegar con teclado, con foco siempre visible
✅ La lógica de la Semana 12 sigue intacta
❌ Sin estilos en línea salvo valores calculados en ejecución
❌ Sin componentes de shadcn sin usar
```

El requisito de **navegación completa por teclado** es el que más se olvida y el
que más importa. Recorre la aplicación entera con Tab antes de darla por
terminada.

---

### 📋 Estructura

```
app/globals.css              @import + @theme
components/ui/               componentes de shadcn (generados)
componentes/                 los tuyos
lib/utils.ts                 cn()
```

---

### 💡 Las dos únicas pistas

**Pista 1** — Si un bloque de clases se repite en tres sitios, no lo copies: eso
es un componente. Ya sabes hacerlos desde la Semana 10.

**Pista 2** — Para los esqueletos de carga, `npx shadcn@latest add skeleton`.
Piensa qué forma debe tener el esqueleto para que la página no salte cuando
lleguen los datos reales.

---

### ✅ Criterios de aprobación

```
□ Corre sin errores ni advertencias
□ Usable y legible en 375px, 768px y 1440px
□ Modo oscuro completo y con contraste suficiente
□ Navegación completa con teclado y foco siempre visible
□ Los colores de marca salen de @theme
□ Al menos un componente de shadcn modificado por ti
□ Ninguna funcionalidad de la Semana 12 se rompió
□ Subido a GitHub con commit descriptivo
```

**Verificación:** abre la aplicación en el móvil real, no solo en las DevTools. El
emulador miente sobre el tamaño de los objetivos táctiles.

---

**Cuando termines el proyecto, avísame. Hacemos la validación semanal interactiva.** 🎯

---

## 🗂 ARCHIVOS A ENTREGAR

```
📁 semana-13/
└── nexus-web/          (el mismo proyecto de la Semana 12, rediseñado)
    ├── app/ · componentes/ · components/ui/ · lib/
    ├── package.json
    └── README.md
```

---

> ### 📘 PRÓXIMA SEMANA
> Pendiente de definir. El mapa curricular de la Semana 14 en adelante no existe
> todavía.
>
> Por la narrativa Nexus, lo siguiente sería base de datos y persistencia
> (Prisma + PostgreSQL). Hay que hacer la Fase 0 antes de generarlo.

---

*Semana 13 — Tailwind CSS v4 y shadcn/ui*
*Formato v4 — Constitución v1.3 · Protocolo QA con Fase 6b*
*Óscar — Full Stack Developer en formación 🇨🇱*
