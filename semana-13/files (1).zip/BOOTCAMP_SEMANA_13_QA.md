# 🔬 REPORTE QA — BOOTCAMP SEMANA 13

> Documento interno de auditoría. No es material de estudio.

---

```
ACTA DE GENERACIÓN
Fecha de generación: julio 2026
Semana en curso de Óscar al generar: 04 (PS-1 en curso)
Distancia estimada hasta el uso: ~8 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 7, 8
Referencias: Tailwind CSS v4.x · shadcn/ui CLI v4
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v1.3 (enmiendas 1-10)
```

---

## FASE 0 — DELIMITACIÓN CURRICULAR

### Dentro del alcance

```
- Modelo de utilidades: qué resuelve y qué cuesta
- Traducción CSS → Tailwind apoyada en la Semana 8
- Escala de espaciado y detección automática de clases
- Variantes: responsive, estados, group, dark
- @theme y tokens de diseño CSS-first
- shadcn/ui: qué es, init, add, propiedad del código
- cn() y resolución de conflictos entre clases
- Composición de componentes de shadcn
- Criterio para decidir shadcn vs utilidades propias
```

### Fuera del alcance, con razón documentada

| Excluido | Razón |
|---|---|
| `tailwind.config.js` | **No existe en v4.** Solo se menciona para que reconozca material antiguo |
| Plugins de Tailwind | Sin necesidad real en el proyecto |
| `@apply` | Contradice el modelo de utilidades; su uso extendido reproduce los problemas del CSS clásico |
| `next-themes` y botón de tema | Requiere estado de cliente e hidratación. `dark:` con preferencia del sistema cubre el objetivo sin librería |
| Animaciones (`tw-animate-css`) | Refinamiento visual, no competencia |
| Registries propios, monorepo, v0 | Casos de equipo/escala que no existen aquí |
| `--base` (Radix vs Base UI) | Decisión de arquitectura sin criterio todavía |
| Figma, bloques prefabricados | No aportan competencia |
| `next/font` | Corresponde a la semana de optimización |

### Prerrequisitos

```
Semana 8  → CSS, flexbox, grid, media queries, variables CSS  ✔ verificado
Semana 10 → componentes y props                                ✔ verificado
Semana 11 → composición de componentes                         ✔ verificado
Semana 12 → proyecto Next.js sin Tailwind                      ✔ verificado
```

**Dependencia crítica con la Semana 8.** Esta semana se apoya en ella todo el
tiempo: la tabla de traducción, el mobile-first, las variables CSS que preparan
`@theme`. Sin CSS previo, el alumno memorizaría clases sin entender qué producen.

La decisión de las Semanas 10 y 12 de excluir Tailwind se paga aquí: llega sobre
una base de CSS entendida y un proyecto que ya funciona.

---

## FASE 1 — INVESTIGACIÓN (tecnología viva de alto riesgo)

| Afirmación | Verificado | Impacto |
|---|---|---|
| Tailwind v4 **eliminó `tailwind.config.js`**; configuración CSS-first con `@theme` | julio 2026 | **Reescribió el Día 3 completo** |
| `@import "tailwindcss"` reemplaza las tres directivas `@tailwind` | julio 2026 | Bloque de setup |
| Detección de contenido automática; no hay array `content` | julio 2026 | Se elimina toda mención a configurar rutas |
| Motor Oxide; PostCSS y autoprefixer ya no van aparte | julio 2026 | Setup simplificado |
| Los tokens de `@theme` se exponen como variables CSS | julio 2026 | Día 3 |
| `@custom-variant` para modo oscuro por clase | julio 2026 | Cheat Sheet, marcado como opcional |
| shadcn CLI v4: `init` configura proyectos existentes | julio 2026 | Bloque de setup |
| shadcn copia archivos al proyecto; no es dependencia npm | julio 2026 | Concepto central del Día 4 |
| `init` crea `components.json`, `lib/utils.ts`, variables en el CSS global | julio 2026 | Día 4 |
| Con Tailwind v4 la config de tailwind va vacía en `components.json` | julio 2026 | Coherente con no crear config JS |
| Estilo `new-york` por defecto; `default` deprecado | julio 2026 | No se menciona el estilo antiguo |
| `toast` deprecado en favor de `sonner` | julio 2026 | No se enseña `toast` |
| `tailwindcss-animate` → `tw-animate-css` | julio 2026 | Fuera de alcance, registrado |

### Qué habría salido mal sin esta fase

De memoria habría escrito, con alta probabilidad:

```
✗ tailwind.config.js con content: [...]     → archivo que ya no existe
✗ @tailwind base/components/utilities       → sintaxis de v3
✗ instalar postcss y autoprefixer aparte    → innecesario y contraproducente
✗ theme.extend en JavaScript                → el mecanismo cambió por completo
✗ componentes de shadcn con forwardRef      → se eliminaron
```

Es el fallo de mayor superficie posible: el setup entero habría sido de v3, y el
Día 3 —que es el corazón de la personalización— habría enseñado un mecanismo
inexistente.

Segunda semana consecutiva en que la Fase 1 evita un error estructural, no
cosmético.

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ Las utilidades corresponden 1:1 a propiedades CSS
✔ La escala de espaciado: 1 = 0.25rem = 4px
✔ Las variantes responsive son mobile-first y aplican hacia arriba
✔ md: no significa "solo pantallas medianas"
✔ group / group-hover requiere la clase group en el ancestro
✔ dark: sigue la preferencia del sistema sin configuración
✔ @theme genera utilidades; :root solo define variables
✔ El prefijo de la variable determina la familia de utilidades
✔ El escáner busca cadenas completas: bg-${color}-500 no se genera
✔ shadcn copia archivos; no agrega dependencia de componentes
✔ cn() = twMerge(clsx(...)): condicional + resolución de conflictos
✔ twMerge solo resuelve conflictos entre clases de Tailwind
```

### Corrección aplicada durante esta fase

```
Formulación incorrecta (borrador):
  "@theme define las variables de tu tema"

Por qué era incorrecta:
  Es lo que también hace :root, y el alumno con ese modelo no puede
  explicar por qué su color definido en :root no genera bg-*. Describe
  el efecto visible y omite el mecanismo que importa.

Formulación corregida:
  "@theme no solo define variables: le dice a Tailwind que GENERE las
  utilidades correspondientes", con la trampa explícita @theme vs :root
  y un ejercicio que obliga a comprobar la diferencia.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ Terminología estable: "utilidad", "variante", "token", "componente"
✔ La Semana 8 se invoca explícitamente cinco veces (traducción, mobile-first,
   variables CSS, contraste, semántica)
✔ El Día 3 (tokens) alimenta al Día 4 (variante propia del botón) y al proyecto
✔ La composición de la Semana 11 se retoma en el Día 5 con Card
✔ La frontera servidor/cliente de la Semana 12 se retoma en el Día 5
✔ Cada día abre con un dolor concreto del proyecto existente
```

### Ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — setup, traducir tarjeta, catálogo grid | Proyecto D6 |
| D1 — probar el escáner | Ninguno. **Justificado:** demostración de mecanismo |
| D2 — responsive, estados, group, dark | Proyecto D6 |
| D3 — paleta, tokens semánticos, colores por dificultad | Proyecto D6 |
| D3 — comprobar `@theme` vs `:root` | Ninguno. **Justificado:** verificación de trampa |
| D4 — init, usar, modificar | Proyecto D6 |
| D4 — leer button.tsx | Ninguno. **Justificado:** lectura de código |
| D5 — Card, diálogo, formulario | Proyecto D6 |
| D5 — decidir y justificar | Ninguno. **Justificado:** ejercicio de criterio |

**Cero huérfanos sin justificar.**

---

## FASE 6b — CONFORMIDAD

```
□✔ Constitución Parte 3 — punto y coma, ===, nombres en español, toLocaleString
□✔ .prettierrc — semi true, tabWidth 2, comillas dobles, sin trailing comma
□✔ ESTADO_ROADMAP — la Semana 13 la anuncia el pie de la Semana 12: coincide
□✔ NEXUS_PROYECTO_NARRATIVA — capa visual del producto; sin anclaje a mes
□✔ Decisiones arquitectónicas — se trabaja sobre el proyecto anterior sin
     reescribir lógica; coherente con "se hereda lo que existe"
□✔ Bootcamps adyacentes — las Semanas 10 y 12 excluyeron Tailwind prometiendo
     que llegaría después. Esta cumple la promesa
```

**Deuda saldada verificada:** la Semana 10 dijo *"Tailwind entra cuando llegues a
Next.js"* y la Semana 12 dijo *"Tailwind entra en la Semana 13"*. Ambas se
cumplen. Sin esta semana, las dos exclusiones habrían quedado sin cobrar.

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS

```
RECHAZADA 1: "Tailwind reemplaza al CSS"

Razón: falso y peligroso. Produce el alumno que memoriza clases sin
entender qué generan, y que no puede depurar cuando algo no se ve como
espera. Tailwind ES CSS con otra sintaxis.

Reemplazo: la tabla de traducción explícita y la nota de alcance: "esta
semana no enseña CSS, enseña otra forma de escribir el de la Semana 8".
```

```
RECHAZADA 2: "Las utilidades son mejores que el CSS tradicional"

Razón: presenta como victoria lo que es un intercambio. El alumno no
desarrolla criterio y aplica utilidades donde no corresponde.

Reemplazo: los tres problemas concretos del CSS a escala (nombrar, no
poder borrar, acción a distancia) Y el costo admitido (el HTML se lee
peor), más la sección "cuándo NO usar Tailwind".
```

```
RECHAZADA 3: "shadcn/ui es una librería de componentes"

Razón: es exactamente lo que NO es, y el malentendido tiene consecuencia
práctica: el alumno buscaría cómo "actualizar la librería" o cómo
personalizar vía props en vez de editar el archivo que ya posee.

Reemplazo: "no es una librería, es código que copias", con la tabla
comparativa y el ejercicio de modificar un componente.
```

```
RECHAZADA 4: "cn() combina clases"

Razón: incompleto de forma engañosa. Si solo combinara, un template
literal bastaría. Omite lo único que la hace necesaria: resolver
conflictos.

Reemplazo: el ejemplo lado a lado del template literal fallando y cn()
funcionando, más la trampa de que solo aplica a clases de Tailwind.
```

### Ataques intentados sin hallazgo

```
✔ ¿Se enseña algo de Tailwind v3? No, tras la Fase 1. Se menciona solo
  para que reconozca material antiguo
✔ ¿La semana justifica el cambio de herramienta? El Día 1 abre con tres
  problemas concretos del CSS a escala, no con "es lo moderno"
✔ ¿Se trata la accesibilidad como adorno? Es el argumento central del Día 4
  y criterio de aprobación del proyecto
✔ ¿Se adelanta contenido de meses posteriores? Fuentes, animaciones y
  optimización quedan fuera con razón documentada
```

---

## VERIFICACIÓN DE LA ENMIENDA 10

| Sintaxis | Peso | Tratamiento |
|---|---|---|
| `@import "tailwindcss"` | LIGERA | Bloque perecedero + trampa (mezclar con `@tailwind` de v3) |
| `@theme` | **MEDIA** | Cuerpo del Día 3, con la trampa `@theme` vs `:root` |
| `cn()` | **MEDIA** | Cuerpo del Día 4, con el contraste frente al template literal |
| `@custom-variant` | LIGERA | Cheat Sheet, marcada como opcional |

```
✔ Ninguna PESADA
✔ Las dos MEDIA se enseñan en el cuerpo del día, no de contrabando
✔ Ninguna en el Día 1
✔ Ninguna en el mismo ejercicio donde se evalúa competencia nueva
```

---

## VERIFICACIÓN INDEPENDIENTE — 2026-07-31

Revisión posterior a la generación, contra búsqueda nueva, para comprobar que la
Fase 1 se ejecutó de verdad y no solo se declaró (Error 6 de la Constitución).

**Confirmado correcto:**

```
✔ Tailwind v4.x es la versión vigente
✔ tailwind.config.js ya no existe; la configuración vive en CSS con @theme
✔ @import "tailwindcss" reemplaza las tres directivas @tailwind de la v3
✔ La detección de archivos es automática, sin array content
✔ shadcn/ui soporta v4 y su init la detecta automáticamente
✔ tailwindcss-animate quedó deprecado en favor de tw-animate-css
✔ Los colores pasaron de HSL a OKLCH
```

**Omisión GRAVE detectada y CORREGIDA:**

```
El material no mencionaba @theme inline.

Es la causa número uno documentada de fallo al combinar Tailwind v4 con
shadcn/ui: shadcn define sus colores como variables en :root para poder
alternarlos en modo oscuro, y las variables de :root NO generan clases de
Tailwind. Sin un bloque @theme inline que las mapee, bg-primary y
text-foreground no aplican nada.

El fallo es SILENCIOSO — sin error de compilación ni advertencia en consola.
Es exactamente la clase de error identificada como lección transversal del
Mes 1: "no dio error" no significa "está bien".

Agravante pedagógico: el Día 3 del propio material enseña que @theme genera
clases y :root no. Sin el puente explícito, el alumno tiene las dos mitades
del problema y ninguna de la solución.

CORRECCIÓN APLICADA: sección nueva entre el Día 3 y el Día 4 explicando el
puente, con el detalle de qué hace la palabra `inline` (mantener viva la
referencia var(...) en vez de congelar el valor en compilación, que es lo
que permite que el modo oscuro funcione). Añadido también a la Cheat Sheet.
```

**Omisiones menores corregidas en la Cheat Sheet:**

```
· bg-gradient-to-r fue renombrado a bg-linear-to-r
· Los componentes de shadcn ya no usan forwardRef (React 19)
· El estilo por defecto pasó de "default" a "new-york"
· El componente toast quedó deprecado en favor de sonner
· Cada primitiva expone un atributo data-slot para estilarla
```

**No corregido, por estar fuera de alcance:** la utilidad `size-*` y el estado de
`@apply` en la v4. Sobre `@apply` hay fuentes que lo dan por desaconsejado y otras
que solo lo desalientan; no se afirma nada porque no pude confirmarlo con fuente
fiable. Registrado para verificar al regenerar el bloque perecedero.

---

## HALLAZGOS ABIERTOS

### 1. La semana no agrega funcionalidad

Cinco días de rediseño sin una función nueva. Riesgo de que se sienta como
trabajo secundario.

**Mitigación aplicada:** es la primera vez en cuatro semanas que el proyecto se ve
bien, lo que en sí mismo es recompensa. Y el marco es explícito: que se pueda
cambiar la capa visual sin tocar la lógica es la prueba de que estaba bien
separada.

**Sin resolver:** si en la práctica se hace pesado, se puede partir en dos —
Tailwind y shadcn en semanas distintas.

### 2. Accesibilidad exigida pero no enseñada

El proyecto exige navegación completa por teclado y contraste suficiente, pero no
hay ningún día dedicado a accesibilidad. Se apoya en `focus:` (Día 2) y en lo que
shadcn resuelve por defecto.

**Riesgo:** exigir un criterio que no se enseñó formalmente.

**Recomendación:** que la accesibilidad tenga su propia semana más adelante, o
como bloque dentro de la semana de calidad y testing. Registrado.

### 3. Modo oscuro sin conmutador

Se enseña `dark:` con preferencia del sistema. Un botón para cambiar el tema
requiere `next-themes` y manejo de hidratación, que se excluyó.

**Consecuencia:** Óscar no podrá ofrecer el conmutador que casi toda aplicación
real tiene. Es una carencia visible.

**Alternativa:** agregar `next-themes` como bloque corto en el Día 2. Se descartó
por Mínima Suficiencia, pero es el hallazgo con más probabilidad de revertirse.

### 4. PS-4 sigue sin generarse

Tercera semana consecutiva que lo registra (11, 12, 13). Ya son tres semanas
apoyadas en un proyecto que no existe.

**Recomendación:** generar PS-4 antes que cualquier semana nueva.

---

## ADVERTENCIA SOBRE LA VIGENCIA

```
MUY ALTO → comandos de instalación de Tailwind y del CLI de shadcn
MUY ALTO → si @theme sigue siendo el mecanismo de configuración
ALTO     → qué crea shadcn init y cómo se llaman los archivos
ALTO     → nombres de componentes y variantes por defecto
MEDIO    → utilidades concretas (Tailwind agrega, rara vez quita)
BAJO     → modelo de utilidades, tokens de diseño, propiedad del código
BAJO     → todo lo que sea CSS por debajo (flex, grid, contraste)
```

Tailwind pasó de v3 a v4 con un cambio total del modelo de configuración en un
solo salto de versión. Asumir que v4 sigue vigente dentro de ocho meses es
razonable, pero verificable en dos minutos: si `@theme` sigue en la documentación
oficial, el Día 3 vale.

---

*Reporte QA Semana 13 — julio 2026*
*Constitución v1.3 · Fases 0-8 incluyendo 6b*
