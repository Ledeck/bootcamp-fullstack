# 📄 CHEAT SHEET — SEMANA 13
## Tailwind CSS v4 · shadcn/ui · Sistema de diseño

> Léela completa antes de empezar el Día 1.
> Esta semana no enseña CSS nuevo. Enseña otra forma de aplicar el CSS que ya
> aprendiste en la Semana 8.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado y verificado: julio 2026
Referencias: Tailwind CSS v4.x · shadcn/ui CLI v4
REGENERAR antes de empezar la semana.
```

**Instalar Tailwind en el proyecto de la Semana 12:**

```bash
npm install tailwindcss @tailwindcss/postcss
```

En `app/globals.css`, una sola línea reemplaza toda la configuración antigua:

```css
@import "tailwindcss";
```

**Inicializar shadcn/ui:**

```bash
npx shadcn@latest init
```

Preguntas del asistente: color base → Neutral. El resto, valores por defecto.

```bash
npx shadcn@latest add button card badge input
```

**Lo que cambió en Tailwind v4 y aún verás mal en tutoriales:**

| Antes (v3) | Ahora (v4) |
|---|---|
| `tailwind.config.js` | **No existe.** Configuración en CSS con `@theme` |
| `@tailwind base; @tailwind components;` | `@import "tailwindcss";` |
| Array `content: [...]` con rutas | Detección automática de archivos |
| PostCSS + autoprefixer aparte | Incluido en el motor |
| `bg-gradient-to-r` | `bg-linear-to-r` |
| `tailwindcss-animate` | `tw-animate-css` |

**Lo que cambió en shadcn/ui con la v4:**

| Antes | Ahora |
|---|---|
| Colores en HSL | **OKLCH** |
| Componentes con `forwardRef` | Sin `forwardRef` (React 19 ya no lo necesita) |
| Estilo `default` | **`new-york`** es el estilo por defecto |
| Componente `toast` | **`sonner`** |
| — | Cada primitiva lleva un atributo `data-slot` para estilarla |

⚠ **La trampa número uno de esta combinación: `@theme inline`.**

shadcn define sus colores como variables en `:root` (para poder cambiarlos en modo
oscuro), y las variables de `:root` **no generan clases de Tailwind**. El puente es:

```css
@theme inline {
  --color-primary: var(--primary);
  --color-foreground: var(--foreground);
}
```

Sin ese bloque, `bg-primary` y `text-foreground` no hacen nada — sin error, sin
advertencia. La palabra `inline` es la que mantiene viva la referencia `var(...)`
en el CSS final; sin ella el valor se congela en compilación y el modo oscuro deja
de funcionar.

El `init` de shadcn lo genera por ti. Esto es para cuando falle.
| `tailwindcss-animate` | `tw-animate-css` |

Si un tutorial te hace crear `tailwind.config.js`, es de v3.

---

## 1. EL MODELO DE UTILIDADES

**Qué es:** Clases que aplican una sola propiedad CSS cada una.

```html
<div class="flex items-center gap-4 p-6 rounded-lg bg-white shadow">
```

Equivale exactamente a:

```css
display: flex;
align-items: center;
gap: 1rem;
padding: 1.5rem;
border-radius: 0.5rem;
background-color: white;
box-shadow: ...;
```

**No hay CSS nuevo que aprender.** `flex` es `display: flex`. `items-center` es
`align-items: center`. Todo lo de la Semana 8 sigue valiendo — cambia la forma de
escribirlo, no lo que hace el navegador.

**Traducción de lo que ya sabes:**

| CSS (Semana 8) | Tailwind |
|---|---|
| `display: flex` | `flex` |
| `flex-direction: column` | `flex-col` |
| `justify-content: space-between` | `justify-between` |
| `align-items: center` | `items-center` |
| `gap: 1rem` | `gap-4` |
| `padding: 1.5rem` | `p-6` |
| `margin-top: 2rem` | `mt-8` |
| `display: grid` | `grid` |
| `grid-template-columns: repeat(3, 1fr)` | `grid-cols-3` |
| `font-size: 1.125rem` | `text-lg` |
| `font-weight: 700` | `font-bold` |
| `color: #374151` | `text-gray-700` |
| `background-color: #fff` | `bg-white` |
| `border-radius: 0.5rem` | `rounded-lg` |
| `width: 100%` | `w-full` |

**La escala de espaciado:** el número es la unidad, no píxeles.
`1` = `0.25rem` = 4px. Así que `p-4` son 16px, `gap-2` son 8px, `mt-8` son 32px.

**Idea mental:** en vez de nombrar cosas (`.tarjeta-destacada`) y describirlas en
otro archivo, describes la cosa donde está.

---

## 2. POR QUÉ ESTO NO ES UN RETROCESO

La objeción evidente: *"esto es como los estilos en línea, que llevo desde la
Semana 8 sabiendo que están mal"*. No lo es, y las diferencias importan:

```
✓ Los estilos en línea no tienen media queries ni :hover. Tailwind sí.
✓ Los estilos en línea aceptan cualquier valor. Tailwind te limita a una
  escala coherente — no puedes poner 13px porque sí.
✓ El CSS final es un archivo compartido y cacheado, no atributos repetidos.
✓ Solo se genera el CSS de las clases que usas.
```

**Lo que sí pierdes:** el HTML se llena de clases y se lee peor. Es un
intercambio real, no una victoria limpia. La respuesta de Tailwind es que si un
bloque de clases se repite, eso es un **componente**, y ya sabes hacer
componentes.

---

## 3. RESPONSIVE

Prefijos que activan una utilidad a partir de cierto ancho:

```html
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3">
```

Una columna en móvil, dos desde `md`, tres desde `lg`.

| Prefijo | Desde |
|---|---|
| *(ninguno)* | siempre |
| `sm:` | 640px |
| `md:` | 768px |
| `lg:` | 1024px |
| `xl:` | 1280px |

**Es mobile-first, igual que lo de la Semana 8.** La clase sin prefijo es la base;
los prefijos la sobrescriben hacia arriba. No existe un prefijo para "solo móvil":
esa es la clase base.

> ⚠ **Error típico:** escribir `md:grid-cols-2` esperando que aplique *solo* en
> pantallas medianas. Aplica desde 768px **hacia arriba**, incluidas las grandes.

---

## 4. ESTADOS Y VARIANTES

Mismo mecanismo de prefijos:

```html
<button class="bg-blue-500 hover:bg-blue-600 focus:ring-2 disabled:opacity-50">
```

| Prefijo | Cuándo |
|---|---|
| `hover:` | puntero encima |
| `focus:` | elemento enfocado |
| `active:` | mientras se presiona |
| `disabled:` | atributo disabled |
| `dark:` | modo oscuro |
| `group-hover:` | al pasar sobre un ancestro con clase `group` |

**Se combinan:**

```html
<div class="md:hover:bg-gray-100">
```

**Modo oscuro** sin librerías, siguiendo la preferencia del sistema:

```html
<div class="bg-white text-gray-900 dark:bg-gray-900 dark:text-gray-100">
```

---

## 5. `@theme` — LA CONFIGURACIÓN CSS-FIRST

**El cambio más grande de v4.** La personalización ya no vive en JavaScript:

```css
@import "tailwindcss";

@theme {
  --color-nexus: oklch(62% 0.19 264);
  --color-alerta: oklch(65% 0.22 25);
  --font-display: "Inter", sans-serif;
  --radius-tarjeta: 0.75rem;
}
```

Eso genera automáticamente las utilidades `bg-nexus`, `text-nexus`,
`border-nexus`, `font-display`, `rounded-tarjeta`.

**Cómo funciona:** el prefijo de la variable le dice a Tailwind qué familia de
utilidades generar.

| Prefijo | Genera |
|---|---|
| `--color-*` | `bg-*`, `text-*`, `border-*`, `ring-*` |
| `--font-*` | `font-*` |
| `--spacing-*` | `p-*`, `m-*`, `gap-*` |
| `--radius-*` | `rounded-*` |
| `--breakpoint-*` | prefijos responsive |

> ⚠ **Trampa:** `@theme` no es lo mismo que `:root`. Las dos definen variables
> CSS, pero solo `@theme` hace que Tailwind **genere clases**. Si defines
> `--color-nexus` en `:root`, la variable existe pero `bg-nexus` no.

**Y al revés:** todos los tokens del tema quedan disponibles como variables CSS
normales, así que puedes usarlos en CSS suelto con `var(--color-nexus)`.

---

## 6. shadcn/ui — QUÉ ES Y QUÉ NO ES

**No es una librería de componentes.** No se instala como dependencia.

```bash
npx shadcn@latest add button
```

Ese comando **copia el archivo** `components/ui/button.tsx` dentro de tu
proyecto. Es tuyo. Lo abres, lo lees, lo modificas.

```
Librería tradicional (MUI, Chakra)   shadcn/ui
──────────────────────────────────   ────────────────────────────────
import { Button } from "libreria"    el archivo está en tu repositorio
lo actualiza npm                     lo actualizas tú si quieres
personalizar = pelear con la API     personalizar = editar el archivo
la versión la manda la librería      no hay versión que te rompa nada
```

**Qué te da realmente:**

```
✓ Accesibilidad resuelta (foco, teclado, ARIA) — es lo más difícil de hacer bien
✓ Estilos coherentes entre componentes
✓ Comportamiento probado en componentes complejos (diálogos, selects, calendarios)
```

**El intercambio:** actualizar es manual. Si el proyecto original arregla un bug,
tienes que traerlo tú.

**Archivos que crea `init`:**

```
components.json      configuración del CLI
lib/utils.ts         la función cn()
app/globals.css      variables de color del tema
components/ui/       aquí van los componentes que agregues
```

---

## 7. `cn()` — LA FUNCIÓN QUE VAS A USAR SIEMPRE

`shadcn init` crea `lib/utils.ts` con esto:

```typescript
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
```

Hace dos cosas: combina clases condicionalmente y **resuelve conflictos**.

```tsx
<div className={cn("p-4 bg-white", destacada && "bg-yellow-100")}>
```

**Por qué no basta un template literal:**

```tsx
// ❌ quedan las dos clases; cuál gana depende del orden en el CSS generado
className={`p-4 bg-white ${destacada ? "bg-yellow-100" : ""}`}

// ✅ cn detecta que ambas son background y deja la última
className={cn("p-4 bg-white", destacada && "bg-yellow-100")}
```

> ⚠ **Trampa:** `cn()` solo resuelve conflictos entre clases **de Tailwind**. Si
> mezclas clases propias con nombres arbitrarios, no puede saber que compiten.

Es también el mecanismo que permite personalizar un componente de shadcn desde
fuera: le pasas `className` y `cn()` decide correctamente.

---

## 8. SINTAXIS NUEVA DE ESTA SEMANA

### `@import "tailwindcss"` · peso LIGERO

Una línea que reemplaza a las tres directivas `@tailwind` de v3.

> ⚠ **Trampa:** si copias un tutorial de v3 y pones `@tailwind base;` junto con
> el `@import`, no falla ruidosamente — simplemente algunos estilos no aparecen.

### `@theme` · peso MEDIO

Ver sección 5. Definición, ejemplo y trampa (`@theme` vs `:root`) están ahí.

### `cn()` · peso MEDIO

Ver sección 7. La trampa es que solo resuelve conflictos entre clases de Tailwind.

### `@custom-variant` · peso LIGERO

Para modo oscuro manual con una clase en vez de la preferencia del sistema:

```css
@custom-variant dark (&:where(.dark, .dark *));
```

> ⚠ Solo lo necesitas si quieres un botón de cambio de tema. Con la preferencia
> del sistema, `dark:` funciona sin configurar nada.

---

## 9. CUÁNDO NO USAR TAILWIND

```
✗ Animaciones complejas con keyframes → CSS normal
✗ Estilos que dependen de valores calculados en ejecución → estilo en línea
✗ Un bloque de clases que se repite en cinco sitios → eso es un componente
```

**La señal de que algo va mal:** una línea con veinte clases. Casi siempre
significa que el elemento hace demasiado, no que Tailwind sea insuficiente.

---

## 10. TABLA DE DECISIÓN

| Necesito... | Uso |
|---|---|
| Estilar un elemento puntual | Utilidades directas |
| El mismo estilo en varios sitios | Un componente propio |
| Un botón, tarjeta, diálogo, select accesible | `shadcn add` |
| Un color o fuente de marca | `@theme` |
| Cambiar clases según una condición | `cn()` |
| Que se vea distinto en móvil | Prefijo `md:` / `lg:` |
| Modo oscuro | Prefijo `dark:` |

---

*Cheat Sheet Semana 13 — Tailwind CSS v4 y shadcn/ui*
*Prerrequisitos: Semana 8 (CSS, flexbox, grid, responsive) · Semanas 10-11 (componentes) · Semana 12 (Next.js)*
