# 🔬 REPORTE QA — BOOTCAMP SEMANA 14

> Documento interno de auditoría. No es material de estudio.
> Contiene el PRODUCTO de cada fase crítica, no su declaración (Enmienda 6).

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-07-31
Semana en curso de Óscar al generar: 05 (PS-1 completado)
Distancia estimada hasta el uso: ~8 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 7, 8
Fase 1 — fuentes: documentación oficial de Prisma (guías de Next.js, generadores,
         actualización a v7), changelog de versiones y discusión pública sobre el
         estado de la línea 7.x. Consultadas el 2026-07-31
Referencia: Prisma ORM 7.x · PostgreSQL 16+
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v1.3 (enmiendas 1-10)
```

---

## FASE 0 — DELIMITACIÓN CURRICULAR

Esta semana **no existía**. El pie de la Semana 13 la dejaba sin definir. La Fase 0
se ejecutó como parte de esta generación.

### Justificación del tema elegido

La Semana 12 (Día 5, Server Actions) instruye explícitamente: *"los datos pueden
vivir en un array en memoria del servidor; no hace falta base de datos"*. Eso deja
una aplicación que escribe datos y los pierde al reiniciar.

Ese es el dolor instalado, y determina el tema sin ambigüedad: **persistencia**.

Coincide además con la narrativa Nexus, que asigna base de datos y ORM al bloque
posterior a la interfaz.

### Dentro del alcance

```
- Por qué un array en memoria no es almacenamiento
- Qué es un ORM y qué problema resuelve
- Esquema de Prisma: modelos, tipos, atributos, relaciones 1-N
- Configuración de Prisma 7: generator, datasource, prisma.config.ts
- Migraciones: crear, versionar, reproducir en otra máquina
- Consultas: findMany, findUnique, where, orderBy, include, select, count
- Escritura: create, update, delete
- El singleton de PrismaClient y por qué es obligatorio en Next.js
- revalidatePath tras cada escritura
- Errores de Prisma con código (P2002, P2003)
- Agregaciones: aggregate, groupBy
- El problema N+1 y cómo detectarlo
```

### Fuera del alcance, con razón documentada

| Excluido | Razón |
|---|---|
| Transacciones (`$transaction`) | El Día 4 plantea el problema (dos reservas simultáneas por el último cupo) pero no lo resuelve. Deliberado: instala el dolor sin la solución. Ver hallazgo abierto 2 |
| `$queryRaw` | Sin problema que lo justifique. Mínima Suficiencia |
| Relaciones N-M | La asignación de guías podría modelarse así, pero se resuelve con dos 1-N. Añadir N-M duplicaría conceptos sin necesidad |
| Índices y optimización | Requieren un volumen de datos que este proyecto no tiene |
| Pool de conexiones en producción | Pertenece a la semana de despliegue |
| Prisma Accelerate | Producto comercial, fuera del stack objetivo |
| MongoDB / bases NoSQL | Los datos son claramente relacionales. Se menciona y se descarta con razón, en un párrafo |
| SQL directo como tema propio | Se muestra una comparación en la Cheat Sheet para contexto, no se enseña |

### Prerrequisitos

```
Semana 06 → async/await, manejo de errores          ✔ verificado
Semana 09 → TypeScript, tipos generados             ✔ verificado
Semana 12 → Server Components, Server Actions       ✔ verificado
              ⚠ dependencia FUERTE: el Día 1 parte de reproducir
                el fallo del array en memoria de esa semana
PS-1      → el cruce reservas ↔ expediciones         ✔ completado
              usado como ancla conceptual en 4 puntos del material
```

---

## FASE 1 — INVESTIGACIÓN (tecnología viva de alto riesgo)

Prisma tiene número de versión y cambió de arquitectura → búsqueda obligatoria.
Ejecutada en dos rondas, porque la primera devolvió información contradictoria.

### Ronda 1 — resultado ambiguo

Las fuentes mencionaban simultáneamente Prisma 6, Prisma 7 y Prisma 8. Insuficiente
para escribir material.

### Ronda 2 — resolución

| Afirmación | Verificado | Impacto en el contenido |
|---|---|---|
| **Prisma 7.x es la línea estable**: 7.0.0 (nov 2025), 7.3.0 (ene 2026) | 2026-07-31 | Define toda la referencia del material |
| Prisma 7 hizo el cliente **libre de Rust** por defecto | 2026-07-31 | Explica por qué hace falta un adaptador de driver |
| `prisma-client-js` está **deprecado**; el generador es `prisma-client` | 2026-07-31 | Corrige el error más extendido en tutoriales |
| El campo **`output` es obligatorio** en Prisma 7 | 2026-07-31 | Sin esto, `prisma generate` falla |
| El cliente ya **no se genera en `node_modules`** | 2026-07-31 | Cambia la ruta de import por completo |
| La URL de conexión va en **`prisma.config.ts`**, no en el datasource | 2026-07-31 | Archivo nuevo que el material explica |
| Se requiere **adaptador de driver** (`@prisma/adapter-pg` para PostgreSQL) | 2026-07-31 | Incluido en el singleton |
| El **singleton en `global`** es el patrón oficial para Next.js | 2026-07-31 | Sección propia en el Día 3 |
| "Prisma 8" / "prisma-next" es un **rediseño en acceso anticipado**, NO la versión de producción | 2026-07-31 | **Advertencia explícita** en el bloque perecedero |

### Qué habría salido mal sin esta fase

```
Sin la Fase 1, el material habría enseñado:

  generator client {
    provider = "prisma-client-js"      ← deprecado, romperá
  }
  import { PrismaClient } from "@prisma/client";   ← ruta que ya no existe
  datasource db { url = env("DATABASE_URL") }      ← movido a prisma.config.ts

Los tres son el patrón dominante en el material disponible en internet, porque
fue lo correcto durante años. Ninguno funciona en Prisma 7.

Y el alumno habría visto "Prisma 8" en el repositorio oficial, concluido que
es la versión a usar, e instalado un rediseño en acceso anticipado.
```

Este es el segundo caso documentado —tras `ts-node` en la Semana 09— donde lo que
envejece no es el concepto sino el setup. Refuerza la Enmienda 2.

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ Un array de módulo de Node vive en la memoria del proceso y se pierde al terminar
✔ En despliegues multiinstancia cada proceso tiene su propia copia del array
✔ Escrituras concurrentes sobre un archivo JSON producen condiciones de carrera
✔ El sistema de archivos es efímero en entornos serverless
✔ @relation genera una clave foránea real en PostgreSQL
✔ El lado "muchos" de una relación 1-N no crea columna
✔ Las migraciones se versionan; los datos no
✔ where filtra en la base; filter filtra en memoria tras traerlo todo
✔ Sin singleton, la recarga en caliente de Next.js agota el pool de conexiones
✔ global sobrevive a la recarga de módulos
✔ Sin revalidatePath la escritura ocurre pero la vista no se actualiza
✔ P2002 es violación de unicidad; P2003 es violación de clave foránea
✔ Un await de base de datos dentro de un bucle produce N+1
✔ Insertar una reserva antes que su expedición viola la clave foránea
```

### Corrección aplicada durante esta fase

```
Formulación incorrecta (borrador):
  "Prisma traduce tu código a SQL, así que no necesitas saber SQL"

Por qué era incorrecta:
  Genera dependencia ciega de la herramienta. El alumno que cree esto no
  entiende por qué un N+1 es caro, no sabe leer el SQL de una migración, y
  ante un problema de rendimiento no tiene dónde mirar.

Formulación corregida:
  "El ORM es el traductor. Tú hablas TypeScript; la base habla SQL."
  Más el ejercicio del Día 2 que obliga a ABRIR el SQL generado por la
  migración y leerlo.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ Terminología estable: "esquema", "modelo", "migración", "consulta", "cliente"
✔ El Día 1 instala el dolor; los Días 2-5 lo resuelven por partes
✔ El singleton aparece en el Día 3 con su problema, no como receta
✔ revalidatePath se enseña con el fallo silencioso, no como paso obligatorio ciego
✔ La tabla de traducción (Día 3) conecta explícitamente con PS-1
✔ Cada concepto de los Días 1-5 reaparece en el proyecto del Día 6
```

### Anclaje en trabajo previo de Óscar

El material referencia su propio historial en cinco puntos. Deliberado: la
competencia central de PS-1 fue el cruce por ID, y esta semana es la formalización
de ese mismo concepto.

```
· Día 1  → el caso del expedicionId inexistente que él mismo detectó en 3.3
· Día 2  → @relation cierra ese agujero por diseño (integridad referencial)
· Día 3  → tabla de traducción desde los métodos de array de PS-1
· Día 3  → ejercicio 4 verifica contra las anclas numéricas de PS-1
· Día 4  → P2003 es el error del caso que él planteó, ahora rechazado por la base
· Día 5  → groupBy reemplaza los dos reduce encadenados del punto 2.4
```

### Verificación de ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — documentar el fallo | Proyecto D6 (comparación final) |
| D1 — provocar condición de carrera | Ninguno. **Justificado:** demostración |
| D1 — decidir dónde alojar la base | Proyecto D6 |
| D1 — preparar `.env` y `.gitignore` | Proyecto D6, criterio de aprobación |
| D2 — esquema completo | Proyecto D6 |
| D2 — primera migración | Proyecto D6 |
| D2 — evolucionar el esquema | Proyecto D6 |
| D2 — provocar error de migración | Ninguno. **Justificado:** diagnóstico |
| D3 — singleton | Proyecto D6, requisito explícito |
| D3 — semilla | Proyecto D6, requisito explícito |
| D3 — migrar catálogo | Proyecto D6 |
| D3 — recalcular reporte | Proyecto D6 |
| D4 — migrar escrituras | Proyecto D6 |
| D4 — quitar revalidatePath | Ninguno. **Justificado:** experiencia del fallo |
| D4 — reglas de negocio | Proyecto D6 |
| D4 — provocar P2003 | Proyecto D6, criterio de aprobación |
| D5 — reporte con agregaciones | Proyecto D6, requisito explícito |
| D5 — contar consultas | Proyecto D6 (criterio de N+1) |
| D5 — encontrar y arreglar N+1 | Proyecto D6, criterio de aprobación |
| D5 — decidir base vs JavaScript | Ninguno. **Justificado:** criterio |

**Cero huérfanos sin justificar.**

---

## FASE 6b — AUDITORÍA DE CONFORMIDAD

```
□✔ Constitución Parte 3
     Punto y coma en todas las sentencias TS
     === y !== : sin ocurrencias de == o !=
     Nombres en español: expediciones, reservas, adaptador, globalParaPrisma
     .toLocaleString("es-CL"): heredado del proyecto

□✔ .prettierrc
     semi: true → conforme
     tabWidth: 2 → conforme
     singleQuote: false → conforme (comillas dobles en todo el material)

□✔ ESTADO_ROADMAP.md
     La Semana 14 no existía; esta generación la define
     Prerrequisitos verificados contra los documentos reales

□✔ NEXUS_PROYECTO_NARRATIVA.md
     Corresponde al módulo "Persistencia de Datos"
     Anclaje por punto de síntesis (PS-5), sin referencias a meses calendario

□✔ Decisiones arquitectónicas
     Se heredan DATOS de PS-1 y de la Semana 11, no código
     Inglés desactivado: respetado
     Sin for...in ni this

□✔ Bootcamps adyacentes
     El pie de la Semana 13 anticipaba "Prisma + PostgreSQL" → coincide
     La Semana 12 instala el dolor que esta resuelve → verificado leyendo
       el Día 5 de la Semana 12, que dice literalmente que los datos pueden
       vivir en un array en memoria
```

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS, con su razón

```
RECHAZADA 1: "Una base de datos es donde se guardan los datos de forma permanente"

Razón: verdadera y vacía. No explica por qué un archivo JSON no sirve, que es
la pregunta que el alumno se hace de verdad. Con esa definición, la respuesta
correcta a "¿por qué no un archivo?" sería "también es permanente".

Reemplazo adoptado: las cinco garantías (persistencia, concurrencia, consultas,
integridad, transacciones), con el Día 1 dedicado a demostrar que el archivo
JSON falla en cuatro de ellas — incluida una condición de carrera que el alumno
provoca él mismo.
```

```
RECHAZADA 2: "Prisma traduce tu código a SQL, así que no necesitas saber SQL"

Razón: produce dependencia ciega. Ver Fase 4.

Reemplazo adoptado: el ORM como traductor, más el ejercicio de abrir y leer el
SQL de la migración.
```

```
RECHAZADA 3: "El singleton evita crear muchos clientes de Prisma"

Razón: describe QUÉ hace sin decir por qué importa. El alumno lo copia como
receta y no lo entiende. Cuando aparezca "too many clients already" en otro
contexto, no sabrá relacionarlo.

Reemplazo adoptado: explicar el mecanismo completo — recarga en caliente de
Next.js, un cliente nuevo por recarga, pools que no se cierran, y el error
concreto que produce. Más el ejercicio de guardar diez veces y comprobar.
```

```
RECHAZADA 4: "Usa revalidatePath después de escribir"

Razón: instrucción sin causa. Se convierte en superstición: el alumno lo pone
en todas partes por si acaso, o lo olvida y no sabe dónde mirar.

Reemplazo adoptado: el Día 4 hace que lo quite a propósito, vea la lista sin
actualizar, y compruebe en prisma studio que el dato SÍ se guardó. El fallo
silencioso enseña mejor que la regla.
```

```
RECHAZADA 5: "Las agregaciones son más rápidas"

Razón: afirmación de rendimiento no verificable por el alumno, con 12 registros
donde la diferencia es imperceptible. Produce culto al patrón.

Reemplazo adoptado: explicar DÓNDE ocurre el trabajo (traer 500.000 filas para
descartar 799.992 vs. pedir 8), más una sección "cuándo NO usar agregaciones"
que da permiso explícito para calcular en JavaScript cuando corresponde.
```

### Ataques intentados sin hallazgo

```
✔ ¿Algún día introduce la solución antes del dolor? El Día 1 es enteramente
  dolor, sin solución
✔ ¿Se enseña algún patrón deprecado? Verificado contra Fase 1: el material usa
  prisma-client, output obligatorio y prisma.config.ts
✔ ¿Las secciones "cuándo NO" tienen peso real? Presentes en agregaciones y en
  la elección de dónde alojar la base
✔ ¿El proyecto es verificable objetivamente? Sí: las anclas numéricas de PS-1
  y la prueba de borrar la base y reconstruirla
```

---

## VERIFICACIÓN DE LA ENMIENDA 10 — SINTAXIS NUEVA POR PESO

| Sintaxis | Peso | Justificación | Entrega |
|---|---|---|---|
| Lenguaje de esquema de Prisma | **MEDIA** | Lenguaje propio, ni JS ni SQL. Se enseña en el cuerpo del Día 2, no de contrabando | Definición + ejemplos + trampa (editar no basta, hay que migrar y generar) |
| `revalidatePath()` | **LIGERA** | Una llamada con un string | Definición + ejemplo + trampa (ruta, no URL; varias rutas si aplica) |
| `global as unknown as` | **LIGERA** | Casteo de tipo en un caso acotado | Definición + ejemplo + trampa (es una excepción legítima, no permiso general para `as`) |

```
✔ Ninguna PESADA introducida de contrabando
✔ Las tres cumplen las condiciones de admisión de la Enmienda 9
✔ Ninguna en el Día 1
✔ Ninguna en el mismo ejercicio donde se evalúa competencia nueva
```

---

## HALLAZGOS ABIERTOS

### 1. Dependencia fuerte de la Semana 12 — y de PS-4

El Día 1 pide reproducir el fallo del array en memoria. Eso exige una aplicación
con Server Actions funcionando, es decir, la Semana 12 completada.

Y la Semana 12 a su vez extiende trabajo que asume PS-4, que **sigue sin
generarse**. Es la tercera semana consecutiva que lo asume (11, 12, 14).

**Recomendación:** generar PS-4 antes que cualquier semana nueva. Es la deuda más
antigua del sistema.

### 2. Las transacciones quedan fuera, y el material lo señala

El mini-ejercicio del Día 4 plantea el problema: dos usuarios reservan los últimos
cupos simultáneamente, la validación de ambos pasa, y se sobrevende.

El material **no da la solución**. Es deliberado —instalar el dolor para que
`$transaction` tenga sentido cuando llegue— pero deja una pregunta abierta sin
respuesta, lo que puede frustrar.

**Opciones:** (a) dejarlo así y resolverlo en una semana futura; (b) añadir una
nota de "esto se resuelve con transacciones, lo verás más adelante"; (c) incluir
transacciones en esta semana.

Recomendación: **(b)**. Cuesta dos líneas y evita la sensación de cabo suelto sin
ampliar el alcance.

### 3. La elección de base de datos no está resuelta

El material recomienda una base alojada por el escenario de dos laptops, pero no
elige proveedor. Deliberado: los proveedores y sus capas gratuitas cambian, y fijar
uno hoy sería contenido perecedero adicional.

**Consecuencia:** Óscar tiene que decidir y configurar por su cuenta el Día 1. Si
eso genera fricción, conviene añadir una guía paso a paso al regenerar el bloque
perecedero.

### 4. El singleton depende de detalles de Prisma 7

El código del singleton usa `PrismaPg` y la ruta de import generada. Ambos son
específicos de la versión y del `output` configurado. Si Prisma 8 cambia el modelo
de adaptadores —y el rediseño "prisma-next" sugiere que podría—, ese bloque queda
obsoleto entero.

Está dentro del bloque perecedero, pero conviene señalarlo: **es el fragmento de
código más frágil de todo el bootcamp.**

---

## ADVERTENCIA SOBRE LA VIGENCIA

Generado en julio de 2026 para usarse aproximadamente en marzo de 2027.

```
CRÍTICO → nombres de paquete y comandos de instalación
CRÍTICO → el código del singleton (adaptador + ruta de import generada)
CRÍTICO → la sintaxis del generador y de prisma.config.ts
ALTO    → el estado de "prisma-next" / Prisma 8. Si para entonces es estable,
          esta semana necesita revisión mayor, no solo regeneración del setup
MEDIO   → códigos de error de Prisma (P2002, P2003)
BAJO    → modelos, relaciones, migraciones como CONCEPTOS
BAJO    → el problema N+1, la diferencia entre where y filter
BAJO    → por qué un array en memoria no es almacenamiento
```

**Verificar sin excepción antes de usar:** el bloque perecedero completo, y si
sigue siendo Prisma 7 la versión recomendada para producción.

Nota de precedencia registrada en el propio material: **si `npx prisma init`
genera algo distinto de lo que describe el bootcamp, gana lo que genere la
herramienta.**

---

*Reporte QA Semana 14 — 2026-07-31*
*Constitución v1.3 · Fases 0-8 incluyendo 6b*
