# 📄 CHEAT SHEET — SEMANA 14
## Persistencia · PostgreSQL · Prisma ORM

> Léela completa antes de empezar el Día 1.
> Esta semana resuelve el problema que dejó abierto la Semana 12: los datos que
> escribes desaparecen.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado y verificado: julio 2026
Referencia: Prisma ORM 7.x  ·  PostgreSQL 16+
REGENERAR antes de empezar la semana.
```

### Estado de versiones — importante

```
Prisma 7.x es la línea ESTABLE y recomendada para producción.
  · 7.0.0 — noviembre 2025 — cliente sin Rust por defecto
  · 7.3.0 — enero  2026

⚠ En el repositorio de GitHub verás menciones a "Prisma 8" y a "prisma-next".
  Eso es un rediseño en acceso anticipado, escrito completamente en TypeScript.
  NO es la versión que debes usar. Prisma confirmó que la 7 sigue siendo la
  recomendada para producción.
```

### Instalación

```bash
npm install prisma --save-dev
npm install @prisma/client @prisma/adapter-pg
npx prisma init
```

⚠ **Verifica los nombres de paquete contra la guía oficial de inicio rápido antes
de ejecutar esto.** Prisma 7 reorganizó cómo se distribuye el cliente y los nombres
pueden haber cambiado. Si `npx prisma init` genera algo distinto de lo que describe
este material, gana lo que genere la herramienta.

### Dónde poner la base de datos

Tienes dos laptops que sincronizas por GitHub. Eso decide la elección:

```
✅ RECOMENDADO — PostgreSQL alojado con capa gratuita
   (Prisma Postgres, Neon, Supabase)
   Una sola base de datos accesible desde las dos máquinas.
   Sin instalación. La cadena de conexión va en .env

⚠ ALTERNATIVA — PostgreSQL local con Docker
   Más control, pero son DOS bases de datos distintas: una en cada
   laptop. Los datos no se sincronizan solos.

❌ EVITAR — instalar PostgreSQL directamente en el sistema
   Fricción de configuración que no aporta a lo que aprendes esta semana
```

**Regla que no se negocia:** el archivo `.env` **nunca** se sube a GitHub. Verifica
que esté en `.gitignore` antes del primer commit.

---

## 1. POR QUÉ UNA BASE DE DATOS

En la Semana 12 escribiste datos con Server Actions, en un array del servidor:

```typescript
const reservas = [];

export async function crearReserva(datos) {
  reservas.push(datos);
}
```

Funcionaba en desarrollo. Y falla por tres motivos:

```
1. Se pierde al reiniciar. Cada npm run dev empieza de cero.
2. En producción no hay "un servidor". Hay varios, cada uno con su
   propia copia del array. El usuario crea una reserva, recarga, y
   le responde otro servidor que no la tiene.
3. No hay consultas. Filtrar 8 expediciones con filter está bien;
   filtrar 800.000 registros cargándolos todos en memoria, no.
```

**Idea mental:** un array vive mientras el proceso viva. Una base de datos vive
aunque todo lo demás se apague.

---

## 2. QUÉ ES UN ORM

Un ORM traduce entre tu código y las tablas de la base de datos.

```typescript
// Sin ORM — SQL escrito a mano
const resultado = await db.query(
  "SELECT * FROM expediciones WHERE tipo = $1 ORDER BY precio_base ASC",
  [tipo]
);
// resultado.rows es any[] — TypeScript no sabe qué hay adentro

// Con Prisma
const expediciones = await prisma.expedicion.findMany({
  where: { tipo: tipo },
  orderBy: { precioBase: "asc" }
});
// expediciones es Expedicion[] — tipado, autocompletado, verificado
```

**Lo que ganas:** tipos generados desde tu esquema, autocompletado real,
migraciones versionadas, y errores detectados al compilar en vez de en producción.

**Lo que pagas:** una capa más que aprender, y consultas muy complejas que a veces
se expresan mejor en SQL directo.

**Idea mental:** el ORM es el traductor. Tú hablas TypeScript; la base habla SQL.

---

## 3. EL ESQUEMA

Un solo archivo describe toda tu base de datos.

```prisma
// prisma/schema.prisma

generator client {
  provider = "prisma-client"
  output   = "../src/generated/prisma"
}

datasource db {
  provider = "postgresql"
}

model Expedicion {
  id           String   @id
  nombre       String
  tipo         String
  duracionDias Int
  precioBase   Int
  cupoMaximo   Int
  dificultad   String
  creadaEn     DateTime @default(now())

  reservas     Reserva[]
}

model Reserva {
  id           String   @id @default(cuid())
  cliente      String
  personas     Int
  estado       String   @default("pendiente")
  metodoPago   String
  creadaEn     DateTime @default(now())

  expedicionId String
  expedicion   Expedicion @relation(fields: [expedicionId], references: [id])
}
```

### Lo que cambió en Prisma 7 — y verás mal en tutoriales

| Antes (Prisma 6) | Ahora (7.x) |
|---|---|
| `provider = "prisma-client-js"` | `provider = "prisma-client"` |
| `output` era opcional | **`output` es OBLIGATORIO** |
| Se generaba en `node_modules` | Se genera donde tú digas, como código tuyo |
| `import { PrismaClient } from "@prisma/client"` | `import { PrismaClient } from "@/generated/prisma/client"` |
| `url = env("DATABASE_URL")` en el datasource | La URL va en `prisma.config.ts` |
| Motor de consultas en Rust | Cliente TypeScript puro + adaptador de driver |

**Si un tutorial escribe `prisma-client-js` o importa de `@prisma/client`, es
anterior a noviembre de 2025.**

### Configuración

```typescript
// prisma.config.ts
import { defineConfig, env } from "prisma/config";
import "dotenv/config";

export default defineConfig({
  schema: "prisma/schema.prisma",
  migrations: {
    path: "prisma/migrations"
  },
  datasource: {
    url: env("DATABASE_URL")
  }
});
```

---

## 4. TIPOS Y ATRIBUTOS DEL ESQUEMA

```prisma
String      texto
Int         entero
Float       decimal
Boolean     true/false
DateTime    fecha y hora
Json        estructura arbitraria

String?     el ? lo hace OPCIONAL (puede ser null)
String[]    lista
```

```prisma
@id                    clave primaria
@default(cuid())       identificador único generado
@default(now())        fecha actual al crear
@unique                no se puede repetir
@updatedAt             se actualiza sola en cada modificación
@relation(...)         define la relación con otro modelo
```

**Error típico:** olvidar `?` en un campo que a veces no tiene valor. La migración
falla si ya hay filas sin ese dato, y el mensaje habla de una restricción NOT NULL.

---

## 5. RELACIONES

Una expedición tiene muchas reservas. Se escribe en los dos modelos:

```prisma
model Expedicion {
  id       String    @id
  reservas Reserva[]              // lado "muchos" — no crea columna
}

model Reserva {
  expedicionId String                                       // la columna real
  expedicion   Expedicion @relation(fields: [expedicionId], references: [id])
}
```

**Lo que importa entender:** solo `Reserva` tiene una columna nueva en la tabla —
`expedicionId`. El campo `reservas` de `Expedicion` no existe como columna: es la
forma en que Prisma te deja navegar la relación al revés.

Esto es exactamente el cruce por ID que hiciste a mano en PS-1. La diferencia es
que ahora la base de datos **garantiza** que el `expedicionId` apunta a una
expedición real. Aquel caso que planteaste —una reserva con un id inexistente— la
base de datos lo rechaza.

Eso se llama **integridad referencial**.

---

## 6. MIGRACIONES

```bash
npx prisma migrate dev --name descripcion_del_cambio
```

Compara tu esquema con la base de datos, genera el SQL de la diferencia, lo
aplica, y regenera el cliente.

```bash
npx prisma migrate dev      crear y aplicar una migración (desarrollo)
npx prisma generate         regenerar el cliente sin tocar la base
npx prisma studio           interfaz visual para ver y editar datos
npx prisma db seed          poblar con datos iniciales
```

**`prisma studio` es tu mejor herramienta de depuración esta semana.** Abre una
tabla y ves exactamente qué hay.

> ⚠ **Trampa:** las migraciones se versionan y se suben a GitHub. Los datos no.
> Al clonar en tu otra laptop tienes el esquema, pero la base está vacía si es
> local. Por eso conviene una base alojada.

---

## 7. CONSULTAR

```typescript
// todos
const todas = await prisma.expedicion.findMany();

// uno por id — devuelve null si no existe
const una = await prisma.expedicion.findUnique({
  where: { id: "EXP001" }
});

// filtrar y ordenar
const trekking = await prisma.expedicion.findMany({
  where: { tipo: "trekking" },
  orderBy: { precioBase: "asc" }
});

// varias condiciones
const caras = await prisma.expedicion.findMany({
  where: {
    dificultad: "alta",
    duracionDias: { lte: 3 }
  }
});

// traer la relación
const conReservas = await prisma.expedicion.findMany({
  include: { reservas: true }
});

// solo algunos campos
const nombres = await prisma.expedicion.findMany({
  select: { id: true, nombre: true }
});

// contar
const cuantas = await prisma.reserva.count({
  where: { estado: "confirmada" }
});
```

**Operadores de comparación:**

```
equals  gt  gte  lt  lte  in  notIn  contains  startsWith  endsWith
```

`lte` es "menor o igual" — el mismo `<=` de 1.4 en PS-1.

---

## 8. ESCRIBIR

```typescript
// crear
const nueva = await prisma.reserva.create({
  data: {
    cliente: "Carlos Mendoza",
    personas: 2,
    estado: "confirmada",
    metodoPago: "tarjeta",
    expedicionId: "EXP001"
  }
});

// actualizar
await prisma.reserva.update({
  where: { id: reservaId },
  data: { estado: "cancelada" }
});

// borrar
await prisma.reserva.delete({
  where: { id: reservaId }
});

// varios a la vez
await prisma.reserva.createMany({ data: listaDeReservas });
```

---

## 9. EL SINGLETON — obligatorio en Next.js

```typescript
// src/lib/prisma.ts
import { PrismaClient } from "@/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";

const globalParaPrisma = global as unknown as { prisma?: PrismaClient };

const adaptador = new PrismaPg({
  connectionString: process.env.DATABASE_URL
});

const prisma = globalParaPrisma.prisma || new PrismaClient({ adapter: adaptador });

if (process.env.NODE_ENV !== "production") {
  globalParaPrisma.prisma = prisma;
}

export default prisma;
```

**Por qué hace falta:** en desarrollo, Next.js recarga los módulos en caliente cada
vez que guardas. Sin este patrón, cada recarga crea un `PrismaClient` nuevo con su
propio pool de conexiones. A los pocos minutos la base rechaza conexiones con
*"too many clients already"*.

Guardarlo en `global` hace que sobreviva a la recarga.

**Nunca instancies `new PrismaClient()` en otro sitio.** Siempre importas este.

---

## 10. USARLO EN NEXT.JS

En un Server Component, consultas directo:

```typescript
import prisma from "@/lib/prisma";

export default async function PaginaExpediciones() {
  const expediciones = await prisma.expedicion.findMany({
    orderBy: { precioBase: "asc" }
  });

  return <Lista expediciones={expediciones} />;
}
```

Sin API, sin `fetch`, sin estado de carga. Es lo mismo que hiciste en la Semana 12,
cambiando el array por una consulta.

En una Server Action, escribes y refrescas:

```typescript
"use server";

import prisma from "@/lib/prisma";
import { revalidatePath } from "next/cache";

export async function crearReserva(datos: DatosReserva) {
  await prisma.reserva.create({ data: datos });

  revalidatePath("/reservas");
}
```

> ⚠ **Sin `revalidatePath`, la escritura funciona pero la pantalla no cambia.**
> Next.js sigue mostrando la versión anterior. El dato está en la base y el usuario
> no lo ve — un fallo silencioso más.

---

## 11. SINTAXIS NUEVA DE ESTA SEMANA

### El lenguaje de esquema de Prisma · peso MEDIO

No es JavaScript ni SQL: es un lenguaje propio. Se enseña en el cuerpo del Día 2.

> ⚠ **Trampa:** el esquema es la fuente de verdad, pero **no basta con editarlo**.
> Todo cambio necesita `prisma migrate dev` para llegar a la base, y
> `prisma generate` para llegar a los tipos. Si editas el esquema y tu código sigue
> viendo los tipos viejos, es que falta generar.

### `revalidatePath()` · peso LIGERO

Le dice a Next.js que los datos de una ruta cambiaron.

```typescript
revalidatePath("/reservas");
```

> ⚠ **Trampa:** recibe la ruta, no la URL completa. `"/reservas"`, no
> `"http://localhost:3000/reservas"`. Y si el dato aparece en varias rutas, hay que
> revalidarlas todas.

### `global` para el singleton · peso LIGERO

```typescript
const globalParaPrisma = global as unknown as { prisma?: PrismaClient };
```

> ⚠ **Trampa:** ese doble casteo `as unknown as` existe porque TypeScript no sabe
> que `global` puede tener una propiedad `prisma`. Es un caso legítimo de forzar el
> tipo — de los pocos. No lo tomes como permiso general para usar `as`.

---

## 12. FUERA DE ALCANCE ESTA SEMANA

```
Transacciones ($transaction)
Consultas SQL directas ($queryRaw)
Relaciones muchos-a-muchos
Índices y optimización
Pool de conexiones en producción
Prisma Accelerate
```

Todo eso llega cuando tengas el problema que resuelven.

---

*Cheat Sheet Semana 14 — Prisma y PostgreSQL*
*Prerrequisitos: Semana 06 (async/await) · Semana 09 (TypeScript) · Semana 12 (Server Components y Server Actions)*
