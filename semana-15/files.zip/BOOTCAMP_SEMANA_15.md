# 📘 BOOTCAMP SEMANA 15
## Generación de Documentos · PDF · Puppeteer · Formatos Chilenos

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-08-05
Semana en curso de Óscar al generar: 05 (en curso)
Distancia estimada hasta el uso: ~9 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 7, 8
Fase 1 — PARCIAL. Ver el reporte QA, sección "INCIDENTE DE FASE 1".
         Fuentes reales consultadas 2026-08-05: guías de Puppeteer + Node
         (RisingStack, DocuPotion, TestMu), análisis comparativo de
         chrome-headless-shell (pdf4.dev, mayo 2026).
         NO se verificó el número de versión vigente de Puppeteer.
Referencia: Node 18+ · versión de Puppeteer SIN VERIFICAR
Bloque perecedero: ALTO RIESGO — regenerar sí o sí antes de usar
Constitución aplicada: v2.0 (enmiendas 1-17)
```

---

> **Antes de empezar:** Recibe el Cheat Sheet de la semana por partes,
> tema a tema, como guion de la clase de activación.
> **Recuerda:** cuando termines cada día, avísame para validar.

---

## ⚠️ NOTAS DE ALCANCE

**Esta semana no agrega funcionalidad nueva al sistema Nexus.**
Agrega un canal de salida: los datos que ya están en la base de datos
salen como documentos descargables.

**El escenario:** TerraMater necesita enviar comprobantes a sus clientes,
cotizaciones formales y certificados de participación. Hasta ahora todo
vivía en pantalla. Un PDF es lo que hace que un registro digital se
convierta en un documento.

**Prerrequisito real:** tener la Semana 14 completada. Esta semana lee
datos de Prisma y los convierte en documentos. Sin la base de datos, no
hay datos reales que documentar.

---

## 🗓 DÍA 1 — POR QUÉ PDF Y CÓMO FUNCIONA PUPPETEER

### 🎯 Objetivo
Entender qué hace Puppeteer, por qué un Route Handler y no una Server
Action, y generar el primer PDF funcionando.

---

### 📖 El problema real

Tienes una reserva en la base de datos. El cliente quiere llevarla consigo.

Un registro en pantalla no viaja. Un PDF sí: se descarga, se imprime, se
adjunta a un correo, se guarda en el celular.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Tienes Server Actions que escriben datos y las usas para casi todo. El
primer instinto es hacer una Server Action que devuelva el PDF.

---

### 📖 Por qué esa solución no funciona

Las Server Actions están diseñadas para devolver datos — objetos, strings,
resultados de operaciones. React los maneja.

Un PDF es diferente. Es un archivo binario que necesita headers HTTP
específicos para que el navegador lo reconozca y lo descargue:

```
Content-Type: application/pdf
Content-Disposition: attachment; filename="reserva.pdf"
```

Una Server Action no puede devolver una respuesta HTTP con esos headers.
Solo puede devolver datos que React serializa.

Para devolver un archivo, necesitas un **Route Handler** — el equivalente
de un endpoint de API dentro de Next.js.

---

### 📖 Cómo funciona Puppeteer

La idea es sorprendentemente directa:

> Puppeteer abre Chrome en modo invisible, carga tu HTML como si fuera una
> página web, y la "imprime" como PDF.

El resultado es exactamente lo que obtendrías si el usuario abriera esa
página en Chrome y usara Ctrl+P → Guardar como PDF.

```typescript
import puppeteer from "puppeteer";

// Puppeteer corre headless por defecto — no hace falta la opción
const browser = await puppeteer.launch();
const pagina = await browser.newPage();

await pagina.setContent("<h1>Hola</h1>", { waitUntil: "domcontentloaded" });

const pdfBuffer = await pagina.pdf({ format: "A4", printBackground: true });

await browser.close();
```

**Por qué `printBackground: true`:** sin él, todos los colores de fondo
desaparecen. El PDF sale en blanco y negro aunque el HTML tenga colores.

**Por qué cerrar el browser siempre:**

```typescript
try {
  // ... generar PDF
} finally {
  await browser.close();
}
```

Sin el `finally`, si algo falla a la mitad, el proceso de Chrome queda
abierto. Con varios usuarios generando documentos, acabas con decenas de
instancias consumiendo memoria.

---

### 📖 El flujo completo

```
[Botón "Descargar"] (Client Component)
   ↓ fetch POST
[Route Handler] /api/documentos/reserva
   ↓ busca datos en Prisma
   ↓ genera HTML con los datos
   ↓ Puppeteer HTML → PDF
   ↓ devuelve el buffer con headers correctos
[Navegador] descarga el archivo
```

Cuatro pasos, cada uno haciendo lo que sabe: el cliente hace fetch, el
Route Handler lee datos y genera el PDF, el navegador descarga.

---

### 📖 Errores frecuentes del Día 1

```typescript
// ❌ Server Action — no puede devolver un archivo binario con headers
export async function generarPdf() {
  const pdf = await puppeteer...;
  return pdf;   // Next.js intentará serializar esto como JSON
}

// ❌ Sin cerrar el browser — fuga de procesos
const browser = await puppeteer.launch();
const pdf = await pagina.pdf();
return pdf;   // si esto lanza un error, el browser nunca cierra

// ✅ Route Handler con finally
export async function POST(request) {
  let browser;
  try {
    browser = await puppeteer.launch({ headless: true });
    // ...
  } finally {
    await browser?.close();
  }
}
```

---

### 📖 Mini-ejercicio de comprensión

Tienes una Server Action que busca una reserva en Prisma y quieres
convertirla en una función que genere un PDF.

¿Qué es lo único que tienes que cambiar además del código que genera el
PDF? ¿Y por qué?

---

### 🔗 Conexión con lo anterior

`waitUntil: "domcontentloaded"` debería sonar familiar — es el mismo
evento que usas en HTML/CSS para asegurarte de que el DOM está listo
antes de manipularlo. Puppeteer espera ese evento para confirmar que la
página está cargada antes de "imprimirla".

---

### 🛠 EJERCICIOS DÍA 1

**Ejercicio 1** — instalación y primer PDF

Instala Puppeteer:

```bash
npm install puppeteer
```

El paquete descarga Chrome automáticamente al instalarse (~280MB en
Linux y Windows). Si el navegador no aparece, revisa el bloque perecedero
de la Cheat Sheet.

Crea `app/api/documentos/test/route.ts` que genere un PDF con una página
HTML mínima — tu nombre, la fecha de hoy formateada con `.toLocaleDateString("es-CL")`, y el texto "Primer documento generado".

Verifica que el archivo se descarga y se abre correctamente.

**Ejercicio 2** — el botón de descarga

Crea un Client Component `BotonDescargar` que haga `fetch` al Route
Handler del ejercicio 1 y descargue el archivo usando el patrón
blob → createObjectURL → click.

Colócalo en una página existente de tu aplicación.

**Ejercicio 3** — diagnóstico

Quita `printBackground: true` del Route Handler, genera el PDF y describe
qué cambió. Luego quita el `finally` y observa qué pasa en el monitor de
procesos de tu sistema operativo si el handler lanza un error a propósito.

Este ejercicio es para ver los fallos, no para resolver código.

---

**Cuando termines avísame — valido el Día 1.** ✅

---

## 🗓 DÍA 2 — PLANTILLAS HTML COMO FUNCIONES

### 🎯 Objetivo
Separar la estructura del documento de los datos, y entender por qué
la plantilla es HTML puro y no un componente React.

---

### 📖 El problema real

El PDF del Día 1 tenía el contenido escrito a mano. Necesitas generar
el mismo documento con datos distintos para cada reserva.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Tienes template literals desde la Semana 1. Podrías construir el HTML
directamente en el Route Handler:

```typescript
const html = `<h1>${reserva.cliente}</h1><p>${reserva.expedicion.nombre}</p>`;
```

---

### 📖 Por qué eso no escala

Funciona para tres líneas. Con un documento real — encabezado, logo,
tabla de datos, condiciones, pie de página — el Route Handler se convierte
en un archivo de 200 líneas donde la lógica del endpoint está enterrada
entre strings de HTML.

Y si mañana quieres un segundo tipo de documento, copias todo eso.

La solución es la misma que aplicaste en la Semana 3 con StartupMetrics:
**separar la lógica de la presentación**. El Route Handler decide qué
datos juntar; la plantilla decide cómo mostrarlos.

---

### 📖 La plantilla como función

```typescript
// src/lib/plantillas/reserva.ts

type DatosReserva = {
  cliente: string;
  expedicion: string;
  personas: number;
  total: number;
  fecha: Date;
};

export function plantillaReserva(datos: DatosReserva): string {
  return `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: Arial, sans-serif; color: #1f2937; padding: 40px; }
        .encabezado { border-bottom: 2px solid #1d4ed8; padding-bottom: 16px; }
        .titulo { color: #1d4ed8; margin: 0; }
        .monto { font-size: 24px; font-weight: bold; margin-top: 24px; }
        .pie { margin-top: 48px; font-size: 12px; color: #6b7280; }
      </style>
    </head>
    <body>
      <div class="encabezado">
        <h1 class="titulo">Comprobante de Reserva</h1>
        <p>Nexus Expediciones · RUT 76.543.210-K</p>
      </div>

      <h2>${datos.expedicion}</h2>

      <table>
        <tr><td>Cliente</td><td>${datos.cliente}</td></tr>
        <tr><td>Personas</td><td>${datos.personas}</td></tr>
        <tr><td>Fecha</td><td>${datos.fecha.toLocaleDateString("es-CL", {
          day: "numeric", month: "long", year: "numeric"
        })}</td></tr>
      </table>

      <p class="monto">Total: $${datos.total.toLocaleString("es-CL")}</p>

      <p class="pie">
        Este documento es un comprobante de reserva. Para consultas,
        contacte a info@nexus-expediciones.cl
      </p>
    </body>
    </html>
  `;
}
```

**¿Por qué HTML puro y no un componente React?**

Puppeteer no entiende JSX. Recibe un string HTML y lo renderiza en Chrome.
Si le pasas un componente React, ve el código fuente del componente, no su
output renderizado.

La plantilla es una función que recibe datos y retorna un string — igual
que los template literals de la Semana 1, pero a escala de documento.

---

### 📖 CSS en las plantillas — las opciones

Puppeteer no carga URLs externas por defecto. Eso descarta el CDN de
Tailwind. Las opciones viables:

**Opción A — CSS inline:** todo en el `<style>`. Simple, directo, sin
dependencias. El CSS puede ser largo pero nunca falla.

**Opción B — Tailwind compilado:** compilas Tailwind a un archivo CSS
estático y lo incluyes en las plantillas.

**Opción C — `setRequestInterception`:** Puppeteer puede hacer requests
externos, pero requiere configuración extra y agrega latencia.

Para esta semana: **CSS inline**. Cuando el documento sea complejo, la
opción B tiene más sentido.

---

### 📖 Mini-ejercicio de comprensión

La plantilla recibe `datos.fecha` como `Date` y llama a `.toLocaleDateString()`
dentro del template literal.

¿Podría recibir directamente un string formateado en vez de un objeto
`Date`? ¿Qué gana y qué pierde con cada opción?

---

### 🔗 Conexión con lo anterior

El archivo `src/lib/plantillas/` es el equivalente de `src/logica/` en la
arquitectura que armaste en React. Funciones puras que no saben nada del
framework — no importan Next.js, no importan React, no saben que existe
un servidor. Solo reciben datos y retornan un string.

Ese aislamiento es lo que te permite probarlas sin levantar ningún servidor.

---

### 🛠 EJERCICIOS DÍA 2

**Ejercicio 1** — `src/lib/plantillas/comprobante-reserva.ts`

Plantilla tipada con TypeScript que recibe una reserva completa (con la
expedición incluida, como viene de Prisma con `include`) y retorna HTML
listo para Puppeteer.

Debe incluir: logo textual de la empresa, todos los datos de la reserva,
el total formateado y un pie de página con condiciones básicas.

**Ejercicio 2** — conectar plantilla con Route Handler

Actualiza el Route Handler del Día 1 para que use la plantilla del
ejercicio 1. Los datos deben venir de Prisma, no de variables fijas.

**Ejercicio 3** — tipado estricto

Define un tipo `DatosDocumento` que cubra todos los campos que necesitan
las plantillas. El Route Handler debe extraer exactamente esos campos de
Prisma usando `select`, no traer el objeto completo.

Justifica en un comentario por qué `select` es mejor que `include` en
este contexto. Pista: piensa en el principio de mínima información necesaria.

**Ejercicio 4** — dos documentos, una base

Escribe `src/lib/plantillas/cotizacion.ts` que genere una cotización
(sin reserva confirmada: solo nombre del cliente, expedición seleccionada,
personas y precio estimado con IVA desglosado).

Reutiliza los tipos y el CSS base del comprobante. La cotización no tiene
número de reserva — ese dato no existe aún.

---

**Cuando termines avísame — valido el Día 2.** ✅

---

## 🗓 DÍA 3 — FORMATOS CHILENOS

### 🎯 Objetivo
Construir las utilidades de formato que hacen que un documento parezca
hecho en Chile, no en otro lugar.

---

### 📖 El problema real

Los documentos del Día 2 tienen los datos, pero se ven genéricos. Un
comprobante chileno real tiene RUT con puntos, precios con separador de
miles chileno, fechas en español y desglose de IVA.

---

### 📖 Los cuatro formatos que hacen la diferencia

**RUT chileno:**

```typescript
// Entrada:  "76543210K"  o  "76.543.210-K"
// Salida:   "76.543.210-K"

export function formatearRut(rut: string): string {
  // Limpiar puntos y guion que puedan venir
  const limpio = rut.replace(/\./g, "").replace("-", "");
  const cuerpo = limpio.slice(0, -1);
  const dv = limpio.slice(-1).toUpperCase();

  // Agregar puntos cada 3 dígitos
  const conPuntos = cuerpo.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

  return `${conPuntos}-${dv}`;
}
```

**Precio en pesos chilenos:**

```typescript
// 450000  →  "$450.000"
// 1234567 →  "$1.234.567"

export function formatearPrecio(monto: number): string {
  return "$" + monto.toLocaleString("es-CL");
}
```

**Desglose de IVA:**

```typescript
// Chile: IVA = 19% sobre el neto
// Pero lo común es tener el precio con IVA incluido y descomponerlo

export function calcularDesdeTotal(totalConIva: number) {
  const neto = Math.round(totalConIva / 1.19);
  const iva = totalConIva - neto;

  return {
    neto,
    iva,
    total: totalConIva
  };
}
```

**Fecha en español:**

```typescript
// Date → "lunes, 4 de agosto de 2026"
export function formatearFecha(fecha: Date, formato: "largo" | "corto" = "largo"): string {
  if (formato === "corto") {
    return fecha.toLocaleDateString("es-CL");   // "04-08-2026"
  }
  return fecha.toLocaleDateString("es-CL", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}
```

---

### 📖 La expresión regular del RUT — qué hace

```typescript
cuerpo.replace(/\B(?=(\d{3})+(?!\d))/g, ".")
```

Esta regex aparece en muchos proyectos chilenos. Vale la pena entender
qué hace aunque no hayas estudiado regex formalmente:

- `\B` — posición que NO es un borde de palabra
- `(?=(\d{3})+(?!\d))` — seguida de uno o más grupos de 3 dígitos que
  NO tienen más dígitos después

En español: encuentra cada posición donde, mirando hacia la derecha,
quedan exactamente 3, 6, 9... dígitos. Ahí inserta un punto.

`"76543210".replace(...)` → `"76.543.210"`

No necesitas memorizarla — sí necesitas saber qué hace para poder
buscarla o adaptarla.

---

### 📖 Por qué `Math.round` en el IVA

```typescript
const neto = Math.round(totalConIva / 1.19);
```

`450000 / 1.19 = 378151.2605...`

El SII no acepta decimales. `Math.round` da `378151`. La diferencia de
centavos (`449999 - 378151 = 71849`) queda como IVA. Es la convención
estándar en documentos tributarios chilenos.

---

### 📖 Conexión con lo que ya sabes

`.toLocaleString("es-CL")` la usaste en PS-1 para el reporte ejecutivo.
Ahí formateaba números para la consola. Aquí hace exactamente lo mismo,
pero el output va dentro de un string HTML que luego se convierte en PDF.

El concepto no cambió — cambió el destino del resultado.

---

### 📖 Mini-ejercicio de comprensión

```typescript
const monto = 89990;
console.log(monto.toLocaleString("es-CL"));
console.log(monto.toLocaleString("en-US"));
```

¿Qué imprime cada línea? ¿Por qué importa la diferencia en un documento
para un cliente chileno?

---

### 🛠 EJERCICIOS DÍA 3

**Ejercicio 1** — `src/lib/formatos-cl.ts`

Implementa las cuatro funciones: `formatearRut`, `formatearPrecio`,
`calcularDesdeTotal` y `formatearFecha`.

Escribe pruebas manuales para cada una (sin framework de testing —
simplemente `console.log` con el valor esperado al lado):

```typescript
console.log(formatearRut("76543210K"), "→ esperado: 76.543.210-K");
console.log(formatearPrecio(450000), "→ esperado: $450.000");
```

**Ejercicio 2** — integración en las plantillas

Actualiza el comprobante de reserva y la cotización del Día 2 para usar
las funciones del ejercicio 1. Todos los RUTs, precios y fechas deben
venir de `formatos-cl.ts`.

**Ejercicio 3** — la cotización con IVA

La cotización del Día 2 mostraba el precio sin desglose. Agrégale una
tabla de IVA usando `calcularDesdeTotal`:

```
Subtotal (neto):    $xxx.xxx
IVA (19%):          $ xx.xxx
Total:              $xxx.xxx
```

El total debe coincidir con el precio de la expedición × personas.
Verifica que los tres números sumen correctamente.

**Ejercicio 4** — caso borde del RUT

El dígito verificador puede ser `K`. Prueba tu función con:

```typescript
formatearRut("76543210K")   // con K mayúscula
formatearRut("76543210k")   // con k minúscula
formatearRut("76.543.210-K") // con formato ya aplicado
```

Los tres deben producir `"76.543.210-K"`. Si alguno falla, ajusta la
función.

---

**Cuando termines avísame — valido el Día 3.** ✅

---

## 🗓 DÍA 4 — EL BOTÓN DE DESCARGA Y EL FLUJO COMPLETO

### 🎯 Objetivo
Conectar el Route Handler con la interfaz de usuario y entender por qué
la descarga de archivos funciona así.

---

### 📖 El problema real

Tienes el Route Handler que genera el PDF. Falta el botón que lo activa
y hace que el archivo llegue al usuario.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Un `<a href="/api/documentos/reserva">` debería funcionar, ¿no?

---

### 📖 Por qué eso no alcanza

Un `<a>` con href hace una petición GET. El Route Handler necesita recibir
el `reservaId` — eso implica POST con body JSON, que un `<a>` no puede
hacer.

Podrías poner el ID en la URL: `/api/documentos/reserva?id=EXP001`. Eso
sí funciona con GET. Es una solución válida para casos simples.

Pero cuando los datos son más complejos o sensibles, POST es el camino.

---

### 📖 El patrón de descarga con fetch

```typescript
"use client";

export function BotonDescargar({ reservaId }: { reservaId: string }) {
  async function descargar() {
    const respuesta = await fetch("/api/documentos/reserva", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reservaId })
    });

    if (!respuesta.ok) {
      console.error("Error:", respuesta.status);
      return;
    }

    // fetch devuelve los bytes del PDF como Blob
    const blob = await respuesta.blob();

    // Crear una URL temporal que apunta a esos bytes en memoria
    const url = URL.createObjectURL(blob);

    // Crear un enlace invisible, hacer click, y destruirlo
    const enlace = document.createElement("a");
    enlace.href = url;
    enlace.download = `reserva-${reservaId}.pdf`;
    enlace.click();

    // Liberar la memoria
    URL.revokeObjectURL(url);
  }

  return <button onClick={descargar}>Descargar comprobante</button>;
}
```

**Por qué este patrón indirecto:**

El navegador no tiene forma nativa de decirle a `fetch` "descarga este
resultado como archivo". `fetch` solo sabe traer datos a JavaScript.

El truco es:
1. Traer los bytes del PDF a memoria del navegador como `Blob`
2. Crear una URL temporal que apunte a esos bytes
3. Simular que el usuario hizo click en un enlace de descarga
4. Borrar la URL temporal para liberar memoria

Es la solución estándar. Todos la usan aunque sea fea.

---

### 📖 Estados de carga — mejor experiencia

Sin estados, el botón parece que no hace nada mientras genera el PDF:

```typescript
"use client";
import { useState } from "react";

export function BotonDescargar({ reservaId }: { reservaId: string }) {
  const [generando, setGenerando] = useState(false);

  async function descargar() {
    setGenerando(true);
    try {
      const respuesta = await fetch("/api/documentos/reserva", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reservaId })
      });

      if (!respuesta.ok) throw new Error("Error al generar");

      const blob = await respuesta.blob();
      const url = URL.createObjectURL(blob);

      const enlace = document.createElement("a");
      enlace.href = url;
      enlace.download = `reserva-${reservaId}.pdf`;
      enlace.click();

      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
    } finally {
      setGenerando(false);
    }
  }

  return (
    <button onClick={descargar} disabled={generando}>
      {generando ? "Generando..." : "Descargar comprobante"}
    </button>
  );
}
```

El `finally` garantiza que `generando` vuelve a `false` aunque algo falle.
Es el mismo patrón del `browser.close()` del Día 1.

---

### 📖 Mini-ejercicio de comprensión

```typescript
const blob = await respuesta.blob();
const json = await respuesta.json();
```

Si llamas las dos sobre la misma respuesta, una falla. ¿Cuál, y por qué?

---

### 🔗 Conexión con React

`disabled={generando}` es un atributo booleano en JSX — el patrón que
viste en la Semana 10. `{generando}` evalúa a `true` o `false` y
controla si el botón acepta clicks.

El `useState` aquí es el más simple que existe: un booleano que cambia
mientras la operación está en curso.

---

### 🛠 EJERCICIOS DÍA 4

**Ejercicio 1** — `BotonDescargar` con estados

Implementa el componente completo con estado de carga y manejo de errores.
El texto del botón debe cambiar mientras genera, y el botón debe quedar
deshabilitado para evitar clicks múltiples.

**Ejercicio 2** — integración en la vista de reservas

Agrega el `BotonDescargar` al panel de detalle de cada reserva confirmada.
Las reservas en otros estados no muestran el botón.

**Ejercicio 3** — manejo de errores visible

Agrega un estado de error al componente. Si el Route Handler devuelve un
error (status 4xx o 5xx), muestra un mensaje visible al usuario — no solo
un `console.error`.

**Ejercicio 4** — variante GET

Para la cotización, donde no hay reserva guardada, implementa el Route
Handler como GET con query parameters en vez de POST con body:

```
/api/documentos/cotizacion?expedicionId=EXP001&personas=3&cliente=Ana
```

¿Cuándo conviene GET sobre POST para generar documentos? Documenta tu
conclusión en un comentario.

---

**Cuando termines avísame — valido el Día 4.** ✅

---

## 🗓 DÍA 5 — TRES DOCUMENTOS, UN SISTEMA

### 🎯 Objetivo
Completar los tres tipos de documento y extraer lo común en una base
reutilizable.

---

### 📖 El problema real

Tienes el comprobante y la cotización. Falta el certificado de participación.
Y los tres tienen cosas en común: encabezado con logo, estilos base, pie
de página. Están duplicados.

---

### 📖 La base compartida

```typescript
// src/lib/plantillas/base.ts

export type OpcionesDocumento = {
  titulo: string;
  contenido: string;
  numeroDocumento?: string;
};

export function plantillaBase({ titulo, contenido, numeroDocumento }: OpcionesDocumento): string {
  return `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <style>
        ${estilosBase()}
      </style>
    </head>
    <body>
      ${encabezado(titulo, numeroDocumento)}
      <main>${contenido}</main>
      ${pieDocumento()}
    </body>
    </html>
  `;
}

function estilosBase(): string {
  return `
    * { box-sizing: border-box; }
    body { font-family: Arial, sans-serif; color: #1f2937; padding: 0; margin: 0; }
    .documento { padding: 40px; max-width: 800px; margin: 0 auto; }
    .encabezado { border-bottom: 3px solid #1d4ed8; padding-bottom: 20px; margin-bottom: 32px; display: flex; justify-content: space-between; align-items: flex-start; }
    .logo { font-size: 22px; font-weight: bold; color: #1d4ed8; }
    .numero-doc { color: #6b7280; font-size: 13px; }
    .pie { margin-top: 48px; border-top: 1px solid #e5e7eb; padding-top: 16px; font-size: 11px; color: #9ca3af; }
    table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    td, th { padding: 8px 12px; text-align: left; }
    tr:nth-child(even) { background: #f9fafb; }
  `;
}

function encabezado(titulo: string, numero?: string): string {
  return `
    <div class="documento">
      <div class="encabezado">
        <div>
          <div class="logo">Nexus Expediciones</div>
          <div>RUT: 76.543.210-K</div>
          <div>Penco, Chile</div>
        </div>
        <div style="text-align: right;">
          <h1 style="margin: 0; font-size: 20px; color: #1f2937;">${titulo}</h1>
          ${numero ? `<div class="numero-doc">N° ${numero}</div>` : ""}
          <div>${new Date().toLocaleDateString("es-CL")}</div>
        </div>
      </div>
  `;
}

function pieDocumento(): string {
  return `
      <div class="pie">
        Este documento fue generado por Nexus Expediciones ·
        Para consultas: info@nexus-expediciones.cl ·
        Documento generado el ${new Date().toLocaleDateString("es-CL", {
          day: "numeric", month: "long", year: "numeric"
        })}
      </div>
    </div>
  `;
}
```

Cada plantilla específica llama a `plantillaBase` pasando su contenido:

```typescript
export function plantillaComprobante(datos: DatosReserva): string {
  const contenido = `
    <h2>${datos.expedicion}</h2>
    <!-- ... datos de la reserva ... -->
  `;

  return plantillaBase({
    titulo: "Comprobante de Reserva",
    contenido,
    numeroDocumento: datos.id.slice(-6).toUpperCase()
  });
}
```

---

### 📖 El certificado de participación

El tercer documento es distinto: se emite **después** de la expedición,
certifica que alguien participó.

```typescript
type DatosCertificado = {
  cliente: string;
  rut: string;
  expedicion: string;
  fechaExpedicion: Date;
  duracionDias: number;
  dificultad: string;
  guia: string;
};
```

No tiene precio ni total. Tiene fecha de la expedición (pasada), nombre
del guía como firmante, y una redacción formal.

---

### 📖 Opciones de página en Puppeteer

Los tres documentos pueden tener necesidades distintas:

```typescript
// Comprobante — una página A4 estándar
await pagina.pdf({ format: "A4", printBackground: true });

// Certificado — puede ser horizontal o con margen mayor
await pagina.pdf({
  format: "A4",
  landscape: false,
  printBackground: true,
  margin: { top: "30mm", right: "25mm", bottom: "30mm", left: "25mm" }
});
```

**Saltos de página en documentos de varias páginas:**

```css
.tabla-items { page-break-inside: avoid; }  /* no cortar una tabla a la mitad */
.nueva-seccion { page-break-before: always; } /* siempre empezar en página nueva */
```

---

### 📖 Mini-ejercicio de comprensión

`plantillaBase` recibe el contenido como string HTML y lo inserta en un
template literal. ¿Por qué es seguro insertar ahí HTML arbitrario en este
contexto, y en qué situación NO sería seguro?

(Pista: piensa en XSS — qué pasa si el contenido viene de un usuario
desconocido en vez de de tu propia base de datos.)

---

### 🛠 EJERCICIOS DÍA 5

**Ejercicio 1** — `src/lib/plantillas/base.ts`

Implementa la base compartida con encabezado, estilos y pie. Refactoriza
el comprobante y la cotización para que la usen.

**Ejercicio 2** — `src/lib/plantillas/certificado.ts`

Certificado de participación. Texto formal: "Se certifica que [cliente],
RUT [rut], participó en la expedición [nombre] realizada el [fecha], de
[duración] días, con dificultad [dificultad], guiada por [guía]."

El guía firma al pie — su nombre centrado con una línea encima.

**Ejercicio 3** — Route Handler para el certificado

Solo expediciones con al menos una reserva confirmada pueden generar
certificado. Si la condición no se cumple, retorna 400 con un mensaje
claro.

**Ejercicio 4** — Route Handler unificado (optativo)

En vez de tres endpoints separados, un solo Route Handler que recibe
el tipo de documento como parámetro:

```
POST /api/documentos  →  { tipo: "reserva" | "cotizacion" | "certificado", id: string }
```

¿Qué ventajas y desventajas tiene unificarlos? Documenta tu razonamiento
antes de implementar.

---

**Cuando termines avísame — valido el Día 5.** ✅

---

## 🗓 DÍA 6 — PROYECTO DE LA SEMANA

### 🏆 NexusDoc — Sistema de Documentos de TerraMater

> Los datos llevan semanas en la base de datos. Los clientes necesitan
> llevarse algo. Esta semana conecta lo que ya construiste con los documentos
> que lo hacen tangible.

---

### 📋 Los tres documentos

**1. Comprobante de reserva**
- Disponible para reservas confirmadas
- Todos los datos de la reserva y la expedición
- Total formateado, fecha, RUT de la empresa
- Numerado (últimos 6 caracteres del ID)

**2. Cotización**
- No requiere reserva existente: se genera desde el formulario de nueva reserva
- Datos del cliente, expedición seleccionada, número de personas
- Desglose: neto + IVA 19% + total
- Vigencia de 30 días desde la emisión

**3. Certificado de participación**
- Solo para reservas confirmadas con fecha de expedición en el pasado
- Texto formal certificando la participación
- Nombre del guía asignado como firmante

---

### 📋 Requisitos técnicos

```
✅ Plantilla base compartida — encabezado, estilos y pie sin duplicar
✅ Funciones de formato en formatos-cl.ts — RUT, precio, IVA, fecha
✅ Tipos TypeScript para cada tipo de documento
✅ Route Handlers separados por tipo de documento
✅ Browser cerrado siempre en finally
✅ Estado de carga en el botón de descarga
✅ Manejo de errores visible al usuario
✅ Reglas de negocio en el servidor:
     · comprobante → solo reservas confirmadas
     · certificado → solo expediciones pasadas
✅ Pruebas manuales de las funciones de formato
❌ Sin strings de datos sensibles en el cliente
❌ Sin instancias de browser abiertas en caso de error
❌ Sin duplicación de CSS entre plantillas
```

---

### 📋 Estructura sugerida

```
src/
├── lib/
│   ├── plantillas/
│   │   ├── base.ts
│   │   ├── comprobante-reserva.ts
│   │   ├── cotizacion.ts
│   │   └── certificado.ts
│   └── formatos-cl.ts
└── app/
    ├── api/
    │   └── documentos/
    │       ├── reserva/route.ts
    │       ├── cotizacion/route.ts
    │       └── certificado/route.ts
    └── reservas/
        └── [id]/
            └── page.tsx    ← botones de descarga según el estado
```

---

### 💡 Las dos únicas pistas

**Pista 1** — Para la cotización sin reserva, pasa los datos por query
parameters en el POST o construye un objeto temporal sin persistirlo en
la base. No crees una reserva "fantasma" solo para generar el documento.

**Pista 2** — Para saber si la expedición es "pasada", necesitas la fecha
de inicio de la expedición. Si ese campo no existe en tu esquema de Prisma,
agrega una migración. Es exactamente el tipo de evolución que las
migraciones están diseñadas para manejar.

---

### ✅ Criterios de aprobación

```
□ Los tres documentos se generan y se ven bien en un visor de PDF
□ Los números salen formateados: RUT con puntos, precios con separador
□ El IVA cuadra: neto + IVA = total
□ La regla de negocio del certificado se aplica en el servidor
□ El botón muestra "Generando..." mientras espera
□ El browser siempre se cierra, incluso si algo falla
□ Las plantillas comparten la base — sin CSS duplicado
□ Subido a GitHub con commit descriptivo
```

**Verificación cruzada:** abre uno de los PDF y busca un número. Ese número
debe coincidir exactamente con el que muestra la base de datos en Prisma
Studio. Si hay diferencia, el formato está aplicado en el lugar equivocado.

---

**Cuando termines el proyecto, avísame. Hacemos la validación semanal interactiva.** 🎯

---

## 🔜 LO QUE VIENE

Al terminar esta semana tienes el sistema de generación de documentos.
El siguiente bloque natural depende de hacia dónde va la cuña:

```
Si la cuña tributaria se confirma:
  Semana 16 → XML y esquemas (DTE chileno)
  Semana 17 → Firma electrónica y comunicación con el SII

Si se confirma otra cuña:
  El sistema de documentos se adapta a ese dominio
```

Esa decisión depende de conversar con alguien que tenga el problema.

---

> ### 📘 PRÓXIMA SEMANA
> Pendiente de confirmar según la validación de la cuña.

---

*Semana 15 — Generación de Documentos PDF*
*Formato v4 — Constitución v2.0 · Protocolo QA con Fase 6b*
*Óscar — Full Stack Developer en formación 🇨🇱*
