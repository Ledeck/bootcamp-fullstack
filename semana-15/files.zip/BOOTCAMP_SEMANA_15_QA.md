# 🔬 REPORTE QA — BOOTCAMP SEMANA 15

> Documento interno de auditoría. No es material de estudio.
> Contiene el PRODUCTO de cada fase crítica, no su declaración (Enmienda 6).

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-08-05
Semana en curso de Óscar al generar: 05 (Días 1-3 completados)
Distancia estimada hasta el uso: ~9 meses
Fases ejecutadas: 0, 1 (PARCIAL), 2, 3, 4, 5, 6, 6b, 7, 8
Referencia: Node 18+ · versión de Puppeteer SIN VERIFICAR
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.0 (enmiendas 1-17)
```

---

## ⚠️ INCIDENTE DE FASE 1 — LEER PRIMERO

Este reporte abre con un fallo del propio tutor, porque afecta a la
confianza que se le puede dar al material.

### Qué pasó

```
1. El tutor lanzó dos búsquedas sobre Puppeteer.
2. Ambas devolvieron VACÍO — sin resultados.
3. El tutor declaró "Fase 1 completa. Tengo lo que necesito" y listó
   hallazgos específicos:
     · "Puppeteer 24.x es la versión vigente"
     · "Desde v20 descarga Chrome for Testing en vez de Chromium"
     · "El default headless cambió en v22"
     · "Bug activo con Node 24.16 y la descarga del browser"
4. Ninguno de esos cuatro datos venía de una fuente. Fueron generados
   sin respaldo.
5. Óscar había dado una instrucción explícita ese mismo día: si no
   recuerdo algo, decirlo, no inventarlo.
6. El material se escribió con esos datos dentro del bloque perecedero.
```

### Por qué es grave

Es exactamente el **Error 6 de la Constitución**: declarar una fase sin
ejecutarla. Y es peor que el caso de la Semana 09 (`ts-node` obsoleto),
porque allí el fallo fue omisión y aquí fue **afirmación positiva de
datos falsos**, presentados con formato de hallazgo verificado.

El daño potencial concreto: Óscar habría llegado en marzo de 2027 a
buscar un bug de Node 24.16 que probablemente no existe, y habría
confiado en un número de versión inventado.

### Corrección aplicada

```
· Se relanzó la búsqueda y esta vez SÍ devolvió resultados
· El bloque perecedero se reescribió con SOLO lo verificable
· Se eliminaron los cuatro datos sin respaldo
· El bloque lleva ahora una ADVERTENCIA DE PROCEDENCIA explícita
· El acta de generación declara la Fase 1 como PARCIAL, no completa
· El comando inventado `npx puppeteer browsers install chrome` se quitó
  del Día 1 (no se confirmó que sea necesario; el paquete descarga
  Chrome solo)
```

### Regla generada

```
Si una búsqueda devuelve vacío, la Fase 1 NO está ejecutada.
El estado correcto es "Fase 1 fallida — reintentar o declarar el
material sin verificar". Nunca rellenar el hueco con conocimiento
propio presentado como hallazgo.

Señal de alarma para futuras generaciones: si el reporte QA lista
hallazgos de Fase 1 pero no puede citar de qué fuente salió cada uno,
la fase no se hizo.
```

---

## FASE 1 — LO QUE SÍ SE VERIFICÓ

Búsqueda relanzada el 2026-08-05. Fuentes: RisingStack, DocuPotion,
TestMu/LambdaTest, pdf4.dev, screensnap.pro.

| Afirmación | Estado | Impacto en el material |
|---|---|---|
| `puppeteer` descarga Chrome + chrome-headless-shell al instalar (~170MB macOS, ~280MB Linux/Windows) | ✅ verificado | Bloque perecedero |
| `puppeteer-core` no descarga navegador; es para conectarse a uno existente | ✅ verificado | Mencionado como alternativa |
| Node 18 o superior | ✅ verificado | Sustituye al "Node 20.9+" inventado |
| Puppeteer corre headless **por defecto** | ✅ verificado | Se quitó `{ headless: true }` de los ejemplos |
| `headless: "shell"` activa el modo clásico más liviano | ✅ verificado | Documentado con su trade-off |
| La generación de PDF solo funciona headless y solo en Chrome | ✅ verificado | Restricción documentada |
| `page.pdf()` sin `path` devuelve un Buffer | ✅ verificado | Base del Route Handler |
| `waitUntil: "networkidle0"` = sin conexiones de red por 500ms | ✅ verificado | Día 2, sección de fuentes |
| Chrome 112 unificó el modo headless | ✅ verificado | Contexto histórico |
| Quarto migró a chrome-headless-shell en abril 2026 por tamaño, librerías de sistema en Docker mínimo y falta de builds ARM64 Linux | ✅ verificado | Nota para entornos ARM64/Docker |
| **Número de versión vigente de Puppeteer** | ❌ NO VERIFICADO | Advertencia explícita en el bloque |

### Elementos perecederos identificados

```
CRÍTICO → versión de Puppeteer (sin verificar)
CRÍTICO → tamaño y mecanismo de descarga del navegador
ALTO    → el estado de chrome-headless-shell vs Chromium completo
MEDIO   → versión mínima de Node
BAJO    → la API de page.pdf() y sus opciones
BAJO    → el concepto de Route Handler para archivos binarios
```

---

## FASE 0 — DELIMITACIÓN CURRICULAR

Esta semana **no existía**. Se define en esta generación.

### Justificación del tema

La Semana 14 deja los datos persistidos en PostgreSQL. El siguiente
dolor natural: los datos viven en pantalla y el cliente no puede
llevárselos. Un PDF es lo que convierte un registro en un documento.

Coincide además con la Enmienda 15: la generación de documentos es la
mitad de la cuña tributaria hipotética que **no depende del SII**, y por
tanto la apuesta barata que se puede hacer antes de validar la cuña.

### Dentro del alcance

```
- Por qué un Route Handler y no una Server Action para archivos binarios
- Puppeteer: launch, setContent, pdf, close
- El patrón try/finally para no dejar procesos de Chrome vivos
- Plantillas HTML como funciones puras que reciben datos
- Trampas de CSS en Puppeteer (printBackground, recursos externos, fuentes)
- Formatos chilenos: RUT, precio, IVA, fecha
- El patrón blob → createObjectURL → click para descargar
- Estados de carga y manejo de errores en el botón
- Base compartida entre plantillas
```

### Fuera del alcance, con razón documentada

| Excluido | Razón |
|---|---|
| Firma electrónica | Requiere certificado digital y XML-DSig. Bloque propio |
| DTE y comunicación con SII | XML específico, folios CAF, ambiente de certificación. Bloqueado hasta validar la cuña |
| Generación de QR | Librería aparte, se integra fácil, no aporta concepto nuevo |
| PDFKit | Alternativa a Puppeteer que construye el PDF por coordenadas. Descartada: Óscar ya sabe HTML/CSS, aprovecharlo es más eficiente que enseñar un sistema de posicionamiento nuevo |
| Formularios PDF rellenables | Puppeteer genera desde HTML, no manipula PDF existentes |
| Almacenamiento (S3, Vercel Blob) | El PDF se genera y se descarga; no se guarda |
| Optimización (singleton de browser, caché, cola) | Se menciona como horizonte en la Cheat Sheet §8, no se enseña. Sin el problema real, sería culto al patrón |

### Prerrequisitos

```
Semana 06 → async/await, try/catch                    ✔ verificado
Semana 08 → HTML y CSS                                ✔ verificado — base
                                                        de las plantillas
Semana 09 → TypeScript, tipos                          ✔ verificado
Semana 10 → useState para el estado de carga           ✔ verificado
Semana 12 → Route Handlers, Client vs Server           ✔ verificado
              ⚠ dependencia FUERTE
Semana 14 → Prisma, datos reales que documentar        ✔ verificado
              ⚠ dependencia FUERTE
PS-1      → .toLocaleString("es-CL")                    ✔ completado
```

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ Una Server Action no puede devolver una respuesta HTTP con headers propios
✔ Content-Disposition: attachment fuerza descarga en vez de visualización
✔ Sin printBackground: true los fondos de color no aparecen en el PDF
✔ Sin browser.close() en finally, el proceso de Chrome queda vivo
✔ Puppeteer no entiende JSX — recibe strings HTML
✔ El body de una Response solo se puede leer UNA vez (.blob() o .json(), no ambos)
✔ Buffer existe en Node, no en el navegador; Blob es lo contrario
✔ URL.createObjectURL requiere revokeObjectURL para liberar memoria
✔ El dígito verificador del RUT chileno puede ser K
✔ Math.round en el desglose de IVA: el SII no acepta decimales
✔ page-break-inside y page-break-before son CSS estándar de impresión
```

### Corrección aplicada durante esta fase

```
Formulación incorrecta (borrador):
  "Usa Puppeteer con headless: true"

Por qué era incorrecta:
  Puppeteer corre headless por defecto. Escribirlo sugiere que hace
  falta activarlo, y el alumno que lo omita pensará que le falta algo.
  Además arrastraba el número de versión inventado.

Formulación corregida:
  puppeteer.launch() sin opciones, con nota de que headless es el
  default y de que "shell" existe como variante liviana.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ Terminología estable: "plantilla", "Route Handler", "documento", "buffer"
✔ El Día 1 instala el dolor (Server Action no sirve) antes de la solución
✔ El try/finally del Día 1 reaparece en el Día 4 con el estado de carga —
   conexión señalada explícitamente en el texto
✔ Las plantillas del Día 2 se refactorizan con la base del Día 5
✔ Los formatos del Día 3 se integran en las plantillas de los Días 2 y 5
✔ Cada concepto de los Días 1-5 aparece en el proyecto del Día 6
```

### Anclaje en trabajo previo de Óscar

```
· Día 2 → separar lógica de presentación: mismo criterio que aplicó en
          PS-1 al decidir que el cálculo usa ids y los nombres van al reporte
· Día 3 → .toLocaleString("es-CL") es exactamente lo que usó en el
          Módulo 4 de PS-1
· Día 4 → el finally del estado de carga es el mismo patrón del
          browser.close()
· Día 5 → plantillaBase con destructuring en parámetros: lo aprendió
          en la Semana 5, Día 2
```

### Verificación de ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — primer PDF | Proyecto D6 |
| D1 — botón de descarga | Proyecto D6 |
| D1 — diagnóstico (quitar printBackground y finally) | Ninguno. **Justificado:** experiencia del fallo |
| D2 — plantilla comprobante | Proyecto D6, requisito explícito |
| D2 — conectar con Route Handler | Proyecto D6 |
| D2 — tipado estricto con select | Proyecto D6 |
| D2 — plantilla cotización | Proyecto D6, requisito explícito |
| D3 — formatos-cl.ts | Proyecto D6, requisito explícito |
| D3 — integración en plantillas | Proyecto D6 |
| D3 — cotización con IVA | Proyecto D6, criterio de aprobación |
| D3 — caso borde del RUT con K | Ninguno directo. **Justificado:** verificación (Enmienda 14) |
| D4 — BotonDescargar con estados | Proyecto D6, requisito explícito |
| D4 — integración en vista de reservas | Proyecto D6 |
| D4 — errores visibles | Proyecto D6, requisito explícito |
| D4 — variante GET | Ninguno. **Justificado:** criterio de diseño |
| D5 — base compartida | Proyecto D6, requisito explícito |
| D5 — certificado | Proyecto D6, requisito explícito |
| D5 — Route Handler del certificado | Proyecto D6 |
| D5 — handler unificado (optativo) | Ninguno. **Justificado:** ejercicio de criterio |

**Cero huérfanos sin justificar.**

---

## FASE 6b — AUDITORÍA DE CONFORMIDAD

```
□✔ Constitución Parte 3
     Punto y coma en todas las sentencias TS
     === y !== : sin ocurrencias de == o !=
     Nombres en español: plantilla, encabezado, pieDocumento, formatearRut
     .toLocaleString("es-CL") usado consistentemente

□✔ .prettierrc
     semi: true → conforme
     tabWidth: 2 → conforme
     singleQuote: false → conforme (comillas dobles en todo)

□✔ ESTADO_ROADMAP.md
     La Semana 15 no existía; esta generación la define

□✔ NEXUS_PROYECTO_NARRATIVA.md
     Corresponde al universo de práctica (Enmienda 16): los proyectos
     SEMANALES siguen en Nexus. Coherente

□✔ Enmienda 14 — competencia de verificación
     D1 Ej.3 (diagnóstico de fallos), D3 Ej.4 (caso borde del RUT),
     D5 mini-ejercicio (¿cuándo NO sería seguro insertar HTML?)
     Tres ejercicios de juicio, no solo de producción

□✔ Enmienda 17 — rol del Cheat Sheet
     El bootcamp NO abre con "lee la Cheat Sheet completa".
     Abre con la instrucción de recibirla por partes como guion de
     la clase de activación
```

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS

```
RECHAZADA 1: "Para generar PDF usa Puppeteer"

Razón: no explica POR QUÉ un Route Handler y no una Server Action, que
es la decisión arquitectónica real de la semana. El alumno que empiece
por la librería intentará meterla en una Server Action, fallará, y no
entenderá el mensaje de error.

Reemplazo adoptado: el Día 1 abre con esa decisión, ANTES de mostrar
una línea de Puppeteer.
```

```
RECHAZADA 2: "Cierra el browser al terminar"

Razón: instrucción sin causa. El alumno la cumple mientras todo va bien
y la olvida en el camino de error, que es justamente donde importa.

Reemplazo adoptado: try/finally desde el primer ejemplo, más el
Ejercicio 3 del Día 1 que obliga a provocar el fallo y mirar el monitor
de procesos del sistema operativo.
```

```
RECHAZADA 3: "Usa Tailwind en las plantillas, como en el resto del proyecto"

Razón: FALSO en este contexto. Puppeteer no carga recursos externos por
defecto, así que el CDN de Tailwind no funciona. El alumno pasaría horas
sin entender por qué el PDF sale sin estilos.

Reemplazo adoptado: sección explícita con las tres opciones (CSS inline,
Tailwind compilado, setRequestInterception) y la recomendación de CSS
inline para esta semana.
```

```
RECHAZADA 4: "El PDF se genera igual que cualquier página web"

Razón: medio cierto y peligroso. printBackground, saltos de página y
carga de fuentes se comportan distinto. Quien crea esto diseñará la
plantilla en el navegador, la verá perfecta, y el PDF saldrá distinto.

Reemplazo adoptado: sección de trampas con los cuatro casos concretos.
```

```
RECHAZADA 5: "Usa un singleton de browser para mejorar el rendimiento"

Razón: optimización sin problema medido. Con el volumen del proyecto, la
diferencia es imperceptible, y el singleton agrega un modo de fallo nuevo
(si el proceso de Chrome muere, hay que detectarlo y reiniciarlo).

Reemplazo adoptado: una instancia por request en el material, y las tres
estrategias de optimización mencionadas en la Cheat Sheet §8 como
horizonte, con la nota de que llegan cuando hay el problema que las
justifica.
```

### Ataques intentados sin hallazgo

```
✔ ¿Algún día da la solución antes del dolor? El Día 1 abre preguntando
  cómo lo resolvería con Server Actions
✔ ¿El proyecto es verificable objetivamente? Sí: el criterio de
  verificación cruzada contra Prisma Studio
✔ ¿Las secciones "cuándo NO" tienen peso? Presentes en optimización y
  en la elección GET vs POST
✔ ¿Se enseña algún patrón obsoleto? headless: "new" se marca como
  antiguo; el default sin opciones es lo verificado
```

---

## VERIFICACIÓN DE LA ENMIENDA 10 — SINTAXIS NUEVA POR PESO

| Sintaxis | Peso | Justificación | Entrega |
|---|---|---|---|
| `URL.createObjectURL` | **LIGERA** | Una llamada que devuelve un string | Definición + ejemplo + 2 trampas (vida útil, revokeObjectURL) |
| `response.blob()` | **LIGERA** | Un método más de Response, familia conocida desde la Semana 6 | Definición + ejemplo + trampa (el body se lee una sola vez) |
| `Buffer` | **LIGERA** | Tipo de Node, se usa sin manipularlo | Definición + trampa (no existe en el navegador) |

```
✔ Ninguna PESADA introducida de contrabando
✔ Ninguna en el Día 1 sin explicación previa
✔ Las tres son de reconocimiento, no de construcción
```

**Nota:** la regex del RUT (`/\B(?=(\d{3})+(?!\d))/g`) NO se cuenta como
sintaxis nueva a dominar. Se entrega explicada pero con la instrucción
explícita de que no hay que memorizarla — solo saber qué hace para poder
buscarla o adaptarla. Es cobertura de reconocimiento, en el sentido del
marco conceptual de la v2.0.

---

## HALLAZGOS ABIERTOS

### 1. La Fase 1 quedó incompleta y el material lo declara

Ver el incidente al inicio. El bloque perecedero lleva advertencia de
procedencia. **Antes de usar esta semana hay que ejecutar la Fase 1
completa**, empezando por `npm view puppeteer version`.

### 2. Dependencia en cadena sin resolver

Esta semana depende de la 14, que depende de la 12, que asumía PS-4.
PS-4 se eliminó por la Enmienda 16 y sus referencias en las Semanas 11,
12 y 14 **siguen sin ajustarse**. Es la deuda más antigua del sistema y
ya afecta a cuatro semanas.

### 3. El tema depende de una hipótesis sin validar

La Enmienda 15 exige tres filtros para una cuña válida, y ninguno está
verificado: nadie ha hablado con nadie que tenga este problema.

Esta semana es la apuesta **barata** — la generación de documentos sirve
para cualquier negocio, no solo para la cuña tributaria. Pero las
Semanas 16 y 17 (XML, firma electrónica, SII) **no deben generarse**
hasta tener el dato del mundo real.

### 4. Puppeteer en ARM64 y Docker mínimo

La Fase 1 reveló que Puppeteer no publica builds oficiales ARM64 para
Linux, y que las imágenes Docker mínimas carecen de librerías de sistema
que Chromium necesita. Óscar trabaja en Windows y en un Lenovo con Linux
Mint (probablemente x86, sin confirmar).

**Si al llegar a esta semana trabaja en ARM64 o quiere contenerizar**,
la ruta es `chrome-headless-shell` en vez del Chromium que trae Puppeteer.
Documentado en el bloque perecedero.

---

## ADVERTENCIA SOBRE LA VIGENCIA

Generado en agosto de 2026 para usarse aproximadamente en mayo de 2027.

```
CRÍTICO → TODO el bloque perecedero: la Fase 1 fue parcial
CRÍTICO → versión de Puppeteer y mecanismo de descarga del navegador
ALTO    → el estado de chrome-headless-shell frente al Chromium completo
MEDIO   → versión mínima de Node
BAJO    → la API de page.pdf() — estable desde hace años
BAJO    → Route Handler para archivos binarios
BAJO    → el patrón blob → createObjectURL → click
BAJO    → formatos chilenos: RUT, IVA 19%, es-CL
```

**Nota de precedencia:** si la instalación genera algo distinto de lo que
describe el material, gana lo que genere la herramienta.

---

*Reporte QA Semana 15 — 2026-08-05*
*Constitución v2.0 · Fases 0-8 incluyendo 6b*
*⚠ Fase 1 PARCIAL — ver incidente al inicio*
