# 📄 CHEAT SHEET — SEMANA 15
## Generación de Documentos · PDF · Puppeteer · Formatos Chilenos

> Léela como guion de la clase de activación, no de una sola vez.
> El Bootcamp desarrolla la mecánica; esta Cheat Sheet es el mapa.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado: agosto 2026
Verificación de Fase 1: PARCIAL — ver advertencia abajo
REGENERAR COMPLETO antes de empezar la semana.
```

⚠ **ADVERTENCIA DE PROCEDENCIA — leer antes de usar este bloque.**

Este bloque perecedero **no tiene número de versión de Puppeteer
verificado**. La búsqueda de Fase 1 confirmó comportamiento y API, pero
no la versión concreta vigente. No confíes en ningún número que aparezca
aquí: consulta `npm view puppeteer version` antes de empezar.

```bash
npm install puppeteer
```

**Verificado en Fase 1 (agosto 2026):**

```
· El paquete `puppeteer` descarga Chrome + un binario chrome-headless-shell
  automáticamente al instalar (~170MB en macOS, ~280MB en Linux/Windows)
· `puppeteer-core` NO descarga navegador — es para conectarse a uno
  ya existente (útil en Docker)
· Node 18 o superior como mínimo
· Puppeteer corre headless POR DEFECTO — no hace falta pasar la opción
· `headless: "shell"` activa el modo clásico, más liviano
· La generación de PDF SOLO funciona en modo headless y SOLO en Chrome
· `page.pdf()` sin la opción `path` devuelve un Buffer en vez de escribir
  un archivo
```

**Modo headless:**

```typescript
// Por defecto ya es headless — esto basta
const browser = await puppeteer.launch();

// Shell clásico: más liviano, menos fiel al render real del navegador
const browser = await puppeteer.launch({ headless: "shell" });
```

⚠ Si ves `headless: "new"` en un tutorial, es de una versión anterior.
Sigue funcionando por compatibilidad, pero ya no hace falta escribirlo.

**Nota sobre chrome-headless-shell:** en abril de 2026 el proyecto Quarto
migró del Chromium que trae Puppeteer a `chrome-headless-shell`, por tres
razones: descarga más pequeña, librerías de sistema ausentes en imágenes
Docker mínimas, y falta de builds oficiales ARM64 para Linux. Si trabajas
en ARM64 o en contenedores mínimos, ese es el camino a investigar.

**Qué verificar SIN EXCEPCIÓN al llegar a esta semana:**

```
□ npm view puppeteer version   → la versión real vigente
□ Que el comando de instalación no haya cambiado
□ Que headless: "shell" siga siendo válido
□ La versión mínima de Node exigida
```

---

## 1. POR QUÉ UN ROUTE HANDLER Y NO UNA SERVER ACTION

Esta es la decisión arquitectónica central de la semana, y vale entenderla
antes de escribir una línea.

**Las Server Actions** retornan datos — objetos, strings, resultados de
operaciones. Los maneja React.

**Un PDF es un archivo binario.** No es un objeto JSON. Necesita headers
HTTP específicos (`Content-Type: application/pdf`) para que el navegador
lo trate como un archivo descargable.

Las Server Actions no pueden devolver eso. Por eso la generación de PDF
va en un **Route Handler** — el equivalente de un endpoint de API dentro
de Next.js.

```
/app/api/documentos/reserva/route.ts   →  POST: genera y devuelve el PDF
/app/reservas/page.tsx                 →  el botón "Descargar" llama a ese endpoint
```

La separación es la misma que ya conoces: Server Component lee datos de
la base, Client Component tiene el botón interactivo, Route Handler genera
el archivo.

---

## 2. CÓMO FUNCIONA PUPPETEER

Puppeteer controla un navegador real (Chrome) desde Node.js. Para generar
un PDF:

```typescript
import puppeteer from "puppeteer";

const browser = await puppeteer.launch({ headless: true });
const pagina = await browser.newPage();

await pagina.setContent(html, { waitUntil: "domcontentloaded" });

const pdfBuffer = await pagina.pdf({
  format: "A4",
  printBackground: true,
  margin: { top: "20mm", right: "15mm", bottom: "20mm", left: "15mm" }
});

await browser.close();
```

**El modelo mental:**

> Puppeteer abre Chrome en modo invisible, carga tu HTML como una página,
> y "imprime" esa página a PDF. El resultado es un buffer de bytes —
> exactamente como si el usuario hubiera usado Ctrl+P en el navegador.

Por eso el HTML que le pases puede usar CSS completo, incluyendo Tailwind.
Pero hay trampas (ver sección 5).

**Por qué cerrar el browser siempre:**

```typescript
try {
  // ... generar PDF
} finally {
  await browser.close();
}
```

Si no cierras, el proceso de Chrome queda vivo en segundo plano. Con varios
usuarios generando documentos simultáneamente, acabas con decenas de
instancias de Chrome consumiendo memoria hasta que el servidor muere.

---

## 3. EL ROUTE HANDLER COMPLETO

```typescript
// app/api/documentos/reserva/route.ts
import puppeteer from "puppeteer";
import { NextRequest, NextResponse } from "next/server";
import { generarHtmlReserva } from "@/lib/plantillas/reserva";
import prisma from "@/lib/prisma";

export async function POST(request: NextRequest) {
  const { reservaId } = await request.json();

  const reserva = await prisma.reserva.findUnique({
    where: { id: reservaId },
    include: { expedicion: true }
  });

  if (!reserva) {
    return NextResponse.json({ error: "Reserva no encontrada" }, { status: 404 });
  }

  const html = generarHtmlReserva(reserva);

  let browser;
  try {
    browser = await puppeteer.launch({ headless: true });
    const pagina = await browser.newPage();
    await pagina.setContent(html, { waitUntil: "domcontentloaded" });

    const pdfBuffer = await pagina.pdf({
      format: "A4",
      printBackground: true
    });

    return new Response(pdfBuffer, {
      headers: {
        "Content-Type": "application/pdf",
        "Content-Disposition": `attachment; filename="reserva-${reservaId}.pdf"`
      }
    });
  } finally {
    await browser?.close();
  }
}
```

**Los headers que hacen que funcione:**

```
Content-Type: application/pdf
  → le dice al navegador que es un PDF, no texto

Content-Disposition: attachment; filename="..."
  → fuerza la descarga con ese nombre de archivo
  → sin esto, el navegador intentaría mostrar el PDF en pantalla
```

---

## 4. LAS PLANTILLAS — HTML COMO FUNCIÓN

La plantilla es una función que recibe datos y retorna un string HTML.
No es un componente React — es HTML puro, porque Puppeteer no entiende
JSX.

```typescript
// src/lib/plantillas/reserva.ts
import { Reserva, Expedicion } from "@/generated/prisma/client";
import { formatearRut, formatearPrecio, formatearFecha } from "@/lib/formatos-cl";

type ReservaConExpedicion = Reserva & { expedicion: Expedicion };

export function generarHtmlReserva(reserva: ReservaConExpedicion): string {
  return `
    <!DOCTYPE html>
    <html lang="es">
    <head>
      <meta charset="UTF-8">
      <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 40px; }
        .encabezado { border-bottom: 2px solid #1a56db; margin-bottom: 24px; }
        .titulo { color: #1a56db; font-size: 24px; }
        .monto { font-size: 20px; font-weight: bold; color: #1f2937; }
      </style>
    </head>
    <body>
      <div class="encabezado">
        <h1 class="titulo">Comprobante de Reserva</h1>
        <p>Nexus Expediciones · ${formatearRut("76.543.210-K")}</p>
      </div>

      <h2>${reserva.expedicion.nombre}</h2>
      <p>Cliente: ${reserva.cliente}</p>
      <p>Personas: ${reserva.personas}</p>
      <p>Fecha: ${formatearFecha(reserva.creadaEn)}</p>
      <p class="monto">
        Total: ${formatearPrecio(reserva.personas * reserva.expedicion.precioBase)}
      </p>
    </body>
    </html>
  `;
}
```

**Por qué una función y no un archivo `.html`:**

Los datos son dinámicos. El nombre del cliente, el monto, la fecha — todo
cambia por reserva. Una función que retorna un string es la forma más
directa de combinar estructura fija con datos variables.

Es el mismo patrón de los template literals que usaste desde la Semana 1,
aplicado a escala de documento completo.

---

## 5. TRAMPAS DE PUPPETEER CON CSS

Puppeteer renderiza el HTML como Chrome, pero con diferencias importantes:

**1. Los estilos externos no se cargan por defecto.**

```typescript
// ❌ Este <link> falla — Puppeteer no puede hacer requests externos por defecto
<link rel="stylesheet" href="https://cdn.tailwindcss.com">

// ✅ Opciones:
// a) CSS inline en <style>
// b) Tailwind compilado localmente, resultado copiado como string
// c) Habilitar requests: pagina.setRequestInterception(true)
```

**2. `printBackground: true` es obligatorio.**

Sin él, todos los fondos de color (backgrounds) desaparecen. El PDF sale
en blanco y negro aunque el HTML tenga colores.

```typescript
await pagina.pdf({
  format: "A4",
  printBackground: true   // ← sin esto, los colores de fondo no aparecen
});
```

**3. Los saltos de página se controlan con CSS.**

```css
.no-romper { page-break-inside: avoid; }
.nueva-pagina { page-break-before: always; }
```

**4. Las fuentes externas pueden no cargar.**

Si usas Google Fonts con `<link>`, puede que no carguen a tiempo. Solución:

```typescript
await pagina.setContent(html, {
  waitUntil: "networkidle0"   // espera a que no haya requests pendientes
  // en vez de "domcontentloaded"
});
```

Pero `networkidle0` es más lento. Para fuentes, mejor embed en base64 o
usar fuentes del sistema (Arial, Georgia, monospace).

---

## 6. FORMATOS CHILENOS

Funciones de utilidad que van en `src/lib/formatos-cl.ts` y se usan en
todas las plantillas:

```typescript
// RUT: 12345678-9  →  "12.345.678-9"
export function formatearRut(rut: string): string {
  const [cuerpo, dv] = rut.replace(/\./g, "").split("-");
  return cuerpo.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + "-" + dv;
}

// Monto: 450000  →  "$450.000"
export function formatearPrecio(monto: number): string {
  return "$" + monto.toLocaleString("es-CL");
}

// IVA: 450000  →  { neto: 378151, iva: 71849, total: 450000 }
export function calcularIva(montoConIva: number) {
  const iva = Math.round(montoConIva - montoConIva / 1.19);
  return {
    neto: montoConIva - iva,
    iva,
    total: montoConIva
  };
}

// Fecha: Date  →  "lunes, 4 de agosto de 2026"
export function formatearFecha(fecha: Date): string {
  return fecha.toLocaleDateString("es-CL", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric"
  });
}
```

**El RUT chileno — estructura:**

```
76.543.210-K
│  └──────┘ └── dígito verificador (0-9 o K)
└── cuerpo con puntos cada 3 dígitos
```

La K como dígito verificador es válida en Chile. Si la formateas como
número la destruyes.

---

## 7. EL BOTÓN DE DESCARGA — CLIENTE

La descarga requiere un Client Component porque usa `fetch` y manipula
el DOM del navegador:

```typescript
"use client";

export function BotonDescargar({ reservaId }: { reservaId: string }) {
  async function descargar() {
    const respuesta = await fetch("/api/documentos/reserva", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reservaId })
    });

    if (!respuesta.ok) {
      console.error("Error al generar PDF");
      return;
    }

    const blob = await respuesta.blob();
    const url = URL.createObjectURL(blob);

    const enlace = document.createElement("a");
    enlace.href = url;
    enlace.download = `reserva-${reservaId}.pdf`;
    enlace.click();

    URL.revokeObjectURL(url);
  }

  return (
    <button onClick={descargar}>
      Descargar comprobante
    </button>
  );
}
```

**El truco del enlace invisible:**

No hay forma nativa de hacer que `fetch` descargue un archivo
directamente. El patrón es:

```
1. fetch → blob (bytes del PDF)
2. createObjectURL → URL temporal en el navegador
3. crear <a> con esa URL y click() programático
4. revokeObjectURL → liberar la memoria
```

Es feo, es indirecto, y es lo que hace todo el mundo. En Next.js 16 hay
Route Handlers que retornan la URL del archivo directamente, pero el
patrón de blob sigue siendo válido.

---

## 8. RENDIMIENTO — OPCIONAL PARA EL PROYECTO

Puppeteer lanza Chrome entero por cada PDF. Eso cuesta ~500ms mínimo.

Para producción hay tres estrategias:

```
1. SINGLETON — una instancia de browser que se reutiliza
   Más rápido, pero si el proceso de Chrome muere, hay que reiniciarlo

2. CACHÉ — guardar el PDF generado la primera vez
   Si los datos no cambian, servir el archivo ya generado
   Funciona bien para documentos históricos (una reserva ya confirmada)

3. QUEUE — encolar las generaciones y procesarlas en serie
   Evita tener 50 instancias de Chrome simultáneas
```

En esta semana usamos la versión simple (una instancia por request). Las
optimizaciones llegan cuando hay el problema real que las justifica.

---

## 9. SINTAXIS NUEVA DE ESTA SEMANA

### `URL.createObjectURL` · peso LIGERO

Crea una URL temporal que apunta a un objeto en memoria del navegador.

> ⚠ **Trampa:** la URL es válida mientras la página esté abierta. Si el
> usuario la guarda y la abre después, el archivo ya no existe. Por eso se
> descarga en el mismo click — no se guarda la URL para después.
>
> Segunda trampa: hay que llamar a `URL.revokeObjectURL` para liberar la
> memoria. Sin eso, el blob queda en memoria hasta que el usuario cierre la
> pestaña.

### `response.blob()` · peso LIGERO

Convierte la respuesta de `fetch` a un objeto `Blob` (datos binarios).

```typescript
const respuesta = await fetch("/api/documentos/reserva", { ... });
const blob = await respuesta.blob();   // los bytes del PDF
```

> ⚠ **Trampa:** `response.json()`, `response.text()` y `response.blob()`
> son mutuamente excluyentes. El body de una respuesta solo se puede leer
> una vez. Si llamas a `response.json()` y después a `response.blob()`,
> el segundo falla.

### `Buffer` en Node.js · peso LIGERO

`pagina.pdf()` devuelve un `Buffer` — la representación de bytes en Node.
El constructor `Response` de Next.js lo acepta directamente.

> ⚠ **Trampa:** `Buffer` existe en Node.js pero no en el navegador. Solo
> lo usas en el Route Handler (servidor). En el cliente trabajas con `Blob`.

---

## 10. FUERA DE ALCANCE ESTA SEMANA

```
Firma electrónica            requiere certificado digital y conocimiento
                             del estándar XML-DSig

DTE y comunicación con SII   XML específico, folios CAF, ambientes de
                             certificación — bloque propio

Generación de QR             librería aparte, se integra fácil pero es
                             otro tema

PDF fillable forms           PDFKit u otra librería; Puppeteer genera
                             desde HTML, no manipula PDF existentes

Almacenamiento de PDF        S3, Vercel Blob, etc. — el PDF se genera
                             y se descarga directo, sin guardar
```

---

*Cheat Sheet Semana 15 — Generación de Documentos PDF*
*Prerrequisitos: Semana 06 (async/await) · Semana 09 (TypeScript) · Semana 12 (Next.js, Route Handlers) · Semana 13 (Tailwind) · Semana 14 (Prisma)*
