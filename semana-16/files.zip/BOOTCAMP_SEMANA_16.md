# 📘 BOOTCAMP SEMANA 16
## Autenticación y Autorización · Clerk · Next.js

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-08-06
Semana en curso de Óscar al generar: 05 (proyecto semanal)
Distancia estimada hasta el uso: ~10 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes: documentación oficial de Clerk (referencia de Next.js SDK,
         clerkMiddleware, auth, Route Handlers, página de errores),
         guía de autenticación Next.js 2026 de Clerk, artículo de Core 3.
         Consultadas 2026-08-06.
Referencia: Clerk Core 3 (marzo 2026) · Next.js 16
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

---

> **Flujo de la semana:** el Cheat Sheet se entrega por partes, día a día,
> como guion de la clase de activación. No lo leas completo de antemano.

---

## ⚠️ NOTA DE ALCANCE

Esta semana arregla un fallo que tu aplicación tiene desde la Semana 12 y
que no se ve en pantalla: **no tiene usuarios**.

Cualquiera que abra la URL ve todas las reservas y puede modificar
cualquiera. El "rol admin" del contexto de la Semana 11 es un selector de
mentira que no protege nada.

Y hay una segunda mitad que importa más: **autenticar no es autorizar.**
Clerk resuelve el login casi entero. Que un usuario no pueda ver los datos
de otro lo escribes tú, y es donde están los errores caros.

**Prerrequisito real:** Semanas 12 y 14 completadas. Sin Server Actions y sin
base de datos, no hay nada que proteger.

**Transición de fase:** esta semana marca el paso de "construir desde cero" a
"implementar features sobre un sistema existente". No creas una aplicación
nueva — modificas la que ya tienes, sin romperla. Es otro tipo de trabajo.

---

## 🗓 DÍA 1 — EL PROBLEMA Y EL SETUP

### 🎯 Objetivo
Ver el agujero que tiene tu aplicación, y dejar Clerk funcionando con login
real.

---

### 📖 El problema real

Abre tu aplicación y mira la lista de reservas.

Ahora imagina que la despliegas y le pasas la URL a alguien. Esa persona ve
todas las reservas de todos, con nombres de clientes y montos. Y puede
cancelar cualquiera.

No es un fallo que se pueda parchear con un `if`. Es que **la aplicación no
tiene el concepto de "usuario"**.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

El primer instinto suele ser: una tabla `Usuario` en Prisma, con correo y
contraseña, y un formulario de login.

---

### 📖 Por qué eso es mala idea

Guardar contraseñas correctamente es más difícil de lo que parece:

```
· Hash con bcrypt o argon2, nunca en texto plano
· Sal única por contraseña
· Gestión de sesiones con tokens firmados y rotación
· Recuperación de contraseña por correo, con tokens de un solo uso
· Protección contra fuerza bruta
· Verificación de correo
· Y si mañana quieren entrar con Google, todo otra vez
```

Cada uno de esos puntos tiene formas sutiles de hacerse mal, y hacerlas mal
significa filtrar las contraseñas de tus usuarios.

**No es que no se pueda aprender.** Es que es un tema de varias semanas por
sí solo, y en 2026 casi nadie lo escribe a mano en producción.

Clerk resuelve todo eso. Tú te concentras en lo que sí es tuyo: decidir quién
puede ver qué.

---

### 📖 Dos conceptos distintos

```
AUTENTICACIÓN  →  ¿quién eres?       login, sesión, identidad
AUTORIZACIÓN   →  ¿qué puedes hacer?  permisos, roles, propiedad del dato
```

Clerk cubre la primera. **La segunda es tuya**, y es el tema de los Días 3 y 4.

Mantén la distinción clara desde hoy: mucha gente instala Clerk, ve el botón
de login funcionando, y cree que su aplicación está protegida. No lo está.

---

### 📖 Las tres piezas del setup

**1. El proxy** — `proxy.ts` en la raíz:

```typescript
import { clerkMiddleware } from "@clerk/nextjs/server";

export default clerkMiddleware();

export const config = {
  matcher: [
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    "/(api|trpc)(.*)",
    "/__clerk/(.*)"
  ]
};
```

Adjunta la sesión a cada petición que coincida. Sin esto, `auth()` no tiene
de dónde leer.

⚠ En Next.js 15 o anterior el archivo se llama `middleware.ts`.

**2. El proveedor** — en `app/layout.tsx`:

```tsx
import { ClerkProvider } from "@clerk/nextjs";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="es">
        <body>{children}</body>
      </html>
    </ClerkProvider>
  );
}
```

Es un contexto de React. Exactamente lo de la Semana 11 — un valor publicado
arriba que cualquier descendiente puede leer.

**3. Los componentes** — en tu cabecera:

```tsx
import { SignInButton, SignUpButton, UserButton, Show } from "@clerk/nextjs";

<Show when="signed-out">
  <SignInButton />
  <SignUpButton />
</Show>

<Show when="signed-in">
  <UserButton />
</Show>
```

Pantalla de login, registro, recuperación de contraseña y menú de usuario, ya
hechos.

---

### 📖 El error que vas a ver

```
auth() was called but Clerk can't detect usage of clerkMiddleware()
```

Casi siempre es una de dos cosas: falta el `<ClerkProvider>`, o el matcher
del `proxy.ts` no cubre esa ruta.

Vale la pena leerlo con calma cuando aparezca — es un buen ejemplo de un
mensaje de error que **sí** te dice qué pasa, si sabes interpretarlo.

---

### 📖 Mini-ejercicio de comprensión

`<ClerkProvider>` envuelve toda la aplicación y `clerkMiddleware()` corre en
cada petición. Los dos parecen hacer lo mismo.

¿Cuál sirve al servidor y cuál al cliente? ¿Por qué hacen falta los dos?

---

### 🛠 EJERCICIOS DÍA 1

**Ejercicio 1** — cuenta y claves

Crea una cuenta en Clerk, una aplicación nueva, y copia las dos claves a
`.env.local`. Verifica que `.env.local` está en `.gitignore`.

Haz un commit y revisa en GitHub que el archivo no aparece. Si aparece,
rota las claves desde el panel.

**Ejercicio 2** — las tres piezas

Instala `@clerk/nextjs`, crea el `proxy.ts`, envuelve el layout y agrega los
botones a la cabecera. Regístrate con tu propio correo y comprueba que el
`UserButton` muestra tu sesión.

**Ejercicio 3** — provoca el error

Comenta el `<ClerkProvider>` y carga una página que use `auth()`. Lee el
mensaje de error completo y documenta en `NOTAS.md` qué dice y por qué.

Vuelve a ponerlo. Este ejercicio es sobre leer errores, no sobre resolverlos.

---

**Cuando termines avísame — valido el Día 1.** ✅

---

## 🗓 DÍA 2 — LEER AL USUARIO

### 🎯 Objetivo
Obtener la identidad del usuario en servidor y en cliente, y saber cuál usar
en cada caso.

---

### 📖 El problema real

Ya hay sesión. Ahora necesitas saber **quién** es, para mostrar su nombre y
para filtrar sus datos.

---

### 📖 En el servidor — dos funciones

```typescript
import { auth, currentUser } from "@clerk/nextjs/server";

const { userId, isAuthenticated } = await auth();

const user = await currentUser();
// user.firstName, user.emailAddresses[0].emailAddress
```

**La diferencia que importa:**

```
auth()          lee el token de la petición. No sale de tu servidor.
                Rápido. Te da identificadores.

currentUser()   hace una petición HTTP a la API de Clerk.
                Más lento. Te da el objeto completo.
```

**La regla:** `auth()` por defecto. `currentUser()` solo cuando necesitas
nombre, correo o imagen.

Llamar `currentUser()` para obtener el `userId` es pagar una petición de red
por un dato que `auth()` te daba gratis.

---

### 📖 En el cliente

```tsx
"use client";
import { useUser, useAuth } from "@clerk/nextjs";

export function PerfilBoton() {
  const { user, isLoaded } = useUser();
  const { signOut } = useAuth();

  if (!isLoaded) {
    return <p>Cargando...</p>;
  }

  return (
    <div>
      <span>{user?.firstName}</span>
      <button onClick={() => signOut()}>Salir</button>
    </div>
  );
}
```

**`isLoaded` no es opcional.** En el primer render, `user` es `null` aunque
haya sesión — Clerk todavía no resolvió. Sin comprobarlo, muestras "no hay
sesión" durante un parpadeo en cada carga.

Es el mismo problema del estado de carga de la Semana 10, con otro nombre.

---

### 📖 Servidor o cliente — cómo decidir

```
Necesitas el usuario para CONSULTAR DATOS   → servidor, siempre
Necesitas el usuario para MOSTRAR su nombre → servidor si la página ya es
                                               Server Component
Necesitas reaccionar a que cierre sesión    → cliente
Necesitas el usuario dentro de un onClick   → cliente
```

**La regla que hereda de la Semana 12:** empieza en el servidor. Baja al
cliente solo si hay interactividad de por medio.

---

### 📖 Mini-ejercicio de comprensión

```typescript
const user = await currentUser();
const reservas = await prisma.reserva.findMany({
  where: { usuarioId: user.id }
});
```

Esto funciona. ¿Por qué es innecesariamente caro, y cómo se escribe mejor?

---

### 🛠 EJERCICIOS DÍA 2

**Ejercicio 1** — saludo personalizado

En el dashboard, muestra "Hola, [nombre]" con el nombre real del usuario.
Decide si lo haces en servidor o en cliente, y justifica en un comentario.

**Ejercicio 2** — `PerfilUsuario` en cliente

Client Component con el nombre, el correo y un botón de cerrar sesión.
Maneja `isLoaded` correctamente.

**Ejercicio 3** — diagnóstico

Quita la comprobación de `isLoaded` y recarga la página varias veces con la
sesión iniciada. Documenta qué observas en el instante inicial.

**Ejercicio 4** — juzga este código

```typescript
// Server Component
export default async function Pagina() {
  const user = await currentUser();
  const nombre = user.firstName;
  const reservas = await prisma.reserva.findMany({
    where: { usuarioId: user.id }
  });
  return <Lista nombre={nombre} reservas={reservas} />;
}
```

Tiene un problema de rendimiento y otro de robustez. Encuentra los dos y
reescríbelo.

> Pista para el segundo: ¿qué pasa si no hay sesión?

---

**Cuando termines avísame — valido el Día 2.** ✅

---

## 🗓 DÍA 3 — DATOS QUE PERTENECEN A ALGUIEN

### 🎯 Objetivo
Que cada usuario vea solo sus datos, y entender por qué autenticar no basta.

---

### 📖 El problema real

Tienes login. Un usuario entra y ve... todas las reservas de todos.

Autenticar respondió "quién eres". No respondió "qué puedes ver".

---

### 📖 El esquema

```prisma
model Reserva {
  id         String   @id @default(cuid())
  cliente    String
  personas   Int
  estado     String   @default("pendiente")

  usuarioId  String
  @@index([usuarioId])

  expedicionId String
  expedicion   Expedicion @relation(fields: [expedicionId], references: [id])
}
```

⚠ **`usuarioId` es un string, no una relación.** El `userId` de Clerk es algo
como `user_2abc...`, y ese usuario **vive en Clerk, no en tu base de datos**.
No puedes hacer una clave foránea hacia una tabla que no existe.

Es una diferencia real con `expedicionId`, que sí es una relación de Prisma
con integridad referencial garantizada. Aquí guardas un identificador externo
y la coherencia depende de ti.

**El `@@index` importa:** vas a filtrar por `usuarioId` en cada consulta. Sin
índice, PostgreSQL recorre la tabla entera cada vez.

---

### 📖 Filtrar en cada consulta

```typescript
const { userId } = await auth();

// ❌ todo el mundo ve todo
const reservas = await prisma.reserva.findMany();

// ✅
const reservas = await prisma.reserva.findMany({
  where: { usuarioId: userId }
});
```

---

### 📖 El caso que más se olvida — IDOR

Este es el importante.

```typescript
// ❌ Alguien cambia el id en la URL y ve la reserva de otro
const reserva = await prisma.reserva.findUnique({
  where: { id: reservaId }
});
```

El usuario está autenticado. La consulta funciona. Y le entregas datos
ajenos.

```typescript
// ✅ El id tiene que ser suyo
const reserva = await prisma.reserva.findFirst({
  where: { id: reservaId, usuarioId: userId }
});
```

Se llama **IDOR** — *Insecure Direct Object Reference*. No requiere ninguna
herramienta ni conocimiento técnico: basta cambiar un identificador en la
barra de direcciones.

**Fíjate en el cambio de método:** `findUnique` solo acepta campos únicos en
el `where`. Para combinar `id` con `usuarioId` necesitas `findFirst`.

---

### 📖 Lo mismo al escribir

```typescript
// ❌ Cancela la reserva de cualquiera
await prisma.reserva.update({
  where: { id: reservaId },
  data: { estado: "cancelada" }
});

// ✅ Comprobar propiedad primero
const propia = await prisma.reserva.findFirst({
  where: { id: reservaId, usuarioId: userId }
});

if (!propia) {
  return { error: "Reserva no encontrada" };
}

await prisma.reserva.update({
  where: { id: reservaId },
  data: { estado: "cancelada" }
});
```

⚠ **El mensaje de error dice "no encontrada", no "no tienes permiso".**
Deliberado: decir "no tienes permiso" confirma que esa reserva existe, y eso
ya es información que no le corresponde.

---

### 📖 La regla

> **Toda consulta que devuelva datos de un usuario lleva su `userId` en el
> `where`. Sin excepción.**

No hay atajo. No hay "esta consulta es interna así que da igual". Si el dato
pertenece a alguien, la consulta lo filtra.

---

### 📖 Mini-ejercicio de comprensión

```typescript
const reservas = await prisma.reserva.findMany({
  where: { usuarioId: userId },
  include: { expedicion: true }
});
```

Las expediciones son del catálogo público, no de ningún usuario.

¿Está bien que el `include` no lleve filtro de usuario? Justifica.

---

### 🛠 EJERCICIOS DÍA 3

**Ejercicio 1** — migración

Agrega `usuarioId` a `Reserva` con su índice. Ojo: la tabla ya tiene datos.
Decide qué hacer con las reservas existentes y justifica tu decisión.

**Ejercicio 2** — todas las lecturas

Recorre tu aplicación y agrega el filtro de usuario a **todas** las consultas
de reservas. Lista en `NOTAS.md` cuántas encontraste.

**Ejercicio 3** — provoca el IDOR

Con dos cuentas distintas, crea una reserva con cada una. Copia el id de la
reserva de la cuenta A y ábrela desde la cuenta B **antes** de aplicar el
filtro.

Documenta qué viste. Después aplica el filtro y repite.

Este ejercicio es el que hace que la regla se te quede.

**Ejercicio 4** — auditoría de escrituras

Revisa todas tus Server Actions. Para cada una, responde en un comentario:
¿comprueba propiedad antes de escribir? Si alguna no lo hace, arréglala.

---

**Cuando termines avísame — valido el Día 3.** ✅

---

## 🗓 DÍA 4 — DEFENSA EN PROFUNDIDAD

### 🎯 Objetivo
Entender por qué la protección va en varias capas, con un caso real que lo
demostró.

---

### 📖 El problema real

Ya tienes `createRouteMatcher` protegiendo rutas en el proxy. Parece
suficiente: si no hay sesión, no entras.

---

### 📖 Por qué no es suficiente

**CVE-2025-29927** fue una vulnerabilidad de Next.js que permitía **saltarse
el middleware entero** enviando una cabecera HTTP concreta.

Las aplicaciones que ponían toda su autorización ahí quedaron abiertas. Se
parcheó en las versiones 12.3.5, 13.5.9, 14.2.25 y 15.2.3.

Y aquí está el detalle que hay que entender bien:

> Que una aplicación estuviera expuesta o no **dependió de dónde estaba
> desplegada**, no de su código. Vercel resultó "incidentalmente invulnerable"
> porque su enrutamiento corre separado de la aplicación. Los despliegues
> autoalojados sí fueron afectados.

Dos aplicaciones con el mismo código, una segura y otra no, según el hosting.

**Y no fue un incidente aislado.** El patrón se repitió con **CVE-2026-45109**
en mayo de 2026, tras un arreglo incompleto de un bypass de prefetch.

---

### 📖 La conclusión

```
El proxy es CONVENIENCIA, no seguridad.
Sirve para redirigir al login sin que la página llegue a pintarse.

La autorización REAL va donde están los datos:
  · en el where de la consulta a Prisma
  · en la Server Action, antes de escribir
  · en el Route Handler, antes de responder

Si tu única defensa es el proxy, tu seguridad depende de tu proveedor
de hosting y de que no aparezca el próximo CVE.
```

**Idea mental:** el proxy es el portero que te dice que no puedes entrar. La
comprobación en la Server Action es la caja fuerte. Un portero se esquiva;
una caja fuerte hay que abrirla.

---

### 📖 Las tres capas, y qué hace cada una

```
CAPA 1 — proxy.ts
  Redirige al login antes de renderizar.
  Beneficio: experiencia. Sin parpadeo, sin página a medio pintar.
  NO es seguridad.

CAPA 2 — la página (Server Component)
  Comprueba isAuthenticated y redirige.
  Beneficio: si la capa 1 falla, la página no muestra nada.

CAPA 3 — Server Actions, Route Handlers y consultas
  Comprueba sesión Y propiedad del dato.
  Esta es la que importa. Es la única que protege los DATOS.
```

Si tuvieras que quedarte con una sola, sería la 3. Las otras dos son mejoras
de experiencia y red de seguridad.

---

### 📖 Un error que parece seguridad y no lo es

```tsx
// ❌ Esto NO protege nada
<Show when="signed-in">
  <BotonEliminar reservaId={reserva.id} />
</Show>
```

Esconder el botón no impide llamar a la Server Action. Cualquiera con las
herramientas de desarrollo puede invocarla directamente.

Ocultar la interfaz está bien **como experiencia de usuario**. Como
protección, no vale nada.

**La regla:** la interfaz decide qué se ve. El servidor decide qué se puede
hacer. Nunca al revés.

---

### 📖 Mini-ejercicio de comprensión

Tu aplicación tiene una Server Action `eliminarExpedicion` que solo debería
poder usar un administrador. El botón está dentro de un bloque que solo se
muestra si el rol es admin.

¿Está protegida? Si no, ¿qué falta y dónde va exactamente?

---

### 🔗 Conexión con la Enmienda 14

Este día es competencia de verificación pura: leer código ajeno y juzgar si
es seguro. El código de los ejercicios funciona — la pregunta no es si corre,
sino si aguanta a alguien que intente romperlo.

---

### 🛠 EJERCICIOS DÍA 4

**Ejercicio 1** — las tres capas

Implementa las tres en la ruta de reservas: matcher en el proxy, comprobación
en la página, comprobación en cada Server Action.

**Ejercicio 2** — audita este código

```typescript
"use server";

export async function actualizarReserva(reservaId: string, datos: DatosReserva) {
  await prisma.reserva.update({
    where: { id: reservaId },
    data: datos
  });
  revalidatePath("/reservas");
}
```

La ruta está protegida por el proxy y el botón solo aparece a usuarios con
sesión.

Enumera **todos** los problemas que le encuentres, ordenados por gravedad.
Después reescríbela.

**Ejercicio 3** — la prueba del cliente hostil

Sin usar la interfaz, invoca una de tus Server Actions desde la consola del
navegador con datos que no te pertenecen.

Si funciona, tienes un agujero. Documenta qué pasó y arréglalo.

**Ejercicio 4** — escribe la regla

En `NOTAS.md`, escribe con tus palabras la regla que resume este día. Debe
caber en dos frases y servirte dentro de seis meses.

---

**Cuando termines avísame — valido el Día 4.** ✅

---

## 🗓 DÍA 5 — ROLES REALES

### 🎯 Objetivo
Reemplazar el contexto de sesión simulado de la Semana 11 por roles de
verdad.

---

### 📖 El problema real

En la Semana 11 construiste un `ContextoSesion` con un selector para cambiar
entre "admin" y "guia". Era una simulación útil para practicar contexto.

Ahora ese selector es un agujero: cualquiera se declara admin.

---

### 📖 Metadata de usuario

Clerk permite guardar datos propios en cada usuario:

```typescript
const { sessionClaims } = await auth();
const rol = sessionClaims?.metadata?.rol;
```

El rol se asigna desde el panel de Clerk o por API, y viaja **dentro del
token de sesión**. Leerlo no cuesta una petición extra.

**Tipar la metadata:**

```typescript
// types/globals.d.ts
export {};

declare global {
  interface CustomJwtSessionClaims {
    metadata: {
      rol?: "admin" | "guia";
    };
  }
}
```

Con eso, `sessionClaims?.metadata?.rol` queda tipado y el autocompletado
funciona.

---

### 📖 Comprobar el rol donde importa

```typescript
"use server";
import { auth } from "@clerk/nextjs/server";

export async function eliminarExpedicion(expedicionId: string) {
  const { isAuthenticated, sessionClaims } = await auth();

  if (!isAuthenticated) {
    return { error: "No autorizado" };
  }

  if (sessionClaims?.metadata?.rol !== "admin") {
    return { error: "Solo administradores pueden eliminar expediciones" };
  }

  await prisma.expedicion.delete({ where: { id: expedicionId } });
  revalidatePath("/expediciones");
}
```

---

### 📖 Las dos trampas de la metadata

**1. La metadata pública es visible desde el cliente.**

Nunca guardes ahí nada sensible. El rol está bien; una clave de API no.

Y aunque el cliente pueda *leer* el rol, solo el servidor debe *confiar* en
él. Un cliente puede mentir sobre lo que dice tener.

**2. Cambiar la metadata no actualiza las sesiones activas.**

El rol viaja en el token. Si le quitas el rol admin a alguien, su token
actual sigue diciendo "admin" hasta que se refresque. Puede ser minutos.

Para revocación inmediata hace falta comprobar contra la API en cada
petición — más lento, y solo justificado en operaciones críticas.

---

### 📖 Migrar el contexto de la Semana 11

Tu `ContextoSesion` tenía esta forma:

```tsx
const [rol, setRol] = useState<"admin" | "guia">("admin");
```

Ahora el rol viene de Clerk y **no se puede cambiar desde el cliente**. El
selector desaparece.

Lo que puede quedarse es el contexto como mecanismo de distribución: leer el
rol en el servidor una vez y pasarlo hacia abajo. Pero el estado editable se
va.

**Y una decisión que te toca:** ¿sigue haciendo falta el contexto? En un
Server Component puedes llamar `auth()` directamente donde lo necesites, sin
propagar nada. Piénsalo antes de conservarlo por inercia.

---

### 📖 Mini-ejercicio de comprensión

```tsx
"use client";
const { user } = useUser();
const esAdmin = user?.publicMetadata?.rol === "admin";

return esAdmin ? <PanelAdmin /> : <PanelNormal />;
```

Esto funciona y muestra lo correcto. ¿Es seguro? ¿Qué protege y qué no?

---

### 🛠 EJERCICIOS DÍA 5

**Ejercicio 1** — asignar roles

Desde el panel de Clerk, asigna `rol: "admin"` a tu usuario y `rol: "guia"` a
una segunda cuenta de prueba. Verifica que `sessionClaims` lo refleja.

**Ejercicio 2** — tipar la metadata

Crea `types/globals.d.ts` con la declaración. Comprueba que el autocompletado
funciona y que TypeScript marca un rol inválido.

**Ejercicio 3** — desmontar la simulación

Elimina el selector de rol de la Semana 11 y sustituye el contexto simulado
por el rol real. Todas las comprobaciones de admin deben ejecutarse en el
servidor.

**Ejercicio 4** — decide

¿Conservas el `ContextoSesion` o lo eliminas? Escribe el argumento a favor y
en contra, y toma una decisión. Justifica en `NOTAS.md`.

No hay respuesta correcta. Lo que se evalúa es el criterio.

---

**Cuando termines avísame — valido el Día 5.** ✅

---

## 🗓 DÍA 6 — PROYECTO DE LA SEMANA

### 🏆 Nexus Multiusuario

> Nexus deja de ser tu aplicación local y pasa a ser una aplicación con
> usuarios. Cada uno ve lo suyo, los administradores gestionan el catálogo, y
> nadie accede a datos ajenos ni saltándose la interfaz.

---

### 📋 Lo que debe hacer

**1. Autenticación completa**
- Registro, login y cierre de sesión funcionando
- Rutas públicas: portada y catálogo de expediciones
- Rutas protegidas: reservas, dashboard, operaciones

**2. Datos por usuario**
- Cada usuario ve solo sus reservas
- Crear una reserva la asocia a quien la crea
- Un usuario no puede leer, editar ni cancelar reservas ajenas — ni por URL

**3. Roles**
- `admin` — gestiona expediciones y ve todas las reservas
- `guia` — ve las expediciones que tiene asignadas
- Sin rol — solo sus propias reservas
- Las comprobaciones viven en el servidor

**4. Las tres capas en todas las rutas protegidas**
- Matcher en el proxy
- Comprobación en la página
- Comprobación en cada Server Action y Route Handler

**5. Interfaz coherente**
- El nombre del usuario visible
- Los botones de admin solo se muestran a admins — y además están protegidos
- Mensajes de error que no filtran información

---

### 📋 Requisitos técnicos

```
✅ proxy.ts con matcher configurado
✅ <ClerkProvider> en el layout raíz
✅ usuarioId en Reserva, con índice
✅ TODAS las consultas de reservas filtran por usuarioId
✅ findFirst en vez de findUnique donde haya que combinar id + usuario
✅ Toda Server Action comprueba sesión antes de operar
✅ Toda operación de admin comprueba rol en el servidor
✅ Metadata tipada en types/globals.d.ts
✅ .env.local fuera de Git, verificado en GitHub
✅ Los errores de autorización no revelan si el recurso existe
❌ Sin autorización que dependa solo del proxy
❌ Sin autorización que dependa de ocultar la interfaz
❌ Sin consultas de reservas sin filtro de usuario
```

---

### 📋 Estructura sugerida

```
proxy.ts
src/
├── lib/
│   ├── prisma.ts
│   └── autorizacion.ts     ← helpers: requiereSesion(), requiereAdmin()
├── acciones/
├── consultas/
└── app/
    ├── layout.tsx           ← ClerkProvider
    ├── (publico)/
    │   ├── page.tsx
    │   └── expediciones/
    └── (privado)/
        ├── reservas/
        └── dashboard/
types/
└── globals.d.ts
```

`lib/autorizacion.ts` merece existir: si escribes la misma comprobación en
quince Server Actions, la olvidarás en la dieciséis.

---

### 💡 Las dos únicas pistas

**Pista 1** — Los grupos de rutas están en la Cheat Sheet, sección 8b. El
layout de `(privado)` puede comprobar la sesión una sola vez para todo lo que
cuelgue de él — pero recuerda que eso es la capa 2, no sustituye la capa 3.

**Pista 2** — Para las reservas que ya existen en tu base sin `usuarioId`, la
migración tiene que decidir algo. Piensa en las opciones antes de escribirla:
¿un valor por defecto? ¿borrarlas? ¿campo opcional? Cada una tiene
consecuencias distintas para el código que las consulta.

---

### ✅ Criterios de aprobación

```
□ Registro y login funcionan de punta a punta
□ Sin sesión, las rutas privadas redirigen al login
□ Con dos cuentas, ninguna ve las reservas de la otra
□ Cambiar el id en la URL NO da acceso a datos ajenos
□ Invocar una Server Action desde la consola con datos ajenos falla
□ Un usuario sin rol admin no puede eliminar expediciones, ni por la
  interfaz ni por invocación directa
□ Los mensajes de error no revelan si un recurso existe
□ .env.local no aparece en GitHub
□ Subido con commit descriptivo
```

**Verificación adversarial obligatoria:** crea dos cuentas y dedica quince
minutos a intentar acceder a los datos de una desde la otra. Por URL, por
consola, por lo que se te ocurra.

Documenta cada intento y su resultado en `NOTAS.md`. Si alguno funciona,
tienes trabajo pendiente.

---

**Cuando termines el proyecto, avísame. Hacemos la validación semanal interactiva.** 🎯

---

## 🔜 LO QUE VIENE

Con esta semana el sistema tiene usuarios reales. Los candidatos siguientes:

```
Formularios y validación (React Hook Form + Zod)
   El pie de la Semana 14 lo anticipaba: los datos persisten pero nada
   valida su forma antes de entrar

Zustand
   Único elemento del stack objetivo sin semana asignada

Testing
   La Enmienda 14 elevó la verificación a competencia de primer orden
   y no hay semana que la enseñe formalmente

Despliegue en Vercel
   Necesario para que exista un proyecto de portafolio visible
```

Se decide con Fase 0 cuando toque.

---

> ### 📘 PRÓXIMA SEMANA
> Pendiente de definir.

---

*Semana 16 — Autenticación con Clerk*
*Formato v4 — Constitución v2.2 · Protocolo QA con Fases 6b y 6c*
*Óscar — Full Stack Developer en formación 🇨🇱*
