# 🔬 REPORTE QA — BOOTCAMP SEMANA 16

> Documento interno de auditoría. No es material de estudio.
> Contiene el PRODUCTO de cada fase crítica, no su declaración (Enmienda 6).

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-08-06
Semana en curso de Óscar al generar: 05 (proyecto semanal)
Distancia estimada hasta el uso: ~10 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes REALES consultadas 2026-08-06:
   · clerk.com/docs/reference/nextjs/overview
   · clerk.com/docs/reference/nextjs/clerk-middleware
   · clerk.com/docs/reference/nextjs/app-router/auth
   · clerk.com/docs/reference/nextjs/app-router/route-handlers
   · clerk.com/docs/reference/nextjs/errors/auth-was-called
   · clerk.com/articles/nextjs-authentication-guide-2026
   · clerk.com/articles/complete-authentication-guide-for-nextjs-app-router
Referencia: Clerk Core 3 (marzo 2026) · Next.js 16
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

**Nota sobre la Fase 1:** tras el incidente de la Semana 15 —donde se
declararon hallazgos sin fuente— este reporte lista las URLs concretas
consultadas. Cada afirmación de la tabla de Fase 1 es trazable a una de
ellas.

---

## FASE 0 — DELIMITACIÓN CURRICULAR

Esta semana **no existía**. El roadmap no lista semanas más allá de la 14;
solo una progresión de fases:

```
Mes 1-4   → proyectos desde cero
Mes 5-8   → features sobre sistemas existentes
Mes 9-13  → refactoring, bugs, mantenimiento heredado
```

### Justificación del tema

```
1. La Semana 16 cae en la transición Mes 4 → Mes 5. Agregar autenticación
   a una aplicación que ya funciona ES implementar una feature sobre un
   sistema existente. Encaja con la fase, no solo con el temario.

2. Del stack objetivo declarado, solo Clerk y Zustand carecían de semana.

3. La Enmienda 19 fijó los proyectos de portafolio a partir de la Semana 12.
   Una aplicación sin usuarios no es un portafolio creíble.

4. Es la deuda de seguridad más antigua del sistema: desde la Semana 12
   la aplicación escribe datos que no pertenecen a nadie.
```

### Tema descartado y por qué

La planificación anterior asignaba a la Semana 16 el bloque de **XML y DTE
chileno**. La Enmienda 19 (2026-08-06) dejó la cuña tributaria como hipótesis
dormida y declaró explícitamente que las Semanas 16 y 17 no se generan hasta
que haya un dato del mundo real.

Generar XML/DTE ahora contradiría una decisión tomada el mismo día.

### Dentro del alcance

```
- Autenticación vs autorización: la distinción, y por qué se confunden
- Setup de Clerk: proxy.ts, ClerkProvider, componentes de UI
- Leer al usuario: auth(), currentUser(), useUser()
- Cuándo servidor y cuándo cliente
- Proteger rutas: createRouteMatcher, redirect, comprobación en acciones
- Defensa en profundidad: las tres capas y por qué el proxy no basta
- CVE-2025-29927 como caso real
- Propiedad del dato: usuarioId en el where de cada consulta
- IDOR y cómo se evita
- Roles con metadata de sesión, tipada
- Grupos de rutas para organizar público/privado
```

### Fuera del alcance, con razón documentada

| Excluido | Razón |
|---|---|
| Autenticación propia (hash, sesiones, tokens) | Tema de varias semanas por sí solo y con formas sutiles de hacerse mal. Se explica **por qué** no se hace, en el Día 1 |
| Organizaciones y multi-tenancy | Para B2B. El proyecto no lo necesita |
| Webhooks de Clerk | Sincronizar usuarios con la base propia. Útil pero es otro tema |
| MFA y passkeys | Se activan desde el panel, no en código |
| OAuth con proveedores propios | Clerk lo cubre desde su panel sin escribir código |
| Machine tokens | Para comunicación entre servicios |
| Rate limiting | Seguridad, sí, pero de otra familia |
| Precios de Clerk | Cambiaron en febrero de 2026. **No se afirma nada** porque no se verificó el detalle. Registrado como hueco deliberado |

### Prerrequisitos

```
Semana 10 → estados de carga (isLoaded es el mismo patrón)  ✔ verificado
Semana 11 → contexto (ClerkProvider es uno)                 ✔ verificado
              y el ContextoSesion SIMULADO que esta semana
              reemplaza por roles reales
Semana 12 → Server Actions, Server/Client, proxy.ts         ✔ verificado
              ⚠ dependencia FUERTE
Semana 14 → Prisma, migraciones, consultas                  ✔ verificado
              ⚠ dependencia FUERTE
```

**Hallazgo de continuidad favorable:** la Semana 12 ya documentó que
`middleware.ts` pasó a llamarse `proxy.ts` en Next.js 16. Esta semana lo
reutiliza sin contradicción.

---

## FASE 1 — INVESTIGACIÓN

| Afirmación | Fuente | Impacto |
|---|---|---|
| Clerk **Core 3** salió el 3 de marzo de 2026 | artículo App Router de Clerk | Marca qué material previo está obsoleto |
| En Next.js 16 el archivo es **`proxy.ts`**; en 15 o anterior, `middleware.ts`. `clerkMiddleware()` es la misma función | clerk.com/nextjs-authentication | Setup del Día 1 |
| El matcher recomendado incluye `/__clerk/(.*)` | guía 2026 de Clerk | Incluido literal |
| **`<Show when="signed-in">`** es el componente actual | guía App Router (Core 3) | Sustituye a `<SignedIn>`/`<SignedOut>` |
| **`auth.protect()`** — sin paréntesis en `auth` | docs de Route Handlers | Corrige `auth().protect()` de material previo |
| `auth()` devuelve **`isAuthenticated`** | docs de Route Handlers | Se usa en vez de comprobar `userId` |
| `auth()` requiere `clerkMiddleware()` corriendo | docs de auth() | Explica el error más común |
| El error *"auth() was called but Clerk can't detect clerkMiddleware()"* se debe a falta de `<ClerkProvider>` o a matcher incompleto | página de errores de Clerk | Día 1, sección propia |
| En Next.js 16, `auth()` y `currentUser()` leen `headers()`; llamarlas dentro de `'use cache'` lanza error | guía 2026 de Clerk | Trampa documentada |
| `currentUser()` devuelve el objeto Backend User (petición a la API) | docs de Route Handlers | Base del criterio auth() vs currentUser() |
| Clerk recomienda `/dashboard/:path*` sobre `/dashboard(.*)` | docs de clerkMiddleware | Adoptado |
| **CVE-2025-29927**: bypass de middleware. Parcheado en 12.3.5, 13.5.9, 14.2.25, 15.2.3 | guía 2026 de Clerk | **Día 4 completo** |
| Vercel fue "incidentalmente invulnerable" por routing desacoplado; los autoalojados sí afectados | guía 2026 de Clerk | La lección central del Día 4 |
| **CVE-2026-45109**, mayo 2026, tras arreglo incompleto de bypass de prefetch. Parcheado en 15.5.18 y 16.2.6 | guía 2026 de Clerk | Demuestra que no fue incidente aislado |

### Qué habría salido mal sin esta fase

```
El material habría enseñado:

  middleware.ts              → nombre incorrecto en Next.js 16
  <SignedIn> / <SignedOut>   → reemplazados en Core 3
  auth().protect()           → sintaxis anterior a marzo 2026
  auth().userId para sesión  → existe isAuthenticated

Los cuatro son el patrón dominante en el material disponible, porque
fueron correctos hasta hace meses.

Y sin el hallazgo del CVE, el Día 4 no existiría: la semana habría
enseñado a proteger con el proxy sin explicar por qué eso no basta.
```

### Hueco declarado de la Fase 1

```
Los precios de Clerk cambiaron el 5 de febrero de 2026. NO se verificó
el detalle del plan gratuito ni sus límites.

El material NO afirma nada sobre precios. Si al llegar a esta semana el
plan gratuito no cubre el uso del proyecto, hay que revisarlo.
```

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ CLERK_SECRET_KEY sin prefijo NEXT_PUBLIC_ — el prefijo la expondría
✔ ClerkProvider es un contexto de React; clerkMiddleware corre por petición
✔ auth() lee el token de la petición; currentUser() hace petición HTTP
✔ En el primer render del cliente, user es null aunque haya sesión
✔ El userId de Clerk es un string externo, no una clave foránea de Prisma
✔ findUnique solo acepta campos únicos; combinar id + usuarioId exige findFirst
✔ Ocultar un botón no impide invocar la Server Action
✔ La metadata pública es legible desde el cliente
✔ Cambiar metadata no refresca sesiones activas de inmediato
✔ createRouteMatcher devuelve una FUNCIÓN, no un booleano
✔ Los grupos de rutas entre paréntesis no aparecen en la URL
✔ Dos grupos no pueden resolver a la misma ruta
✔ Decir "no tienes permiso" confirma que el recurso existe
```

### Corrección aplicada durante esta fase

```
Formulación incorrecta (borrador):
  "Protege tus rutas con clerkMiddleware y createRouteMatcher"

Por qué era incorrecta:
  Presenta el proxy como LA solución de seguridad. Es exactamente lo
  que CVE-2025-29927 demostró que falla. Un alumno que aprenda esto
  construye aplicaciones cuya seguridad depende del hosting.

Formulación corregida:
  Tres capas explícitas, con el rol de cada una declarado, y el Día 4
  entero dedicado a por qué la capa 3 es la única que protege datos.
  El proxy se presenta como conveniencia, no como seguridad.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ Terminología estable: "autenticación", "autorización", "capa", "propiedad"
✔ El Día 1 separa autenticación de autorización y anuncia que la segunda
   llega en los Días 3 y 4 — se cumple
✔ El Día 3 (propiedad del dato) prepara el Día 4 (por qué en varias capas)
✔ El Día 5 cierra explícitamente el ContextoSesion simulado de la Semana 11
✔ La tabla de decisión de la Cheat Sheet §9 reúne los cinco días
✔ Ningún día introduce una solución antes de mostrar el problema
```

### Anclaje en trabajo previo de Óscar

```
· Día 1 → ClerkProvider ES el contexto de la Semana 11
· Día 2 → isLoaded es el estado de carga de la Semana 10, con otro nombre
· Día 2 → "empieza en el servidor" es la regla de la Semana 12
· Día 3 → el where con usuarioId extiende el cruce por ID de PS-1
· Día 3 → la distinción entre relación de Prisma y string externo conecta
          con la integridad referencial de la Semana 14
· Día 5 → el ContextoSesion de la Semana 11 era una simulación; aquí se
          sustituye por roles reales. El material lo dice explícitamente
```

### Verificación de ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — cuenta y claves | Proyecto D6, criterio de aprobación |
| D1 — las tres piezas | Proyecto D6, requisito explícito |
| D1 — provocar el error | Ninguno. **Justificado:** lectura de errores (Enmienda 14) |
| D2 — saludo personalizado | Proyecto D6 |
| D2 — PerfilUsuario en cliente | Proyecto D6 |
| D2 — diagnóstico de isLoaded | Ninguno. **Justificado:** experiencia del fallo |
| D2 — juzgar código | Ninguno. **Justificado:** verificación (Enmienda 14) |
| D3 — migración de usuarioId | Proyecto D6, requisito explícito |
| D3 — todas las lecturas | Proyecto D6, requisito explícito |
| D3 — provocar el IDOR | Proyecto D6, criterio de aprobación |
| D3 — auditoría de escrituras | Proyecto D6 |
| D4 — las tres capas | Proyecto D6, requisito explícito |
| D4 — auditar código | Ninguno. **Justificado:** verificación (Enmienda 14) |
| D4 — cliente hostil | Proyecto D6, criterio de aprobación |
| D4 — escribir la regla | Ninguno. **Justificado:** consolidación |
| D5 — asignar roles | Proyecto D6, requisito explícito |
| D5 — tipar metadata | Proyecto D6, requisito explícito |
| D5 — desmontar la simulación | Proyecto D6 |
| D5 — decidir sobre el contexto | Ninguno. **Justificado:** criterio |

**Cero huérfanos sin justificar.**

---

## FASE 6b — AUDITORÍA DE CONFORMIDAD

Verificación automática ejecutada sobre los dos archivos:

```
Indentación impar:        0
Sentencias sin punto y coma: 0
Ocurrencias de == o !=:   0
```

```
□✔ Constitución Parte 3
     Nombres en español: usuarioId, requiereSesion, LayoutPrivado,
     PerfilBoton, esAdmin
     ⚠ Excepción documentada: los identificadores de la API de Clerk
       (userId, sessionClaims, isAuthenticated, isLoaded) se mantienen
       en inglés. Son de la librería, no del código de Óscar

□✔ .prettierrc
     semi: true · tabWidth: 2 · singleQuote: false → conformes

□✔ Enmienda 14 — competencia de verificación
     D1 Ej.3 (leer un error), D2 Ej.4 (juzgar código),
     D3 Ej.3 (provocar el IDOR), D4 Ej.2 (auditar por gravedad),
     D4 Ej.3 (cliente hostil), D6 (verificación adversarial obligatoria)
     Seis ejercicios de juicio. Es la semana con más carga de
     verificación de todo el bootcamp — coherente con el tema

□✔ Enmienda 17 — rol del Cheat Sheet
     El bootcamp abre con "se entrega por partes, día a día", no con
     "léelo completo"

□✔ Enmienda 19 — proyectos ficticios
     El proyecto del D6 es Nexus. No exige usuarios reales ni validación
```

---

## FASE 6c — COBERTURA TÉCNICA

**Primera ejecución de esta fase** (creada por la Enmienda 18 el 2026-08-05).

### Técnicas exigidas por ejercicios, y dónde se enseñan

| Técnica | Cheat Sheet | Bootcamp | Estado |
|---|---|---|---|
| `clerkMiddleware()` + matcher | §2 | D1 | ✅ |
| `<ClerkProvider>` | §2 | D1 | ✅ |
| `<Show>`, `SignInButton`, `UserButton` | §2 | D1 | ✅ |
| `auth()` y sus campos | §3, §8 | D2 | ✅ |
| `currentUser()` | §3 | D2 | ✅ |
| `useUser()` + `isLoaded` | §3 | D2 | ✅ |
| `useAuth()` → `signOut` | §3 | D2 | ✅ |
| `createRouteMatcher()` | §4, §8 | D4 | ✅ |
| `redirect()` de next/navigation | §4 | D3 | ⚠ ver abajo |
| `usuarioId` en el where | §6 | D3 | ✅ |
| `findFirst` vs `findUnique` | §6 | D3 | ✅ |
| `@@index` en Prisma | §6 | D3 | ✅ |
| `sessionClaims?.metadata` | §7 | D5 | ✅ |
| `declare global` para tipar claims | — | D5 (cuerpo) | ✅ |
| **Grupos de rutas `(publico)`** | **§8b** | D6 | ✅ **corregido** |

### HUECO DETECTADO Y CORREGIDO

```
TÉCNICA: grupos de rutas — carpetas entre paréntesis

DÓNDE SE EXIGÍA: estructura sugerida del proyecto del Día 6

DÓNDE SE ENSEÑABA: en ningún sitio.

AGRAVANTE: la Pista 1 del proyecto decía literalmente "es una
característica de Next.js que no vimos en la Semana 12 pero que aquí
encaja: búscala como route groups".

Es decir: el material RECONOCÍA el hueco y lo trasladaba al alumno.
Eso es exactamente lo que la Enmienda 18 prohíbe — "NUNCA dejar el
hueco confiando en que el alumno lo deduzca o lo busque".

CORRECCIÓN APLICADA:
  + Sección 8b nueva en la Cheat Sheet: qué son, la estructura, el
    layout protegido como caso de uso, y dos trampas (colisión de
    rutas, y que el layout es capa 2 y no sustituye la capa 3)
  + Pista 1 reescrita: ahora apunta a la sección, no manda a buscar
```

### Nota sobre `redirect()`

Se usa en el Día 3 sin haberse enseñado en esta semana. **No es un hueco:**
pertenece a la Semana 12 (Next.js), donde `next/navigation` es tema central.
Cumple el criterio "enseñado en una semana anterior ya validada".

### Valor de la primera ejecución

La Fase 6c encontró un hueco en la primera semana donde se aplicó. Confirma
el diagnóstico de la Enmienda 18: **no era un descuido de la Semana 05, era
un agujero estructural del protocolo.**

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS

```
RECHAZADA 1: "Instala Clerk y tu aplicación queda protegida"

Razón: falso y peligroso. Clerk resuelve autenticación. La autorización
—qué puede ver y hacer cada usuario— la escribe el alumno. Quien crea
esto despliega una app donde cualquiera con cuenta ve los datos de todos.

Reemplazo adoptado: el Día 1 separa los dos conceptos ANTES de instalar
nada, y anuncia que la segunda mitad llega en los Días 3 y 4.
```

```
RECHAZADA 2: "Protege las rutas con el middleware"

Razón: es lo que CVE-2025-29927 demostró que falla. Ver Fase 4.

Reemplazo adoptado: tres capas con rol declarado, y el Día 4 entero
dedicado al caso real.
```

```
RECHAZADA 3: "Oculta los botones de administrador a los usuarios normales"

Razón: presenta una decisión de INTERFAZ como una medida de seguridad.
El alumno que lo crea deja Server Actions abiertas y piensa que están
protegidas porque el botón no se ve.

Reemplazo adoptado: sección explícita en el Día 4 —"un error que parece
seguridad y no lo es"— con la regla: la interfaz decide qué se ve, el
servidor decide qué se puede hacer.
```

```
RECHAZADA 4: "Usa currentUser() para obtener los datos del usuario"

Razón: incompleto de forma cara. currentUser() hace una petición HTTP
a la API de Clerk. Usarla solo para obtener el userId paga red por un
dato que auth() da gratis, en cada carga de página.

Reemplazo adoptado: criterio explícito de cuándo cada una, más el
Ejercicio 4 del Día 2 que obliga a detectar ese desperdicio en código
ajeno.
```

```
RECHAZADA 5: "Guarda el rol en la base de datos junto al usuario"

Razón: defendible, pero introduce una consulta extra en cada
comprobación de permiso y crea una segunda fuente de verdad que puede
desincronizarse de Clerk.

Reemplazo adoptado: metadata de sesión, que viaja en el token y no
cuesta petición. CON su desventaja documentada: los cambios de rol no
se propagan hasta que el token se refresca. El alumno conoce el
trade-off, no solo la recomendación.
```

### Ataques intentados sin hallazgo

```
✔ ¿Se enseña algún patrón obsoleto? Verificado contra Fase 1: proxy.ts,
  <Show>, auth.protect(), isAuthenticated — todos actuales
✔ ¿Algún día da la solución antes del dolor? El D1 abre con el agujero
  de la aplicación existente; el D3 con "tienes login y ves todo"
✔ ¿El proyecto es verificable? Sí, y de forma adversarial: dos cuentas
  intentando acceder a los datos de la otra
✔ ¿Las secciones "cuándo NO" tienen peso? Presentes en auth vs
  currentUser, servidor vs cliente, y en las dos trampas de la metadata
```

---

## VERIFICACIÓN DE LA ENMIENDA 10 — SINTAXIS NUEVA POR PESO

| Sintaxis | Peso | Justificación | Entrega |
|---|---|---|---|
| `await auth()` | **MEDIA** | Función asíncrona con contrato propio y dependencia del middleware. Se enseña en el cuerpo del D2 | Definición + ejemplo + 2 trampas (requiere middleware, no va en `'use cache'`) |
| `auth.protect()` | **LIGERA** | Una llamada | Definición + trampa (sin paréntesis en `auth`) |
| `createRouteMatcher()` | **LIGERA** | Devuelve una función | Definición + trampa (es función, no booleano) |
| `declare global` | **LIGERA** | Declaración de tipos, se copia una vez | Enseñada en el cuerpo del D5, con ejemplo completo |
| Grupos de rutas | **LIGERA** | Convención de carpetas | Cheat Sheet §8b + 2 trampas |

```
✔ Ninguna PESADA de contrabando
✔ Ninguna en el Día 1 sin explicación previa
✔ Ninguna en el mismo ejercicio donde se evalúa competencia nueva
```

---

## HALLAZGOS ABIERTOS

### 1. Cadena de dependencias sin resolver

Esta semana depende de la 14 y la 12. Las referencias a **PS-4** en las
Semanas 11, 12 y 14 siguen sin ajustarse desde que la Enmienda 16 lo eliminó.

Es la deuda más antigua del sistema y ya afecta a cinco semanas.

### 2. La Semana 09 sigue sin auditar

Con defecto conocido (`ts-node` obsoleto) y sin Fase 6b ni 6c.

### 3. Precios de Clerk sin verificar

No se afirma nada en el material. Si al llegar el plan gratuito no cubre el
uso del proyecto, hay que revisar la elección.

### 4. Fase 6c pendiente en las Semanas 06 a 15

Esta es la primera semana que la incorpora desde el diseño. Las anteriores
no la tienen ejecutada, y la Semana 05 solo tras el hallazgo de Óscar.

**Recomendación de la Enmienda 18 vigente:** ejecutarla justo antes de
empezar cada semana, junto con la regeneración del bloque perecedero.

### 5. El Día 4 asume que el CVE sigue siendo relevante

Dentro de diez meses, CVE-2025-29927 será historia antigua. **La lección
sigue valiendo** —la autorización no vive en el middleware— pero conviene
comprobar si hay un caso más reciente que ilustre mejor el punto.

El material ya cita dos casos (2025 y 2026), lo que refuerza que es un patrón
y no un accidente.

---

## ADVERTENCIA SOBRE LA VIGENCIA

Generado en agosto de 2026 para usarse aproximadamente en junio de 2027.

```
CRÍTICO → nombres de API de Clerk (<Show>, auth.protect, isAuthenticated).
          Core 3 es de marzo 2026; puede haber Core 4
CRÍTICO → proxy.ts vs middleware.ts según versión de Next.js
CRÍTICO → el matcher recomendado
ALTO    → precios y límites del plan gratuito (sin verificar)
MEDIO   → la forma de tipar sessionClaims
BAJO    → autenticación vs autorización como conceptos
BAJO    → defensa en profundidad y las tres capas
BAJO    → IDOR y el filtrado por propiedad
BAJO    → los CVE citados (son históricos, no cambian)
```

**Verificar sin excepción antes de usar:** el bloque perecedero completo y la
versión de `@clerk/nextjs`.

**Nota de precedencia:** si la documentación oficial de Clerk contradice este
material, gana la documentación.

---

*Reporte QA Semana 16 — 2026-08-06*
*Constitución v2.2 · Fases 0-8 incluyendo 6b y 6c*
*Primera semana con Fase 6c ejecutada desde el diseño*
