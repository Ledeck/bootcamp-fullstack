# 📄 CHEAT SHEET — SEMANA 16
## Autenticación y Autorización · Clerk · Next.js

> Guion de la clase de activación. Se entrega POR PARTES, día a día.
> No lo leas completo de antemano.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado y verificado: agosto 2026
Referencia: Clerk Core 3 (marzo 2026) · Next.js 16
REGENERAR antes de empezar la semana.
```

```bash
npm install @clerk/nextjs
```

Variables en `.env.local` (se copian del panel de Clerk):

```
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_...
CLERK_SECRET_KEY=sk_test_...
```

⚠ `CLERK_SECRET_KEY` **nunca** lleva el prefijo `NEXT_PUBLIC_`. Ese prefijo
expone la variable al navegador. La clave secreta es de servidor.

### Cambios de Clerk Core 3 — marzo 2026

Casi todo el material anterior a esa fecha está desactualizado:

| Antes | Ahora |
|---|---|
| `middleware.ts` | **`proxy.ts`** (Next.js 16 renombró el concepto) |
| `<SignedIn>` / `<SignedOut>` | **`<Show when="signed-in">`** |
| `auth().protect()` | **`auth.protect()`** — sin paréntesis en `auth` |
| `auth().userId` para saber si hay sesión | **`auth()` devuelve `isAuthenticated`** |

**Qué verificar al llegar a esta semana:** la versión de `@clerk/nextjs`, si
`proxy.ts` sigue siendo el nombre del archivo, y si `<Show>` sigue vigente.

---

## 1. EL PROBLEMA — POR QUÉ AUTENTICACIÓN

Tu aplicación de la Semana 14 tiene un fallo que no se ve: **no tiene
usuarios**.

```
Cualquiera que abra la URL ve todas las reservas
Cualquiera puede crear, editar o cancelar cualquier reserva
Ninguna reserva pertenece a nadie
El "rol admin" del contexto de la Semana 11 es un selector de mentira
```

Eso no es un detalle de seguridad: es que la aplicación no puede existir
fuera de tu máquina.

**Dos conceptos que se confunden y son distintos:**

```
AUTENTICACIÓN  →  ¿quién eres?      (login, sesión, identidad)
AUTORIZACIÓN   →  ¿qué puedes hacer? (permisos, roles, propiedad del dato)
```

Clerk resuelve la primera casi entera. La segunda la escribes tú, y es
donde están los errores caros.

---

## 2. LAS TRES PIEZAS DEL SETUP

### `proxy.ts` — en la raíz del proyecto

```typescript
import { clerkMiddleware } from "@clerk/nextjs/server";

export default clerkMiddleware();

export const config = {
  matcher: [
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    "/(api|trpc)(.*)",
    "/__clerk/(.*)"
  ]
};
```

**Qué hace:** adjunta la sesión a cada petición que coincida con el matcher.
Sin esto, `auth()` no tiene de dónde leer y lanza error.

⚠ **En Next.js 15 o anterior el archivo se llama `middleware.ts`.** La
función `clerkMiddleware()` es la misma; solo cambia el nombre del archivo.

### `<ClerkProvider>` — en el layout raíz

```tsx
import { ClerkProvider } from "@clerk/nextjs";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="es">
        <body>{children}</body>
      </html>
    </ClerkProvider>
  );
}
```

Es un contexto de React — exactamente lo de la Semana 11. Provee la sesión
a los hooks y componentes de Clerk.

⚠ **El error más común de toda la semana:** *"auth() was called but Clerk
can't detect usage of clerkMiddleware()"*. Casi siempre significa una de dos
cosas: falta el `<ClerkProvider>`, o el matcher del `proxy.ts` no cubre esa
ruta.

### Componentes de interfaz

```tsx
import { SignInButton, SignUpButton, UserButton, Show } from "@clerk/nextjs";

<Show when="signed-out">
  <SignInButton />
  <SignUpButton />
</Show>

<Show when="signed-in">
  <UserButton />
</Show>
```

Clerk trae la pantalla de login, el registro, la recuperación de contraseña
y el menú de usuario ya hechos. No se escriben.

---

## 3. LEER EL USUARIO

### En el servidor

```typescript
import { auth, currentUser } from "@clerk/nextjs/server";

// auth() — rápido, solo identificadores
const { userId, isAuthenticated } = await auth();

// currentUser() — el objeto completo, hace una petición a la API de Clerk
const user = await currentUser();
// user.firstName, user.emailAddresses[0].emailAddress, ...
```

**Cuál usar:** `auth()` cuando solo necesitas saber quién es o si hay sesión.
`currentUser()` cuando necesitas nombre, correo o imagen.

`currentUser()` cuesta una petición de red. No lo llames si te basta el
`userId`.

⚠ **Trampa de Next.js 16:** `auth()` y `currentUser()` leen `headers()` por
dentro, así que llamarlas dentro de una función con `'use cache'` lanza
error. Solución: llamar `auth()` **fuera** y pasar el resultado como
argumento.

### En el cliente

```tsx
"use client";
import { useUser, useAuth } from "@clerk/nextjs";

const { user, isLoaded } = useUser();
const { userId, signOut } = useAuth();

if (!isLoaded) return <p>Cargando...</p>;
```

⚠ **`isLoaded` no es opcional.** En el primer render `user` es `null` aunque
haya sesión, porque Clerk todavía no resolvió. Sin comprobar `isLoaded`
muestras "no hay sesión" durante un instante en cada carga.

---

## 4. PROTEGER RUTAS

### Con el proxy — la primera capa

```typescript
import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";

const isRutaProtegida = createRouteMatcher([
  "/dashboard/:path*",
  "/reservas/:path*"
]);

export default clerkMiddleware(async (auth, req) => {
  if (isRutaProtegida(req)) {
    await auth.protect();
  }
});
```

⚠ Clerk recomienda `/dashboard/:path*` en vez de `/dashboard(.*)`. Las dos
funcionan, pero la primera es la sintaxis nativa de Next.js.

### En la página — la segunda capa

```typescript
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export default async function PaginaReservas() {
  const { userId, isAuthenticated } = await auth();

  if (!isAuthenticated) {
    redirect("/sign-in");
  }

  const reservas = await prisma.reserva.findMany({
    where: { usuarioId: userId }
  });
}
```

### En un Route Handler o Server Action — la capa que importa

```typescript
"use server";
import { auth } from "@clerk/nextjs/server";

export async function cancelarReserva(reservaId: string) {
  const { userId, isAuthenticated } = await auth();

  if (!isAuthenticated) {
    return { error: "No autorizado" };
  }

  // ...
}
```

---

## 5. POR QUÉ TRES CAPAS Y NO UNA

Esta sección es la más importante de la semana.

**CVE-2025-29927** fue una vulnerabilidad de Next.js que permitía **saltarse
el middleware entero** con una cabecera HTTP. Aplicaciones que ponían toda su
autorización ahí quedaron abiertas.

El detalle que hay que entender:

> Que una aplicación estuviera expuesta o no dependió de **dónde estaba
> desplegada**, no de su código. Vercel resultó "incidentalmente invulnerable"
> porque su enrutamiento corre separado de la aplicación. Los despliegues
> autoalojados sí fueron afectados.

Y el patrón se repitió: **CVE-2026-45109**, en mayo de 2026, tras un arreglo
incompleto de un bypass de prefetch.

**La lección, que vale más allá de este CVE concreto:**

```
El proxy es conveniencia, no seguridad.
Sirve para redirigir al login sin que la página se pinte.

La autorización REAL va donde están los datos:
  · en la consulta a Prisma (where: { usuarioId })
  · en la Server Action antes de escribir
  · en el Route Handler antes de responder

Si tu única defensa es el proxy, tu seguridad depende de tu proveedor
de hosting, no de tu código.
```

**Idea mental:** el proxy es el portero que te dice que no puedes entrar. La
comprobación en la Server Action es la caja fuerte. Un portero se puede
esquivar; una caja fuerte hay que abrirla.

---

## 6. AUTORIZACIÓN — DATOS QUE PERTENECEN A ALGUIEN

Autenticar no basta. Un usuario con sesión sigue pudiendo pedir la reserva de
otro si tu consulta no lo impide.

### En el esquema

```prisma
model Reserva {
  id         String   @id @default(cuid())
  cliente    String
  personas   Int

  usuarioId  String              // el userId de Clerk
  @@index([usuarioId])
}
```

⚠ El `userId` de Clerk es un string tipo `user_2abc...`. No es una relación
de Prisma — Clerk vive fuera de tu base de datos. Guardas el identificador,
no una clave foránea.

### En cada consulta

```typescript
// ❌ Cualquiera con sesión ve todo
const reservas = await prisma.reserva.findMany();

// ✅ Solo lo suyo
const reservas = await prisma.reserva.findMany({
  where: { usuarioId: userId }
});
```

### El caso que más se olvida — leer uno por id

```typescript
// ❌ Con el id de otro, se lo entregas
const reserva = await prisma.reserva.findUnique({
  where: { id: reservaId }
});

// ✅ El id tiene que ser suyo
const reserva = await prisma.reserva.findFirst({
  where: { id: reservaId, usuarioId: userId }
});
```

Se llama **IDOR** (Insecure Direct Object Reference), y es de las
vulnerabilidades más frecuentes en aplicaciones reales. No requiere ningún
truco: basta cambiar un número en la URL.

**La regla:** toda consulta que devuelva datos de un usuario lleva su
`userId` en el `where`. Sin excepción.

---

## 7. ROLES Y METADATA

En la Semana 11 construiste un `ContextoSesion` con un selector para cambiar
entre "admin" y "guia". Era una simulación. Ahora se hace de verdad.

```typescript
const { sessionClaims } = await auth();
const rol = sessionClaims?.metadata?.rol;

if (rol !== "admin") {
  return { error: "Solo administradores" };
}
```

El rol se guarda en la **metadata pública** del usuario, desde el panel de
Clerk o por API. Va dentro del token de sesión, así que leerlo no cuesta una
petición extra.

⚠ **Trampa:** la metadata pública es visible desde el cliente. Nunca guardes
ahí nada sensible. Y aunque el cliente pueda *leer* el rol, solo el servidor
debe *confiar* en él.

⚠ **Segunda trampa:** cambiar la metadata no actualiza las sesiones ya
activas hasta que el token se refresca. Un usuario puede conservar su rol
anterior durante minutos.

---

## 8. SINTAXIS NUEVA DE ESTA SEMANA

### `await auth()` · peso MEDIO

Función asíncrona que devuelve el estado de sesión de la petición actual.

```typescript
const { userId, isAuthenticated, sessionClaims } = await auth();
```

> ⚠ **Trampa 1:** requiere `clerkMiddleware()` corriendo. Sin eso, lanza el
> error de "can't detect usage of clerkMiddleware".
>
> ⚠ **Trampa 2:** en Next.js 16 no se puede llamar dentro de `'use cache'`.

### `auth.protect()` · peso LIGERO

Corta la petición si no hay sesión válida.

```typescript
await auth.protect();
```

> ⚠ **Trampa:** `auth.protect()` sin paréntesis en `auth`. En Core 2 era
> `auth().protect()`. Los tutoriales anteriores a marzo de 2026 usan la forma
> antigua.

### `createRouteMatcher()` · peso LIGERO

Construye una función que dice si una petición coincide con unas rutas.

```typescript
const isRutaProtegida = createRouteMatcher(["/dashboard/:path*"]);
```

> ⚠ **Trampa:** devuelve una **función**, no un booleano. Hay que llamarla
> con la petición: `isRutaProtegida(req)`.

---

## 8b. GRUPOS DE RUTAS — organizar sin cambiar la URL

Una carpeta entre paréntesis **no aparece en la URL**. Sirve para agrupar
rutas que comparten layout o nivel de protección.

```
app/
├── (publico)/
│   ├── layout.tsx          ← cabecera sin menú de usuario
│   ├── page.tsx            →  /
│   └── expediciones/
│       └── page.tsx        →  /expediciones
└── (privado)/
    ├── layout.tsx          ← cabecera con UserButton y navegación
    ├── reservas/
    │   └── page.tsx        →  /reservas
    └── dashboard/
        └── page.tsx        →  /dashboard
```

Fíjate en las URLs: `(publico)` y `(privado)` **no salen**. `/expediciones`,
no `/publico/expediciones`.

**Para qué sirve aquí:** el layout de `(privado)` puede comprobar la sesión
una sola vez y proteger todo lo que cuelga de él:

```tsx
// app/(privado)/layout.tsx
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";

export default async function LayoutPrivado({
  children
}: {
  children: React.ReactNode;
}) {
  const { isAuthenticated } = await auth();

  if (!isAuthenticated) {
    redirect("/sign-in");
  }

  return (
    <div>
      <CabeceraPrivada />
      {children}
    </div>
  );
}
```

> ⚠ **Trampa 1:** dos grupos no pueden producir la misma ruta. Si tienes
> `(publico)/page.tsx` y `(privado)/page.tsx`, los dos resuelven a `/` y
> Next.js falla al construir.
>
> ⚠ **Trampa 2:** el layout del grupo protege lo que se renderiza, no los
> datos. Sigue haciendo falta la comprobación en cada Server Action. Es la
> capa 2 de las tres, no un sustituto de la 3.

---

## 9. TABLA DE DECISIÓN

| Necesitas | Usa |
|---|---|
| Saber si hay sesión, en servidor | `auth()` → `isAuthenticated` |
| El id del usuario, en servidor | `auth()` → `userId` |
| Nombre, correo, foto | `currentUser()` |
| Datos del usuario en un Client Component | `useUser()` + `isLoaded` |
| Cerrar sesión desde un botón | `useAuth()` → `signOut` |
| Redirigir al login antes de pintar | `proxy.ts` + `createRouteMatcher` |
| Impedir que se ejecute una escritura | `auth()` dentro de la Server Action |
| Que un usuario solo vea lo suyo | `where: { usuarioId: userId }` |
| Comprobar un rol | `sessionClaims?.metadata?.rol` |

---

## 10. FUERA DE ALCANCE ESTA SEMANA

```
Organizaciones y multi-tenancy    para B2B; el proyecto no lo necesita
Webhooks de Clerk                 sincronizar usuarios con tu base
MFA y passkeys                    se activan en el panel, no en código
Autenticación con OAuth propio    Clerk lo cubre desde su panel
JWT y sesiones a mano             el punto de usar Clerk es no hacerlo
Machine tokens                    para APIs entre servicios
```

---

*Cheat Sheet Semana 16 — Autenticación con Clerk*
*Prerrequisitos: Semana 11 (contexto) · Semana 12 (Next.js, Server Actions) · Semana 14 (Prisma)*
