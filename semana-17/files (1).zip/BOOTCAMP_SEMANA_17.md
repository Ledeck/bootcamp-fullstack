# 📘 BOOTCAMP SEMANA 17
## Validación · Zod · Formularios · React 19

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-08-06
Semana en curso de Óscar al generar: 05 (proyecto semanal)
Distancia estimada hasta el uso: ~11 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes consultadas 2026-08-06:
   · zod.dev/v4 y zod.dev/v4/changelog (notas de versión oficiales)
   · Guía de migración Zod v4 (gist, abril 2026)
   · buildmvpfast.com — migración Zod v4 (julio 2026)
   · baeseokjae.github.io — Zod v4 guide (junio 2026)
   · dev.to/pockit_tools — migración a Zod 4 (marzo 2026)
   · mattburgess.medium.com — React Hook Form vs React 19
Referencia: Zod 4 · React 19 · Next.js 16
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

---

> **Flujo de la semana:** el Cheat Sheet se entrega por partes, día a día,
> como guion de la clase de activación.

---

## ⚠️ NOTA DE ALCANCE

Esta semana cierra el hueco más antiguo del sistema, declarado por el propio
material: **la Semana 14 guarda datos y nada comprueba su forma antes de
entrar**. La Semana 16 lo agravó al añadir usuarios reales que envían datos.

Y hay una convergencia que hace esta semana distinta: **ya escribiste esto a
mano**. En PS-2 construiste saneamiento, validación con motivos y cuarentena,
todo manual. Zod hace lo mismo de forma declarativa.

Habiendo sufrido la versión artesanal, la librería no es magia. Es
*"ah, esto es lo que escribí a mano"*.

**Prerrequisito real:** Semanas 14 y 16. Sin datos que persistir y sin
usuarios que envíen, no hay nada que validar.

---

## 🗓 DÍA 1 — POR QUÉ TYPESCRIPT NO BASTA

### 🎯 Objetivo
Ver fallar tu propio sistema y entender por qué el tipo no lo impidió.

---

### 📖 El problema real

Tu Server Action de la Semana 16:

```typescript
type DatosReserva = { cliente: string; personas: number };

export async function crearReserva(datos: DatosReserva) {
  const { userId } = await auth();
  await prisma.reserva.create({ data: { ...datos, usuarioId: userId } });
}
```

Está tipada. Comprueba sesión. Filtra por usuario.

**Y acepta esto:**

```javascript
crearReserva({ cliente: "", personas: -47 });
```

Se guarda. Cliente vacío, personas negativas, en tu base de datos.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

Dos respuestas naturales, y las dos fallan.

**"El tipo dice `number`, no acepta `-47`."** El tipo acepta cualquier
`number`, y `-47` lo es. TypeScript no sabe de reglas de negocio.

**"Pero el formulario no deja enviar eso."** El formulario no es la única
puerta. Cualquiera puede invocar la Server Action desde la consola — lo
comprobaste en el Día 4 de la Semana 16.

---

### 📖 Por qué pasa

Es lo del Día 7 de la Semana 9, ahora con consecuencia:

> **Los tipos se borran al compilar. En ejecución no queda nada.**

TypeScript protege mientras escribes. Cuando el programa corre, las
anotaciones ya no existen.

```
TypeScript  →  comprobación en tiempo de ESCRITURA
Zod         →  comprobación en tiempo de EJECUCIÓN
```

Y no compiten: se complementan. Necesitas las dos.

---

### 📖 Lo que ya sabes hacer

En PS-2 escribiste esto:

```javascript
function validarReserva(reserva, catalogo, refsVistas) {
  const motivos = [];
  if (!reserva.cliente) motivos.push("cliente vacío");
  if (reserva.personas <= 0) motivos.push("personas inválido");
  return motivos;
}
```

Funciona. Y tiene tres problemas que no se ven con catorce registros:

```
1. El tipo y la validación viven separados. Si agregas un campo al tipo
   y olvidas la regla, nada avisa.

2. Cada validación se escribe a mano, y el mismo campo se valida distinto
   en sitios distintos.

3. Los mensajes de error se construyen a mano en cada regla.
```

Zod resuelve los tres. Y el primero de una forma que no habías visto: **el
tipo sale del esquema**, así que no pueden desincronizarse.

---

### 📖 El primer esquema

```typescript
import { z } from "zod";

const esquemaReserva = z.object({
  cliente: z.string().min(3, { error: "Mínimo 3 caracteres" }),
  personas: z.number().int().positive({ error: "Debe ser mayor a 0" })
});

const resultado = esquemaReserva.safeParse({ cliente: "", personas: -47 });

console.log(resultado.success);        // false
console.log(resultado.error.issues);   // los dos problemas, con su campo
```

Dos reglas, dos errores, con el campo al que pertenecen.

---

### 📖 Mini-ejercicio de comprensión

```typescript
type Reserva = { personas: number };

function crear(datos: Reserva) {
  console.log(datos.personas * 2);
}

crear({ personas: "5" as any });
```

Compila. ¿Qué imprime, y por qué TypeScript no lo impidió?

---

### 🛠 EJERCICIOS DÍA 1

**Ejercicio 1** — provoca el fallo

Desde la consola del navegador, invoca tu Server Action de crear reserva con
`{ cliente: "", personas: -47 }`.

Comprueba en Prisma Studio que se guardó. Documenta en `NOTAS.md`.

**Ejercicio 2** — primer esquema

Instala Zod y escribe `esquemaReserva` con cuatro reglas. Pruébalo con
`safeParse` sobre tres entradas: una válida, una con un error, una con varios.

**Ejercicio 3** — juzga este código

```typescript
export async function actualizarPerfil(datos: { correo: string; edad: number }) {
  await prisma.usuario.update({ where: { id }, data: datos });
}
```

Enumera todo lo que puede entrar por esa puerta y no debería. Al menos cinco
casos.

---

**Cuando termines avísame — valido el Día 1.** ✅

---

## 🗓 DÍA 2 — ESQUEMAS Y LA INFERENCIA DE TIPOS

### 🎯 Objetivo
Construir esquemas expresivos y descubrir la característica que hace a Zod
distinto de cualquier validador.

---

### 📖 La característica central

```typescript
const esquemaReserva = z.object({
  cliente: z.string().min(3),
  personas: z.number().int().positive(),
  expedicionId: z.string()
});

type Reserva = z.infer<typeof esquemaReserva>;
// { cliente: string; personas: number; expedicionId: string }
```

**No escribiste el tipo. Salió del esquema.**

Y eso resuelve el problema número uno de PS-2: allí el tipo y la validación
eran dos cosas independientes que había que mantener sincronizadas a mano.

Aquí son la misma cosa. **No pueden desincronizarse.**

> ⚠ **Trampa:** es `typeof esquemaReserva`, no `typeof Reserva`. Pides el
> tipo de la variable del esquema.

---

### 📖 El catálogo de reglas

```typescript
z.string().min(3).max(100).trim()
z.number().int().positive().max(50)
z.email()
z.url()
z.enum(["confirmada", "pendiente", "cancelada"])
z.array(z.string()).nonempty()
z.string().optional()
z.string().nullable()
z.string().default("sin dato")
```

⚠ **`optional()` y `nullable()` no son lo mismo.** El primero permite que
falte; el segundo permite que sea `null`. Es la distinción que trabajaste en
el Día 4 de la Semana 5 con los default parameters.

---

### 📖 Reglas entre campos — `refine`

Un tipo no puede expresar "personas no debe superar el cupo". Zod sí:

```typescript
const esquemaReserva = z.object({
  personas: z.number().int().positive(),
  cupoMaximo: z.number()
}).refine((d) => d.personas <= d.cupoMaximo, {
  error: "Excede el cupo disponible",
  path: ["personas"]
});
```

El `path` decide en qué campo aparece el error en el formulario.

> ⚠ **Trampa:** `refine` solo corre si las validaciones previas pasaron. Si
> `personas` no es un número, el refine ni se llama.

---

### 📖 Transformar mientras validas

```typescript
const esquemaMonto = z.string().transform((s) => Number(s.replace(/[$.]/g, "")));

esquemaMonto.parse("$45.000");   // 45000
```

Ese es `normalizarMonto` de PS-2, en una línea.

> ⚠ **Trampa:** `.transform()` cambia el tipo de salida. `z.infer` te da el
> tipo **después**. Si necesitas los dos: `z.input` y `z.output`.

---

### 📖 Componer esquemas

```typescript
const esquemaBase = z.object({
  cliente: z.string().min(3),
  personas: z.number().int().positive()
});

const esquemaCrear = esquemaBase;
const esquemaActualizar = esquemaBase.partial();
const esquemaConId = esquemaBase.extend({ id: z.string() });
```

`.partial()` es el `Partial<T>` de la Semana 9, del lado de la validación.

⚠ En Zod 4, `.merge()` está deprecado. Usa `.extend()`.

---

### 📖 Mini-ejercicio de comprensión

```typescript
const esquema = z.object({
  edad: z.string().transform((s) => Number(s))
});

type T = z.infer<typeof esquema>;
```

¿`T["edad"]` es `string` o `number`? ¿Y qué tipo espera `parse()` de entrada?

---

### 🛠 EJERCICIOS DÍA 2

**Ejercicio 1** — `src/esquemas/reserva.ts`

Esquema completo de reserva con al menos seis reglas y mensajes en español.
Exporta también el tipo con `z.infer`.

**Ejercicio 2** — reemplazar tipos escritos a mano

Busca en tu proyecto los tipos que escribiste a mano para datos que entran
del exterior. Sustitúyelos por esquemas + `z.infer`.

Anota cuántos eliminaste.

**Ejercicio 3** — la regla del cupo

Implementa con `refine` la validación de que las personas no superen el cupo
disponible de la expedición.

**Ejercicio 4** — porta PS-2

Toma tres funciones de saneamiento de PS-2 —`normalizarNombre`,
`normalizarMonto`, `normalizarEstado`— y exprésalas como esquemas Zod con
`.transform()`.

Compara las dos versiones y anota en un comentario qué ganaste y qué perdiste.
No todo es ganancia: sé honesto en las dos direcciones.

---

**Cuando termines avísame — valido el Día 2.** ✅

---

## 🗓 DÍA 3 — VALIDAR EN EL SERVIDOR

### 🎯 Objetivo
Poner la validación donde protege de verdad.

---

### 📖 El problema real

Tienes esquemas. ¿Dónde los usas?

La respuesta parece obvia —en el formulario— y es la equivocada.

---

### 📖 La regla, heredada de la Semana 16

> Validar en el formulario mejora la experiencia.
> **Validar en el servidor es lo que protege.**

Es la misma estructura del Día 4 de la Semana 16: la interfaz decide qué se
ve, el servidor decide qué se puede hacer. Aquí: el formulario decide qué se
puede escribir, el servidor decide qué se puede guardar.

---

### 📖 La Server Action validada

```typescript
"use server";
import { z } from "zod";
import { auth } from "@clerk/nextjs/server";
import { revalidatePath } from "next/cache";

const esquemaReserva = z.object({
  cliente: z.string().min(3),
  personas: z.number().int().positive(),
  expedicionId: z.string().startsWith("EXP")
});

export async function crearReserva(entrada: unknown) {
  const { userId, isAuthenticated } = await auth();
  if (!isAuthenticated) {
    return { error: "No autorizado" };
  }

  const resultado = esquemaReserva.safeParse(entrada);
  if (!resultado.success) {
    return { errores: z.treeifyError(resultado.error) };
  }

  await prisma.reserva.create({
    data: { ...resultado.data, usuarioId: userId }
  });

  revalidatePath("/reservas");
  return { exito: true };
}
```

**El detalle que importa: `entrada: unknown`.**

Tiparlo como `DatosReserva` sería mentir — no tienes forma de saber qué te
mandaron. `unknown` es honesto y te obliga a validar antes de tocar nada.

Es la misma elección de PS-2 y PS-3. Tercera vez que aparece: no es
casualidad, es el patrón de las fronteras.

---

### 📖 El orden importa

```
1. ¿Hay sesión?          → auth()
2. ¿Los datos valen?     → safeParse()
3. ¿Tiene permiso?       → comprobar propiedad
4. ¿Cumple el negocio?   → cupo, fechas, estado
5. Escribir
```

Validar la forma **antes** de consultar la base evita consultas inútiles con
datos basura. Y comprobar sesión antes que nada evita trabajar para alguien
que no debería estar ahí.

---

### 📖 Formatear errores

```typescript
z.treeifyError(error)    // estructura anidada → para formularios
z.prettifyError(error)   // texto legible → para logs
resultado.error.issues   // array crudo → para lógica propia
```

⚠ `error.errors` **se eliminó** en Zod 4. `error.format()` está deprecado.
Los tutoriales anteriores a 2025 usan los dos.

---

### 📖 Un esquema, dos usos

```
src/esquemas/reserva.ts   ← el esquema vive aquí, solo
       ↓                            ↓
Server Action                  Formulario
(protege)                      (mejora la experiencia)
```

Que el esquema no viva dentro del formulario es lo que permite reutilizarlo.
Es la separación entre lógica y presentación, otra vez.

---

### 📖 Mini-ejercicio de comprensión

```typescript
export async function crearReserva(datos: DatosReserva) {
  const resultado = esquemaReserva.safeParse(datos);
  // ...
}
```

Valida correctamente. ¿Por qué el tipo del parámetro sigue siendo un problema?

---

### 🛠 EJERCICIOS DÍA 3

**Ejercicio 1** — todas las acciones

Agrega validación Zod a **todas** tus Server Actions. Lista cuántas eran.

**Ejercicio 2** — el orden correcto

Revisa cada una y verifica que el orden sea sesión → forma → permiso →
negocio → escritura. Corrige las que no lo cumplan.

**Ejercicio 3** — el cliente hostil, otra vez

Repite el ataque del Día 1: invoca desde la consola con datos inválidos.
Ahora debe rechazarlos con mensajes claros.

**Ejercicio 4** — juzga estos mensajes

```typescript
return { errores: z.treeifyError(resultado.error) };
```

Esto devuelve al cliente la estructura completa de tu esquema, incluidos los
nombres de campos internos.

¿Es un problema? ¿En qué casos sí y en cuáles no?

---

**Cuando termines avísame — valido el Día 3.** ✅

---

## 🗓 DÍA 4 — FORMULARIOS: DOS CAMINOS

### 🎯 Objetivo
Elegir con criterio entre React 19 nativo y React Hook Form.

---

### 📖 El problema real

El servidor ya rechaza datos malos. Pero el usuario se entera después de
enviar, y con un mensaje genérico.

---

### 📖 Lo que cambió en React 19

Durante años, React Hook Form era la respuesta obvia. **React 19 cambió eso.**

Ahora hay manejo de formularios nativo: `useActionState`, acciones de
formulario, estado de envío incluido. Para muchos casos, la librería sobra.

Este día trata de saber cuándo cada uno.

---

### 📖 Camino A — React 19 nativo

```tsx
"use client";
import { useActionState } from "react";

export function FormularioReserva() {
  const [estado, accion, pendiente] = useActionState(crearReserva, null);

  return (
    <form action={accion}>
      <input name="cliente" />
      {estado?.errores?.properties?.cliente && (
        <span>{estado.errores.properties.cliente.errors[0]}</span>
      )}

      <input name="personas" type="number" />

      <button disabled={pendiente}>
        {pendiente ? "Guardando..." : "Reservar"}
      </button>
    </form>
  );
}
```

La Server Action cambia de firma:

```typescript
export async function crearReserva(estadoPrevio: unknown, datos: FormData) {
  const entrada = {
    cliente: datos.get("cliente"),
    personas: Number(datos.get("personas"))
  };

  const resultado = esquemaReserva.safeParse(entrada);
  // ...
}
```

> ⚠ **Trampa 1:** la acción recibe **dos** parámetros. El primero es el estado
> anterior. Olvidarlo es el error más común.
>
> ⚠ **Trampa 2:** `FormData.get()` devuelve string o `File`. **Nunca number.**
> Hay que convertir, y es la frontera del usuario de PS-3 otra vez.

```
✅ Sin dependencias
✅ Funciona sin JavaScript en el cliente
✅ Estado de carga incluido
❌ Validación solo al enviar
```

---

### 📖 Camino B — React Hook Form

```tsx
"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { esquemaReserva, type Reserva } from "@/esquemas/reserva";

export function FormularioReserva() {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting }
  } = useForm<Reserva>({ resolver: zodResolver(esquemaReserva) });

  async function enviar(datos: Reserva) {
    await crearReserva(datos);
  }

  return (
    <form onSubmit={handleSubmit(enviar)}>
      <input {...register("cliente")} />
      {errors.cliente && <span>{errors.cliente.message}</span>}

      <input {...register("personas", { valueAsNumber: true })} type="number" />
      {errors.personas && <span>{errors.personas.message}</span>}

      <button disabled={isSubmitting}>Reservar</button>
    </form>
  );
}
```

**El mismo esquema, ahora del lado del cliente.** `zodResolver` conecta los
dos mundos.

> ⚠ **Trampa:** sin `valueAsNumber: true`, el campo llega como string y Zod
> lo rechaza. Es la frontera del usuario, otra vez.

```
✅ Validación mientras escribe
✅ Muy pocos re-renders
✅ Bueno para formularios largos
❌ Una dependencia más
❌ No funciona sin JavaScript
```

---

### 📖 El criterio

| Situación | Camino |
|---|---|
| Pocos campos, validación al enviar | **A** |
| Debe funcionar sin JavaScript | **A** |
| Validación en cada tecla | **B** |
| Muchos campos o dependientes entre sí | **B** |
| Varios pasos | **B** |

**Y en los dos, el servidor valida igual.** El formulario nunca sustituye a
la Server Action.

---

### 📖 Mini-ejercicio de comprensión

Un compañero dice:

> "Con React Hook Form y Zod en el cliente ya no hace falta validar en el
> servidor. El formulario no deja enviar datos malos."

Explica por qué está equivocado, con un ejemplo concreto de cómo saltárselo.

---

### 🛠 EJERCICIOS DÍA 4

**Ejercicio 1** — camino A

Reescribe el formulario de reserva con `useActionState`. Sin librerías.

**Ejercicio 2** — camino B

El mismo formulario con React Hook Form y `zodResolver`. En una rama Git
aparte.

**Ejercicio 3** — compara

Con los dos funcionando, responde en `NOTAS.md`:

```
· ¿Cuántas líneas tiene cada uno?
· ¿Cuál se siente mejor al usarlo?
· Desactiva JavaScript en el navegador. ¿Cuál sigue funcionando?
· ¿Cuál elegirías para este formulario? ¿Y para uno de 20 campos?
```

**Ejercicio 4** — decide y justifica

Elige uno para tu proyecto y borra el otro. Justifica en el README.

No hay respuesta correcta. Se evalúa el criterio.

---

**Cuando termines avísame — valido el Día 4.** ✅

---

## 🗓 DÍA 5 — ERRORES QUE SIRVEN

### 🎯 Objetivo
Que un error diga qué pasó y qué hacer.

---

### 📖 El problema real

```
"Error de validación"
```

No dice qué campo, ni qué regla, ni cómo arreglarlo. El usuario prueba a
ciegas.

---

### 📖 Mensajes por regla

```typescript
const esquemaReserva = z.object({
  cliente: z
    .string({ error: "El nombre es obligatorio" })
    .min(3, { error: "Al menos 3 caracteres" })
    .max(100, { error: "Máximo 100 caracteres" }),

  personas: z
    .number({ error: "Indica cuántas personas" })
    .int({ error: "Debe ser un número entero" })
    .positive({ error: "Al menos una persona" })
});
```

⚠ En Zod 4 el parámetro es `error`, no `message`. Y `required_error` e
`invalid_type_error` se unificaron en `error`.

---

### 📖 Qué hace un mensaje útil

```
❌ "Inválido"                     no dice nada
❌ "String must contain at least 3 character(s)"   en inglés y técnico
❌ "Error en el campo cliente"    dice dónde, no qué

✅ "Al menos 3 caracteres"        qué falta
✅ "No hay cupos suficientes: quedan 4"   qué pasa y el dato
```

**La regla:** un mensaje debe permitir corregir sin adivinar.

---

### 📖 Errores de negocio vs errores de forma

```typescript
// Forma → el esquema
personas: z.number().int().positive()

// Negocio → necesita consultar la base
if (ocupados + personas > expedicion.cupoMaximo) {
  return { error: `Solo quedan ${expedicion.cupoMaximo - ocupados} cupos` };
}
```

Zod valida la **forma**. El negocio necesita datos que el esquema no tiene.

Los dos deben llegar al usuario igual de claros, aunque vengan de sitios
distintos.

---

### 📖 Estados del formulario

```
inactivo   → nada ha pasado
enviando   → deshabilitar el botón, evitar doble envío
error      → mostrar qué falló, conservar lo escrito
exito      → confirmar y limpiar
```

⚠ **Conservar lo escrito cuando hay error no es opcional.** Un formulario que
se vacía al fallar hace que el usuario lo abandone.

Es una unión discriminada — el patrón de la Semana 11.

---

### 📖 Mini-ejercicio de comprensión

Tu formulario muestra "No hay cupos suficientes" y limpia todos los campos.

Enumera los tres problemas de experiencia que eso causa.

---

### 🛠 EJERCICIOS DÍA 5

**Ejercicio 1** — todos los mensajes en español

Ninguno debe salir en inglés ni con jerga técnica.

**Ejercicio 2** — errores de negocio

Cupo insuficiente, expedición inexistente, fecha pasada. Con el dato concreto
en el mensaje, no genérico.

**Ejercicio 3** — los cuatro estados

Implementa el estado del formulario como unión discriminada. Al fallar,
conserva lo escrito.

**Ejercicio 4** — juzga esta experiencia

```tsx
{errores && <div>Hubo un error. Revisa los datos.</div>}
```

Enumera todo lo que está mal. Al menos cuatro cosas. Reescríbelo.

---

**Cuando termines avísame — valido el Día 5.** ✅

---

## 🗓 DÍA 6 — PROYECTO DE LA SEMANA

### 🏆 Nexus Blindado

> El sistema ya tiene usuarios y datos que les pertenecen. Ahora ninguna
> puerta acepta basura, y cuando rechaza algo, dice exactamente por qué.

---

### 📋 Lo que debe hacer

**1. Esquemas centralizados** en `src/esquemas/`, uno por entidad. Los tipos
salen de ellos con `z.infer` — cero tipos escritos a mano para datos externos.

**2. Toda Server Action validada**, con `entrada: unknown` y el orden: sesión
→ forma → permiso → negocio → escritura.

**3. Formularios** de crear reserva, editar reserva y asignar guía, con el
camino que elegiste el Día 4.

**4. Errores útiles** — en español, por campo, con el dato concreto cuando lo
haya. Conservando lo escrito.

**5. Reglas de negocio con `refine`** donde dependan de varios campos, y en la
acción donde necesiten la base de datos.

---

### 📋 Requisitos técnicos

```
✅ Un esquema por entidad, en su propio archivo
✅ Todos los tipos de datos externos salen de z.infer
✅ Toda Server Action recibe unknown y valida
✅ safeParse, no parse, en las acciones
✅ Mensajes en español, por campo
✅ El formulario conserva lo escrito al fallar
✅ El mismo esquema se usa en cliente y servidor
✅ Sintaxis de Zod 4 (z.email, error, .issues)
❌ Sin tipos escritos a mano duplicando un esquema
❌ Sin validación que solo exista en el cliente
❌ Sin mensajes en inglés
❌ Sin z.string().email() ni error.errors — son de Zod 3
```

---

### 📋 Estructura sugerida

```
src/
├── esquemas/
│   ├── reserva.ts
│   ├── expedicion.ts
│   └── guia.ts
├── acciones/
├── componentes/formularios/
└── app/
```

---

### 💡 Las dos únicas pistas

**Pista 1** — Si el mismo campo se valida igual en varios esquemas, extráelo:

```typescript
const nombrePersona = z.string().min(3).max(100).trim();
```

Un esquema es un valor. Se puede guardar en una variable y reutilizar.

**Pista 2** — Para el cupo necesitas consultar la base, y `refine` no puede
ser asíncrono de forma sencilla. Piensa qué va en el esquema y qué va en la
acción. La separación forma/negocio del Día 5 es la respuesta.

---

### ✅ Criterios de aprobación

```
□ Invocar cualquier Server Action con basura desde la consola: rechazada
□ Los mensajes dicen qué campo y qué regla
□ Al fallar, el formulario conserva lo escrito
□ Cero tipos escritos a mano para datos que entran del exterior
□ El esquema de reserva se usa en el formulario y en la acción
□ npx tsc --noEmit sin errores
□ Subido con commit descriptivo
```

**Verificación adversarial:** quince minutos intentando meter datos inválidos
por consola. Números negativos, strings vacíos, campos de más, tipos
cambiados, objetos anidados donde va un string.

Documenta cada intento en `NOTAS.md`.

---

**Cuando termines el proyecto, avísame.** 🎯

---

## 🔜 LO QUE VIENE

```
Despliegue en Vercel
   La Enmienda 19 fijó los proyectos de portafolio, y un portafolio sin
   URL pública no lo es. Candidato natural para la Semana 18

Zustand
   Único elemento del stack sin semana. Espera a que el dolor del
   contexto duela de verdad

Testing
   La Enmienda 14 lo respalda. Necesita código estable que testear
```

**PS-4 se dispara tras la Semana 16**, no tras esta. Ver el roadmap.

---

*Semana 17 — Validación con Zod*
*Formato v4 — Constitución v2.2 · Protocolo QA con Fases 6b y 6c*
*Óscar — Full Stack Developer en formación 🇨🇱*
