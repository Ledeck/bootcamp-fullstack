# 🔬 REPORTE QA — BOOTCAMP SEMANA 17

> Documento interno de auditoría. Contiene el PRODUCTO de cada fase, no su
> declaración (Enmienda 6).

---

```
ACTA DE GENERACIÓN
Fecha: 2026-08-06
Semana en curso de Óscar al generar: 05 (proyecto semanal)
Distancia estimada hasta el uso: ~11 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes consultadas 2026-08-06:
   · zod.dev/v4 · zod.dev/v4/changelog (oficiales)
   · gist Zod v4 migration guide (abril 2026)
   · buildmvpfast.com Zod v4 migration (julio 2026)
   · baeseokjae.github.io Zod v4 guide (junio 2026)
   · dev.to/pockit_tools migración Zod 4 (marzo 2026)
   · dev.to/ahmed_mahmoud360 (1 mes)
   · mattburgess.medium.com React Hook Form vs React 19
Referencia: Zod 4 · React 19 · Next.js 16
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

---

## FASE 0 — DELIMITACIÓN

La Semana 17 no tenía tema. La planificada originalmente (firma electrónica y
SII) quedó dormida por la Enmienda 19.

### Los cuatro candidatos y por qué se descartaron tres

| Candidato | Veredicto |
|---|---|
| **Zustand** | ❌ La Semana 11 Día 5 declara el criterio para pasar a Zustand: *"cuando el perfilador muestre re-renders que no deberían ocurrir"*. Ese momento no ha llegado. Enseñarlo ahora es solución sin problema — prohibido por la Constitución |
| **Testing** | ❌ Problema de secuencia: para escribir tests útiles hace falta código estable, y la aplicación cambia cada semana |
| **Despliegue** | ⏳ Buen candidato por la Enmienda 19, pero desplegar en Vercel son minutos. Lo que da para semana —variables de entorno, base en producción, errores que solo aparecen desplegado— encaja mejor **después** de tener formularios sólidos. Recomendado como Semana 18 |
| **Zod + formularios** | ✅ Elegido |

### Por qué Zod

```
1. Es el hueco MÁS ANTIGUO sin tapar, y lo declaró el propio material:
   el pie de la Semana 14 dice "los datos ahora persisten, pero nada
   valida su forma antes de entrar"

2. La Semana 16 lo agravó. Antes solo Óscar metía datos. Ahora hay
   usuarios reales enviando formularios

3. Cierra el círculo de PS-3. Allí aprendió que TypeScript no protege
   en la red, el DOM ni el usuario. Zod es la herramienta que construye
   ese puente — y hace algo único: el tipo sale del esquema, así que
   validación y tipo NO pueden desincronizarse

4. Es prerrequisito de todo lo demás. Cualquier formulario posterior
   lo necesita

5. CONVERGENCIA CON PS-2 — la razón más fuerte. Allí escribió a mano
   saneamiento, validación con motivos y cuarentena. Zod hace eso
   declarativamente. Habiendo sufrido la versión artesanal, la librería
   no es magia: es reconocimiento
```

### Fuera del alcance

| Excluido | Razón |
|---|---|
| `z.toJSONSchema()` | Para generar OpenAPI. Sin problema que lo justifique |
| `z.globalRegistry` | Metadatos en esquemas. Nicho |
| `z.templateLiteral()` | Validar patrones tipo `event:${string}`. Sin caso de uso aquí |
| `zod/mini` | Optimización de bundle. Sin problema medido |
| Esquemas recursivos | Estructuras anidadas sin límite. El dominio no las tiene |
| `z.config(z.locales.es())` | Localización global. Los mensajes se escriben a mano, que enseña más |
| Yup, Valibot, ArkType | Alternativas. Zod está en el stack declarado |

### Prerrequisitos

```
Semana 09 → TypeScript, z.infer se apoya en él         ✔ verificado
              ⚠ CRÍTICO: el Día 7 (ejecutar vs comprobar) es la base
                conceptual del Día 1 de esta semana
Semana 11 → uniones discriminadas (safeParse es una)    ✔ verificado
Semana 12 → Server Actions                              ✔ verificado
Semana 14 → Prisma, datos que persistir                 ✔ verificado
Semana 16 → autorización, "no confíes en el cliente"    ✔ verificado
PS-2      → validación manual — el contraste            ✔ generado
PS-3      → las tres fronteras                          ✔ generado
```

---

## FASE 1 — INVESTIGACIÓN

### Zod 4 — cambios verificados

| Zod 3 | Zod 4 | Estado |
|---|---|---|
| `z.string().email()` | `z.email()` | deprecado, funciona |
| `z.string().url()` | `z.url()` | deprecado, funciona |
| `z.string().uuid()` | `z.uuid()` | **más estricto** (RFC 4122/9562). `z.guid()` para el comportamiento antiguo |
| `z.string().datetime()` | `z.iso.datetime()` | deprecado |
| `{ message }` | `{ error }` | deprecado |
| `{ required_error, invalid_type_error }` | `{ error }` | **eliminados** |
| `error.errors` | `error.issues` | **ELIMINADO** |
| `error.format()` | `z.treeifyError()` | deprecado |
| `z.record(v)` | `z.record(k, v)` | **rompe** — dos argumentos obligatorios |
| `.merge()` | `.extend()` | deprecado |
| `.strict()`, `.passthrough()`, `.strip()` | funciones de objeto | deprecados |

**Novedades:** `z.prettifyError()`, `z.toJSONSchema()`, `z.templateLiteral()`,
`z.globalRegistry`, `zod/mini`. Validación numérica más estricta (rechaza
`Infinity` y enteros no seguros).

**Codemod disponible:** `npx zod-v3-to-v4`.

**Rendimiento:** un benchmark reportó `tsc` bajando de 47s a 5s tras migrar.

### Hallazgo que cambió el diseño de la semana

```
React 19 introdujo manejo de formularios nativo: useActionState, acciones
de formulario, estado de envío incluido.

Consecuencia: React Hook Form ya NO es la respuesta obvia. Una fuente lo
describe como "menos una elección necesaria".

DECISIÓN DE DISEÑO: el Día 4 enseña los DOS caminos con criterio explícito
de cuándo cada uno, en vez de imponer RHF.

Sin este hallazgo, la semana habría enseñado React Hook Form como única
opción — correcto hasta 2024, discutible en 2026.
```

### Hueco declarado de la Fase 1

```
NO se verificó el número de versión exacto de Zod ni de @hookform/resolvers.
Se confirmó que Zod 4 es la línea vigente y sus cambios, pero no el número
menor.

El material NO afirma ninguno. Comprobar con npm view zod version.
```

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ Los tipos de TypeScript se borran al compilar; no existen en ejecución
✔ z.infer deriva el tipo del esquema — no pueden desincronizarse
✔ safeParse devuelve una unión discriminada
✔ .transform() cambia el tipo de salida; z.input y z.output los distinguen
✔ .refine() solo corre si las validaciones previas pasaron
✔ FormData.get() devuelve string | File | null, nunca number
✔ Sin valueAsNumber, RHF entrega string y Zod lo rechaza
✔ La acción de useActionState recibe DOS parámetros
✔ z.optional() y z.nullable() son distintos
✔ error.errors se eliminó en Zod 4
```

### Corrección aplicada

```
Formulación incorrecta (borrador):
  "Valida en el cliente con React Hook Form y Zod"

Por qué era incorrecta:
  Presenta la validación de cliente como suficiente. Cualquiera puede
  invocar la Server Action desde la consola — Óscar lo comprobó en el
  Día 4 de la Semana 16.

Formulación corregida:
  El Día 3 (servidor) va ANTES del Día 4 (formularios), deliberadamente.
  El mini-ejercicio del Día 4 pide refutar exactamente esa creencia.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ El Día 1 instala el dolor con el propio código de Óscar
✔ El Día 3 (servidor) precede al Día 4 (cliente) — orden deliberado
✔ El Día 5 distingue errores de forma y de negocio, base del proyecto
✔ safeParse se presenta como unión discriminada, conectando con la S11
✔ "entrada: unknown" aparece en los Días 1, 3 y en el proyecto
```

### Anclaje en trabajo previo

```
· Día 1 → el Día 7 de la S09: los tipos se borran al compilar
· Día 1 → el Día 4 de la S16: el cliente hostil por consola
· Día 2 → PS-2: las tres funciones de saneamiento, ahora con .transform()
· Día 2 → S09: .partial() es Partial<T> del lado de la validación
· Día 2 → S05 Día 4: optional vs nullable es ausencia vs valor falsy
· Día 3 → PS-2 y PS-3: unknown como entrada, tercera aparición
· Día 4 → PS-3: la frontera del usuario, todo llega como string
· Día 5 → S11: el estado del formulario como unión discriminada
```

**El ejercicio 4 del Día 2 es el ancla central:** pide portar tres funciones
de PS-2 a esquemas Zod y comparar. Y exige honestidad en las dos direcciones
— *"no todo es ganancia"*.

### Ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — provocar el fallo | Proyecto D6, criterio adversarial |
| D1 — primer esquema | Proyecto D6 |
| D1 — juzgar código | Ninguno. **Justificado:** verificación (E14) |
| D2 — esquema de reserva | Proyecto D6, requisito |
| D2 — reemplazar tipos manuales | Proyecto D6, requisito |
| D2 — regla del cupo | Proyecto D6, requisito |
| D2 — portar PS-2 | Ninguno. **Justificado:** comparación de criterio |
| D3 — todas las acciones | Proyecto D6, requisito |
| D3 — el orden correcto | Proyecto D6 |
| D3 — cliente hostil | Proyecto D6, criterio de aprobación |
| D3 — juzgar treeifyError | Ninguno. **Justificado:** criterio de seguridad |
| D4 — camino A | Proyecto D6 |
| D4 — camino B | Proyecto D6 |
| D4 — comparar | Ninguno. **Justificado:** criterio |
| D4 — decidir y borrar | Proyecto D6 |
| D5 — mensajes en español | Proyecto D6, requisito |
| D5 — errores de negocio | Proyecto D6, requisito |
| D5 — cuatro estados | Proyecto D6, requisito |
| D5 — juzgar experiencia | Ninguno. **Justificado:** verificación (E14) |

**Cero huérfanos sin justificar.**

---

## FASE 6b — CONFORMIDAD

Verificación automática sobre los dos archivos:

```
Indentación impar:            0
Sentencias sin punto y coma:  0
Ocurrencias de == o !=:       0
```

```
□✔ Nombres en español: esquemaReserva, entrada, resultado, pendiente,
     nombrePersona, esquemaMonto
     ⚠ Excepción documentada: identificadores de las librerías
       (safeParse, register, formState, valueAsNumber) en inglés

□✔ .prettierrc — semi, tabWidth 2, comillas dobles: conformes

□✔ Enmienda 14 — verificación
     D1 Ej.3, D3 Ej.4, D4 mini-ejercicio, D5 Ej.4 + adversarial del D6
     Cinco ejercicios de juicio

□✔ Enmienda 17 — Cheat Sheet como guion, no lectura previa

□✔ Enmienda 19 — proyecto ficticio en Nexus, sin usuarios reales
```

---

## FASE 6c — COBERTURA TÉCNICA

| Técnica | Cheat Sheet | Bootcamp | Estado |
|---|---|---|---|
| `z.object` y reglas | §2, §4 | D1, D2 | ✅ |
| `z.infer` | §3, §7 | D2 | ✅ |
| `safeParse` / `parse` | §2, §7 | D1, D3 | ✅ |
| `.refine()` | §4, §7 | D2 | ✅ |
| `.transform()` | §4 | D2 | ✅ |
| `z.treeifyError` | §5, §8 | D3 | ✅ |
| `useActionState` | §6, §7 | D4 | ✅ |
| `zodResolver` | §6 | D4 | ✅ |
| **`valueAsNumber`** | **§6** | D4 | ✅ **corregido** |
| **`.partial()` / `.extend()`** | **§4** | D2 | ✅ **corregido** |

### Huecos menores detectados y corregidos

```
valueAsNumber y .partial()/.extend() estaban en el cuerpo del bootcamp
—donde se enseñan antes de exigirse, cumpliendo la Fase 6c— pero NO en
el Cheat Sheet.

No eran huecos según la definición estricta. Pero el Cheat Sheet es
material de CONSULTA POSTERIOR (Enmienda 17), y una técnica que se usa
en el proyecto debería poder buscarse ahí.

CORRECCIÓN: añadidas dos secciones al Cheat Sheet —"Componer esquemas" y
"La conversión de tipos en formularios"— con sus trampas.
```

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS

```
RECHAZADA 1: "Zod valida tus datos"

Razón: describe QUÉ hace sin decir por qué hace falta si ya tienes
TypeScript. El alumno que no entienda que los tipos se borran al compilar
va a ver Zod como duplicación burocrática.

Reemplazo: el Día 1 abre haciéndole invocar su propia Server Action con
datos inválidos y ver que se guardan.
```

```
RECHAZADA 2: "Usa React Hook Form para tus formularios"

Razón: era correcto hasta 2024. React 19 trae manejo nativo, y para
formularios simples RHF es una dependencia que no aporta.

Reemplazo: el Día 4 enseña los dos caminos con tabla de criterio, y el
Ejercicio 3 obliga a implementar ambos y desactivar JavaScript para ver
la diferencia.
```

```
RECHAZADA 3: "Valida en el cliente para mejor experiencia"

Razón: cierto y peligrosamente incompleto. Ver Fase 4.

Reemplazo: el Día 3 (servidor) precede al Día 4 (cliente), y el
mini-ejercicio del Día 4 pide refutar esa creencia con un ejemplo
concreto de cómo saltársela.
```

```
RECHAZADA 4: "z.infer te ahorra escribir el tipo"

Razón: subestima el punto. El ahorro de teclas es lo menos importante.
Lo que importa es que el tipo y la validación NO PUEDEN
DESINCRONIZARSE, porque son el mismo objeto.

Reemplazo: se presenta como la solución al problema número uno de PS-2,
donde tipo y validación eran independientes y nada garantizaba que
coincidieran.
```

```
RECHAZADA 5: "Devuelve los errores de Zod al cliente"

Razón: z.treeifyError expone la estructura completa del esquema,
incluidos nombres de campos internos. En un formulario propio no importa;
en una API pública es filtración de estructura.

Reemplazo: se enseña, y el Ejercicio 4 del Día 3 pide juzgar en qué casos
es un problema y en cuáles no. Criterio, no regla.
```

### Ataques sin hallazgo

```
✔ ¿Se enseña sintaxis de Zod 3? Verificado: z.email, error, .issues,
  .extend — todo Zod 4, con tabla de equivalencias
✔ ¿Algún día da la solución antes del dolor? El D1 es enteramente dolor
✔ ¿El proyecto es verificable? Sí, adversarialmente por consola
✔ ¿Hay secciones "cuándo NO"? En safeParse vs parse, en los dos caminos
  de formulario, y en forma vs negocio
```

---

## ENMIENDA 10 — SINTAXIS NUEVA POR PESO

| Sintaxis | Peso | Entrega |
|---|---|---|
| `z.infer<typeof esquema>` | **MEDIA** | Cuerpo del D2 + 2 trampas |
| `useActionState` | **MEDIA** | Cuerpo del D4 + 2 trampas |
| `safeParse` | **LIGERA** | Definición + trampa (comprobar success) |
| `.refine()` | **LIGERA** | Definición + trampa (orden de ejecución) |
| `zodResolver` | **LIGERA** | Ejemplo en el D4 |

```
✔ Ninguna PESADA de contrabando
✔ Las dos MEDIA se enseñan en el cuerpo, no en un ejercicio
✔ Ninguna en el Día 1 sin explicación previa
```

---

## HALLAZGOS ABIERTOS

### 1. Versión exacta de Zod sin verificar

Declarado en la Fase 1. El material no afirma ningún número.

### 2. El Día 4 puede quedar obsoleto de forma asimétrica

React 19 vs React Hook Form es una tensión **activa**. En once meses puede
haberse resuelto en cualquier dirección: React 20 puede absorber más, o RHF
puede adaptarse.

**El criterio del día sobrevive** —cuándo hace falta validación en cada tecla
y cuándo no— pero los ejemplos concretos pueden envejecer.

### 3. Fase 6c pendiente en las Semanas 06, 07, 10-15

Solo las Semanas 16 y 17 la tienen desde el diseño. La 05 tras el hallazgo de
Óscar.

### 4. Despliegue sigue sin semana

La Enmienda 19 fijó proyectos de portafolio desde la Semana 12, y un
portafolio sin URL pública no lo es. **Recomendado como Semana 18.**

---

## ADVERTENCIA SOBRE LA VIGENCIA

```
CRÍTICO → versión de Zod y sintaxis deprecada. Las formas de Zod 3 se
          eliminarán en la próxima mayor; si ya salió Zod 5, revisar todo
CRÍTICO → React Hook Form vs React 19 nativo. Tensión activa
ALTO    → useActionState y su firma
MEDIO   → z.treeifyError y el formato de errores
BAJO    → por qué TypeScript no basta en ejecución
BAJO    → validar en el servidor, no solo en el cliente
BAJO    → la separación forma / negocio
```

**Nota de precedencia:** si zod.dev contradice este material, gana zod.dev.

---

*Reporte QA Semana 17 — 2026-08-06*
*Constitución v2.2 · Fases 0-8 incluyendo 6b y 6c*
