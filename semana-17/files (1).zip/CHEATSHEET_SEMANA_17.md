# 📄 CHEAT SHEET — SEMANA 17
## Validación · Zod · Formularios · React 19

> Guion de la clase de activación. Se entrega POR PARTES, día a día.
> No lo leas completo de antemano.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado y verificado: agosto 2026
Referencia: Zod 4 · React 19 · Next.js 16
REGENERAR antes de empezar la semana.
```

```bash
npm install zod
npm install react-hook-form @hookform/resolvers
```

⚠ El segundo comando es **opcional**. El Día 4 explica cuándo hace falta React
Hook Form y cuándo React 19 ya lo resuelve solo.

### Cambios de Zod 4 — el material anterior está desactualizado

| Zod 3 | Zod 4 |
|---|---|
| `z.string().email()` | **`z.email()`** |
| `z.string().url()` | **`z.url()`** |
| `z.string().uuid()` | **`z.uuid()`** (más estricto) |
| `z.string().datetime()` | **`z.iso.datetime()`** |
| `{ message: "..." }` | **`{ error: "..." }`** |
| `{ required_error, invalid_type_error }` | **`{ error: "..." }`** (unificado) |
| `error.errors` | **`error.issues`** |
| `error.format()` | **`z.treeifyError(error)`** |
| `z.record(v)` | **`z.record(k, v)`** — dos argumentos |
| `.merge()` | **`.extend()`** |

Las formas antiguas de string **siguen funcionando pero están deprecadas**, y
se eliminarán en la próxima versión mayor. `error.errors` sí se eliminó.

> Hay un codemod si algún día migras código existente: `npx zod-v3-to-v4`.

**Qué verificar al llegar:** la versión de Zod, si las formas deprecadas ya
desaparecieron, y si React Hook Form sigue siendo relevante frente a React 19.

---

## 1. EL PROBLEMA — TYPESCRIPT NO EXISTE EN EJECUCIÓN

Esto lo aprendiste en el Día 7 de la Semana 9, y aquí es la base de todo:

```typescript
type Reserva = { cliente: string; personas: number };

async function crearReserva(datos: Reserva) {
  await prisma.reserva.create({ data: datos });
}
```

El tipo dice `personas: number`. Si alguien llama a esa Server Action desde la
consola del navegador con `{ cliente: "", personas: -5 }`, **se guarda**.

**Por qué:** los tipos se borran al compilar. En ejecución no queda nada que
compruebe. TypeScript protege mientras escribes; no protege cuando alguien
usa tu programa.

```
TypeScript  →  comprobación en tiempo de ESCRITURA
Zod         →  comprobación en tiempo de EJECUCIÓN
```

**Idea mental:** TypeScript es el plano; Zod es el inspector en la obra.

---

## 2. ESQUEMAS

```typescript
import { z } from "zod";

const esquemaReserva = z.object({
  cliente: z.string().min(3, { error: "Mínimo 3 caracteres" }),
  correo: z.email({ error: "Correo inválido" }),
  personas: z.number().int().positive({ error: "Debe ser mayor a 0" }),
  expedicionId: z.string().startsWith("EXP")
});
```

Un esquema describe la forma **y las reglas** de un dato.

### Validar

```typescript
// parse — lanza excepción si falla
const datos = esquemaReserva.parse(entrada);

// safeParse — devuelve un resultado, no lanza
const resultado = esquemaReserva.safeParse(entrada);

if (!resultado.success) {
  console.log(resultado.error.issues);
  return;
}

resultado.data;   // aquí ya está tipado y validado
```

**Cuál usar:** `safeParse` casi siempre. `parse` solo cuando un fallo debe
tumbar el programa.

`safeParse` devuelve una **unión discriminada** — el patrón de la Semana 11.
Dentro del `if`, TypeScript sabe que existe `error`; fuera, que existe `data`.

---

## 3. LA CARACTERÍSTICA QUE LO CAMBIA TODO — `z.infer`

```typescript
const esquemaReserva = z.object({
  cliente: z.string(),
  personas: z.number()
});

type Reserva = z.infer<typeof esquemaReserva>;
// { cliente: string; personas: number }
```

**El tipo sale del esquema.** No escribes los dos.

Y esa es la diferencia con validar a mano, como hiciste en PS-2: allí tenías
el tipo por un lado y la validación por otro, y nada garantizaba que
coincidieran. Si agregabas un campo al tipo y olvidabas la validación, no
pasaba nada — hasta producción.

Con `z.infer` **no pueden desincronizarse**, porque son el mismo objeto.

> ⚠ **Trampa:** `typeof esquemaReserva`, no `typeof Reserva`. Estás pidiendo
> el tipo de la *variable del esquema*, no del tipo resultante.

---

## 4. TIPOS Y REGLAS DE USO FRECUENTE

```typescript
z.string()          z.number()         z.boolean()
z.date()            z.array(z.string())
z.email()           z.url()            z.uuid()
z.iso.date()        z.iso.datetime()

z.enum(["confirmada", "pendiente", "cancelada"])
z.literal("admin")
z.string().optional()          // puede faltar
z.string().nullable()          // puede ser null
z.string().default("sin dato")
```

```typescript
z.string().min(3).max(100).trim()
z.number().int().positive().max(50)
z.array(z.string()).nonempty()
```

### Refinamiento — reglas propias

```typescript
const esquema = z.object({
  personas: z.number(),
  cupoMaximo: z.number()
}).refine((d) => d.personas <= d.cupoMaximo, {
  error: "Excede el cupo disponible",
  path: ["personas"]
});
```

`refine` valida **relaciones entre campos**, algo que un tipo no puede
expresar. El `path` decide en qué campo aparece el error.

### Componer esquemas

```typescript
const base = z.object({ cliente: z.string(), personas: z.number() });

base.partial()                      // todos los campos opcionales
base.extend({ id: z.string() })     // agregar campos
base.pick({ cliente: true })        // quedarse con algunos
base.omit({ personas: true })       // quitar algunos
```

`.partial()` es el `Partial<T>` de la Semana 9, del lado de la validación.

⚠ En Zod 4 `.merge()` está deprecado — usa `.extend()`.

### Transformar

```typescript
const esquemaMonto = z.string().transform((s) => Number(s.replace(/[$.]/g, "")));
```

Eso es `normalizarMonto` de PS-2, en una línea. Zod valida **y** convierte.

> ⚠ **Trampa:** `.transform()` cambia el tipo de salida. `z.infer` te da el
> tipo **después** de transformar, no antes. Si necesitas los dos, existe
> `z.input<typeof esquema>` y `z.output<typeof esquema>`.

---

## 5. VALIDAR EN EL SERVIDOR

La regla de la Semana 16 aplicada a datos:

> Nunca confíes en lo que llega del cliente. Validar en el formulario mejora
> la experiencia; validar en el servidor es lo que protege.

```typescript
"use server";
import { auth } from "@clerk/nextjs/server";

const esquemaReserva = z.object({
  cliente: z.string().min(3),
  personas: z.number().int().positive()
});

export async function crearReserva(entrada: unknown) {
  const { userId, isAuthenticated } = await auth();
  if (!isAuthenticated) return { error: "No autorizado" };

  const resultado = esquemaReserva.safeParse(entrada);
  if (!resultado.success) {
    return { errores: z.treeifyError(resultado.error) };
  }

  await prisma.reserva.create({
    data: { ...resultado.data, usuarioId: userId }
  });

  revalidatePath("/reservas");
  return { exito: true };
}
```

**Fíjate en el parámetro: `entrada: unknown`, no `entrada: Reserva`.**

Tipar el parámetro como `Reserva` es una mentira: no tienes forma de saber
qué te mandaron. `unknown` es honesto y te obliga a validar antes de usar.

Es la misma elección que hiciste en PS-2 y en PS-3.

### Formatear errores

```typescript
z.treeifyError(error)    // estructura anidada, útil para formularios
z.prettifyError(error)   // texto legible, útil para logs
resultado.error.issues   // el array crudo
```

⚠ `error.errors` y `error.format()` son de Zod 3. El primero **se eliminó**.

---

## 6. FORMULARIOS — DOS CAMINOS

React 19 cambió el panorama. Ya no hay una única respuesta.

### Camino A — React 19 nativo, sin librerías

```tsx
"use client";
import { useActionState } from "react";

export function FormularioReserva() {
  const [estado, accion, pendiente] = useActionState(crearReserva, null);

  return (
    <form action={accion}>
      <input name="cliente" />
      {estado?.errores?.cliente && <span>{estado.errores.cliente}</span>}

      <button disabled={pendiente}>
        {pendiente ? "Guardando..." : "Reservar"}
      </button>
    </form>
  );
}
```

```
✅ Sin dependencias
✅ Funciona sin JavaScript en el cliente
✅ El estado de carga viene incluido
❌ La validación solo ocurre al enviar
```

### Camino B — React Hook Form

```tsx
"use client";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";

export function FormularioReserva() {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(esquemaReserva)
  });

  return (
    <form onSubmit={handleSubmit(enviar)}>
      <input {...register("cliente")} />
      {errors.cliente && <span>{errors.cliente.message}</span>}
    </form>
  );
}
```

```
✅ Validación mientras el usuario escribe
✅ Muy pocos re-renders
✅ Bueno para formularios largos o con campos dependientes
❌ Una dependencia más
❌ No funciona sin JavaScript
```

### La conversión de tipos en formularios

Los campos HTML siempre entregan texto. Es la frontera del usuario de PS-3.

```tsx
// React Hook Form
<input {...register("personas", { valueAsNumber: true })} type="number" />

// React 19 nativo
const personas = Number(datos.get("personas"));
```

> ⚠ **Trampa:** sin `valueAsNumber: true`, el campo llega como string y Zod
> lo rechaza aunque el usuario haya escrito un número correcto.
>
> ⚠ **Segunda:** `FormData.get()` devuelve `string | File | null`. Nunca
> `number`. Convertir y comprobar `Number.isNaN`.

### El criterio

| Situación | Camino |
|---|---|
| Formulario simple, pocos campos | **A** — React 19 |
| Debe funcionar sin JavaScript | **A** |
| Validación en cada tecla | **B** — RHF |
| Muchos campos o campos dependientes | **B** |
| Formularios en varios pasos | **B** |

**Y en los dos casos, el mismo esquema Zod se usa también en el servidor.**
Esa es la ventaja de tenerlo separado del formulario: un esquema, dos usos.

---

## 7. SINTAXIS NUEVA DE ESTA SEMANA

### `z.infer<typeof esquema>` · peso MEDIO

Extrae el tipo TypeScript desde un esquema Zod.

> ⚠ **Trampa 1:** es `typeof esquema`, no `esquema`.
> ⚠ **Trampa 2:** con `.transform()`, devuelve el tipo de salida. Usa
> `z.input` y `z.output` si necesitas distinguirlos.

### `safeParse()` · peso LIGERO

Valida sin lanzar. Devuelve `{ success: true, data }` o
`{ success: false, error }`.

> ⚠ **Trampa:** hay que comprobar `success` antes de acceder a `data`.
> TypeScript te obliga — es una unión discriminada.

### `useActionState()` · peso MEDIO

Hook de React 19 para el estado de una acción de formulario.

```tsx
const [estado, accion, pendiente] = useActionState(miAccion, valorInicial);
```

> ⚠ **Trampa:** la acción recibe **dos** parámetros: el estado anterior y el
> `FormData`. Es fácil olvidar el primero.
>
> ```typescript
> export async function crearReserva(estadoPrevio: Estado, datos: FormData) { ... }
> ```

### `.refine()` · peso LIGERO

Regla propia sobre uno o varios campos.

> ⚠ **Trampa:** solo se ejecuta si las validaciones anteriores pasaron. Si un
> campo ya falló su tipo, el `refine` ni se llama.

---

## 8. TABLA DE DECISIÓN

| Necesitas | Usa |
|---|---|
| Definir la forma de un dato | `z.object({ ... })` |
| El tipo TypeScript del esquema | `z.infer<typeof esquema>` |
| Validar sin que lance | `safeParse()` |
| Validar y que lance | `parse()` |
| Regla entre dos campos | `.refine()` |
| Convertir mientras validas | `.transform()` |
| Errores para pintar en un formulario | `z.treeifyError()` |
| Errores para un log | `z.prettifyError()` |
| Formulario simple | `useActionState` |
| Validación en cada tecla | React Hook Form |

---

## 9. FUERA DE ALCANCE

```
z.toJSONSchema()        generar OpenAPI desde esquemas
z.globalRegistry        metadatos en esquemas
z.templateLiteral()     validar patrones tipo `event:${string}`
zod/mini                versión reducida para bundle
Esquemas recursivos     categorías anidadas sin límite
Localización de errores z.config(z.locales.es())
```

---

*Cheat Sheet Semana 17 — Validación con Zod*
*Prerrequisitos: Semana 09 (TypeScript) · 11 (uniones discriminadas) · 12 (Server Actions) · 14 (Prisma) · 16 (autorización) · PS-2 (validación a mano)*
