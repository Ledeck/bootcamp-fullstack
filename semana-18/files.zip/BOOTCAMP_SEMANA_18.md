# 📘 BOOTCAMP SEMANA 18
## Testing · Vitest · Testing Library

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-08-06
Semana en curso de Óscar al generar: 06 (Día 2)
Distancia estimada hasta el uso: ~12 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes consultadas 2026-08-06:
   · nextjs.org/docs/app/guides/testing/vitest (oficial, feb 2026)
   · dev.to/whoffagents — Vitest vs Jest Next.js 2026 (abril 2026)
   · wisp.blog — comparación Vitest/Jest Next.js (junio 2026)
   · coderfile.io/blog/vitest-vs-jest-2026 (marzo 2026)
   · pristren.com — Vitest unit testing guide (junio 2026)
   · nandann.com — React TS Vite Vitest setup (mayo 2026)
Referencia: Vitest · React Testing Library · Next.js 16
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

---

> **Flujo de la semana:** el Cheat Sheet se entrega por partes, día a día.

---

## ⚠️ NOTA DE ALCANCE

Esta semana cumple la **Enmienda 14**, que elevó la verificación a competencia
de primer orden y hasta ahora no tenía semana propia.

Y tiene una particularidad: **no vas a escribir tests sobre código nuevo. Vas
a escribirlos sobre el tuyo.**

Tienes cuatro proyectos integradores y trece semanas de material. Ahí dentro
hay lógica de negocio real, reglas que has escrito, y —esto es lo importante—
**bugs que ya cometiste**.

Cada uno de esos bugs es un test esperando a ser escrito.

**Prerrequisito real:** haber hecho PS-1 a PS-4. Sin código propio que testear,
esta semana sería teoría.

---

## 🗓 DÍA 1 — QUÉ TESTEAR

### 🎯 Objetivo
Entender qué hace que un test valga la pena, con bugs que ya te ocurrieron.

---

### 📖 El problema real

En PS-1 cometiste cuatro errores. Ninguno lanzó excepción:

```javascript
Object.entries(expedicionesTrekking)   // el sort no ordenaba
acc.precioBase + expedicion.precioBase  // NaN con acumulador 0
duracionDias > 3                        // debía ser <= 3
cuposPorExpId.length                    // undefined, es un objeto
```

Los cuatro los detectamos **verificando contra anclas numéricas**: el promedio
tenía que dar $261.250, había 8 expediciones, el método más usado era tarjeta.

Comprobaste esas anclas **a mano**, una vez, mirando la consola.

**Un test es esa misma comprobación, escrita para que se repita sola cada vez
que toques el código.**

---

### 📖 Tu primer test es un bug tuyo

```typescript
import { describe, it, expect } from "vitest";
import { calcularPromedio } from "@/logica/analisis";

describe("calcularPromedio", () => {
  it("promedia los precios del catálogo", () => {
    expect(calcularPromedio(expediciones)).toBe(261250);
  });
});
```

Si alguien vuelve a escribir `acc.precioBase` con acumulador `0`, ese test
falla al instante. Sin abrir el navegador, sin mirar la consola.

---

### 📖 La regla — Enmienda 14

> **Un test debe atrapar algo real.** No subir un porcentaje.

Un test inútil:

```typescript
it("suma dos números", () => {
  expect(2 + 2).toBe(4);
});
```

Comprueba que JavaScript funciona. Nunca fallará, nunca avisará de nada, y
sube la cobertura.

**El criterio, antes de escribir cualquier test:** *¿qué bug atraparía esto?*
Si no hay respuesta, no lo escribas.

---

### 📖 Qué testear y qué no

```
✅ SÍ
   Lógica de negocio con reglas
   Transformación de datos
   Casos borde y valores límite
   Bugs que ya ocurrieron
   Funciones puras

❌ NO
   Que Prisma, Zod o React funcionen
   Nombres de variables internas
   Estilos y maquetación
   Código sin ramas ni decisiones
```

**El más rentable de todos:** cuando encuentres un bug, escribe primero el
test que lo reproduce; después arréglalo. Se llama **test de regresión** y es
el que más valor tiene por línea escrita.

---

### 📖 Los casos borde son donde vive el valor

Recuerda 3.2 de PS-1: solo una expedición llegaba al 50%, **exactamente**. Si
usabas `>` en vez de `>=`, el resultado era una lista vacía.

```typescript
it("incluye la expedición que ocupa exactamente el 50%", () => {
  const resultado = conOcupacionAlta([{ ocupados: 6, cupoMaximo: 12 }]);
  expect(resultado).toHaveLength(1);
});
```

Ese test vale más que veinte que prueben el caso normal. **El límite es donde
se rompen las cosas.**

---

### 📖 Mini-ejercicio de comprensión

```typescript
it("crea una reserva", () => {
  const reserva = crearReserva({ cliente: "Ana", personas: 2 });
  expect(reserva).toBeDefined();
});
```

Pasa siempre. ¿Qué bug atraparía? ¿Cómo lo reescribirías para que sirva?

---

### 🛠 EJERCICIOS DÍA 1

**Ejercicio 1** — el inventario

Sin escribir código, lista en `PLAN_TESTS.md` diez funciones de tus proyectos
que **merecen** test. Para cada una, escribe qué bug atraparía.

Si en alguna no sabes qué responder, quítala de la lista.

**Ejercicio 2** — el catálogo de bugs

Repasa tus `NOTAS.md` de PS-1 a PS-4 y lista todos los bugs que documentaste.
Esos son tus tests de regresión prioritarios.

**Ejercicio 3** — juzga estos tests

```typescript
it("test 1", () => {
  expect(formatearPrecio(450000)).toBe("$450.000");
});

it("funciona", () => {
  expect(typeof calcularTotal).toBe("function");
});

it("el array tiene elementos", () => {
  expect(expediciones.length).toBeGreaterThan(0);
});
```

Los tres pasan. Di de cada uno si vale la pena y por qué. Reescribe los que
tengan arreglo.

---

**Cuando termines avísame — valido el Día 1.** ✅

---

## 🗓 DÍA 2 — VITEST

### 🎯 Objetivo
Montar el entorno y escribir tests sobre tu lógica pura.

---

### 📖 Por qué Vitest y no Jest

Jest fue el estándar durante años. En 2026 no hay razón para elegirlo en un
proyecto nuevo:

```
· API idéntica: describe, it, expect, beforeEach
· 10-20× más rápido al arrancar
· ESM nativo — Jest necesita configuración extra
· TypeScript sin ts-jest ni babel-jest
· Superó a Jest en descargas para proyectos nuevos
```

**Si algún día trabajas en un proyecto con Jest**, los tests que escribas aquí
se ven igual. La API es compatible a propósito.

---

### 📖 El setup

Está en el bloque perecedero de la Cheat Sheet. Un detalle:

⚠ El archivo de configuración es **`vitest.config.mts`**, con `.mts`. Es un
módulo ES explícito.

---

### 📖 Anatomía

```typescript
import { describe, it, expect } from "vitest";
import { calcularDesdeTotal } from "@/lib/formatos-cl";

describe("calcularDesdeTotal", () => {
  it("descompone un monto con IVA chileno", () => {
    // Arrange
    const total = 450000;

    // Act
    const resultado = calcularDesdeTotal(total);

    // Assert
    expect(resultado.neto).toBe(378151);
    expect(resultado.iva).toBe(71849);
    expect(resultado.neto + resultado.iva).toBe(total);
  });
});
```

Esa última afirmación es la interesante: **no comprueba un número, comprueba
una propiedad**. Neto más IVA debe dar el total, siempre, con cualquier monto.

---

### 📖 El nombre del test es documentación

```
❌ it("prueba calcularDesdeTotal")
✅ it("descompone un monto con IVA chileno")
✅ it("redondea el neto sin perder pesos en el total")
```

Cuando un test falla, su nombre es lo primero que lees. Debe decir **qué hace
el sistema**, no qué función se llama.

---

### 📖 `toBe` vs `toEqual`

```typescript
expect({ a: 1 }).toBe({ a: 1 });      // ❌ falla
expect({ a: 1 }).toEqual({ a: 1 });   // ✅ pasa
```

`toBe` compara por identidad, como `===`. Dos objetos con el mismo contenido
son referencias distintas.

**Es la comparación por referencia que descubriste con `sort` en PS-1**, ahora
en el otro lado: allí te sorprendió que dos variables fueran el mismo array;
aquí te sorprende que dos objetos iguales no lo sean.

---

### 📖 Errores esperados

```typescript
it("lanza si el monto no es numérico", () => {
  expect(() => calcularDesdeTotal(NaN)).toThrow("Monto inválido");
});
```

⚠ **Trampa:** hay que pasar una **función**, no el resultado. Si escribes
`expect(calcularDesdeTotal(NaN))`, la excepción salta antes de que `expect`
la reciba y el test falla por otro motivo.

---

### 📖 Mini-ejercicio de comprensión

```typescript
it("suma correctamente", () => {
  expect(0.1 + 0.2).toBe(0.3);
});
```

Falla. ¿Por qué, y cuál es la afirmación correcta?

---

### 🛠 EJERCICIOS DÍA 2

**Ejercicio 1** — el entorno

Instala y configura Vitest. Escribe un test trivial y comprueba que
`npm test` lo ejecuta.

**Ejercicio 2** — `formatos-cl.test.ts`

Testea las cuatro funciones de la Semana 15: `formatearRut`,
`formatearPrecio`, `calcularDesdeTotal` y `formatearFecha`.

Incluye el caso borde del RUT con `K`, y la propiedad de que neto más IVA
siempre da el total.

**Ejercicio 3** — los cuatro bugs de PS-1

Escribe un test por cada uno de los errores del Módulo 1 y 2 de PS-1. Deben
fallar si reintroduces el bug.

Compruébalo: rompe el código a propósito, verifica que el test falla, arregla.

**Ejercicio 4** — la regla del 50%

Escribe tres tests para el umbral de ocupación: por debajo, exactamente en el
límite, por encima.

El del medio es el que importa.

---

**Cuando termines avísame — valido el Día 2.** ✅

---

## 🗓 DÍA 3 — TESTEAR LO QUE YA ESCRIBISTE

### 🎯 Objetivo
Cubrir la lógica de tus proyectos, y descubrir qué no se puede testear.

---

### 📖 El problema real

Tienes lógica repartida por cuatro proyectos. ¿Cuál testeas primero?

---

### 📖 El criterio de prioridad

```
1. Lo que ya falló         → tests de regresión
2. Lo que decide dinero    → precios, cupos, IVA
3. Lo que tiene reglas     → validación, permisos
4. Lo que cambia seguido
```

Lo que no aparece en esa lista probablemente no necesita test.

---

### 📖 Y aquí viene el descubrimiento

Intenta testear esto:

```typescript
export default async function PaginaReservas() {
  const { userId } = await auth();
  const reservas = await prisma.reserva.findMany({ where: { usuarioId: userId } });
  const total = reservas.reduce((a, r) => a + r.personas, 0);
  return <div>Total: {total}</div>;
}
```

**No puedes.** Es un Server Component asíncrono, y Vitest no los soporta.

Podrías mockear `auth` y `prisma`... y entonces el test comprobaría que
llamaste a los mocks. No que el cálculo sea correcto.

---

### 📖 La solución es de diseño, no de testing

```typescript
// logica/reservas.ts — testeable, sin dependencias
export function contarPersonas(reservas: Reserva[]): number {
  return reservas.reduce((a, r) => a + r.personas, 0);
}

// app/reservas/page.tsx — delgado, sin lógica
export default async function PaginaReservas() {
  const { userId } = await auth();
  const reservas = await prisma.reserva.findMany({ where: { usuarioId: userId } });
  return <div>Total: {contarPersonas(reservas)}</div>;
}
```

Ahora `contarPersonas` se testea sin base de datos, sin sesión y sin
navegador.

> **La conclusión de la semana:**
> **Si algo es difícil de testear, casi siempre es un problema de diseño.**

Y hay algo que quiero que notes: **llevas separando `logica/` de la
presentación desde la Semana 3.** No lo hiciste pensando en tests — lo
hiciste por claridad.

Resulta que es exactamente lo que los hace posibles. Las decisiones de
arquitectura buenas se pagan en sitios que no anticipaste.

---

### 📖 Testear una función pura de PS-2

```typescript
describe("normalizarMonto", () => {
  it("interpreta el punto chileno como separador de miles", () => {
    expect(normalizarMonto("$45.000")).toBe(45000);
  });

  it("devuelve null si no se puede interpretar", () => {
    expect(normalizarMonto("abc")).toBeNull();
  });

  it("acepta números tal cual", () => {
    expect(normalizarMonto(560000)).toBe(560000);
  });
});
```

El primero es un test de regresión: `Number("45.000")` da `45`, y eso era la
trampa documentada de PS-2.

---

### 📖 Mini-ejercicio de comprensión

Tu función `validarReserva` de PS-2 devuelve un array de motivos.

¿Cuántos tests escribirías, y qué comprobaría cada uno? Piensa en el caso de
un registro que viola **dos** reglas a la vez.

---

### 🛠 EJERCICIOS DÍA 3

**Ejercicio 1** — la lógica de PS-2

Testea `normalizarNombre`, `normalizarMonto`, `normalizarEstado` y
`validarReserva`. Al menos tres casos cada una, incluyendo los que fallan.

**Ejercicio 2** — refactor para testear

Busca en tu proyecto un Server Component con lógica dentro. Extrae la lógica
a `logica/` y testéala.

Documenta cuántas líneas se movieron y si la página quedó más legible.

**Ejercicio 3** — las reglas de PS-4

Testea la función que decide si se puede reservar según el cupo. Casos:
sobra, justo, falta por uno, expedición sin datos.

**Ejercicio 4** — juzga esta suite

```typescript
describe("crearReserva", () => {
  it("llama a prisma.reserva.create", async () => {
    const spy = vi.fn();
    vi.mock("@/lib/prisma", () => ({ default: { reserva: { create: spy } } }));
    await crearReserva({ cliente: "Ana", personas: 2 });
    expect(spy).toHaveBeenCalled();
  });
});
```

Pasa. ¿Qué comprueba en realidad? ¿Qué bug **no** atraparía? Reescríbelo para
que sirva.

---

**Cuando termines avísame — valido el Día 3.** ✅

---

## 🗓 DÍA 4 — COMPONENTES

### 🎯 Objetivo
Testear lo que el usuario ve, sin acoplarte a cómo está escrito.

---

### 📖 El problema real

Un componente puede fallar de formas que la lógica no: no mostrar un dato, no
responder a un clic, mostrar el estado equivocado.

---

### 📖 El primer test de componente

```tsx
import { render, screen } from "@testing-library/react";
import { TarjetaExpedicion } from "./TarjetaExpedicion";

it("muestra el nombre y el precio formateado", () => {
  render(<TarjetaExpedicion nombre="Torres del Paine" precio={450000} />);

  expect(screen.getByText("Torres del Paine")).toBeInTheDocument();
  expect(screen.getByText("$450.000")).toBeInTheDocument();
});
```

`render` monta el componente en un DOM simulado. `screen` lo consulta.

---

### 📖 La filosofía

> **Busca los elementos como lo haría un usuario, no como lo haría el código.**

```
getByRole("button", { name: /reservar/i })   ✅ preferido
getByLabelText("Correo")                      ✅
getByText("Torres del Paine")                 ✅
getByTestId("boton-reservar")                 ⚠ último recurso
container.querySelector(".btn-primary")       ❌
```

**Por qué importa:** un test que busca por clase CSS falla cuando cambias el
estilo, aunque la aplicación funcione igual. Eso genera tests que se rompen
sin motivo, y tests que se rompen sin motivo acaban ignorados.

Buscar por rol acopla el test a **lo que el usuario percibe**. Y de regalo: un
componente fácil de encontrar por rol suele ser accesible.

---

### 📖 Interacción

```tsx
import userEvent from "@testing-library/user-event";

it("avisa al pulsar Reservar", async () => {
  const alReservar = vi.fn();
  render(<TarjetaExpedicion nombre="X" precio={1} alReservar={alReservar} />);

  await userEvent.click(screen.getByRole("button", { name: /reservar/i }));

  expect(alReservar).toHaveBeenCalledOnce();
});
```

⚠ **`userEvent` es asíncrono.** Sin `await`, el test sigue antes de que el
clic se procese y falla sin razón aparente. Es el error más común.

---

### 📖 Comprobar ausencia

```typescript
expect(screen.queryByText("Error")).not.toBeInTheDocument();
```

⚠ `getBy*` **lanza** si no encuentra. Para comprobar que algo no está, usa
`queryBy*`, que devuelve `null`.

---

### 📖 Qué NO testear de un componente

```
❌ Que Tailwind aplique la clase
❌ Que el componente tenga un div
❌ Nombres de props internas
✅ Que el dato aparezca
✅ Que la acción se dispare
✅ Que el estado correcto se muestre
```

---

### 📖 Mini-ejercicio de comprensión

```tsx
it("muestra el error", () => {
  render(<Formulario error="Sin cupos" />);
  expect(container.querySelector(".text-red-500")).toBeInTheDocument();
});
```

Pasa hoy. ¿Qué lo rompería sin que la aplicación deje de funcionar? Reescríbelo.

---

### 🛠 EJERCICIOS DÍA 4

**Ejercicio 1** — tarjeta de expedición

Tres tests: muestra el nombre, muestra el precio formateado, dispara el
callback al pulsar.

**Ejercicio 2** — los cuatro estados del formulario

Testea el formulario de la Semana 17 en sus cuatro estados: inactivo,
enviando, error, éxito.

El de error debe comprobar además que **conserva lo escrito**.

**Ejercicio 3** — estado vacío

Testea que la lista con cero resultados muestra el mensaje de estado vacío y
**no** una lista vacía silenciosa.

**Ejercicio 4** — busca por rol

Toma cualquier test tuyo que use `getByTestId` o `querySelector` y reescríbelo
con `getByRole`.

Si no puedes, probablemente el componente tiene un problema de accesibilidad.
Documenta cuál.

---

**Cuando termines avísame — valido el Día 4.** ✅

---

## 🗓 DÍA 5 — LOS LÍMITES

### 🎯 Objetivo
Saber qué no cubren estos tests, y qué hacer al respecto.

---

### 📖 Lo que Vitest no puede

```
✅ Funciones puras
✅ Componentes cliente
✅ Server Components síncronos
❌ Server Components ASÍNCRONOS
```

La documentación de Next.js lo declara y recomienda **E2E** para esos casos.

**No es una limitación tuya ni un fallo del setup.** Es el estado de la
herramienta.

---

### 📖 Los cuatro niveles

```
UNITARIO       una función aislada          ← Vitest
COMPONENTE     un componente renderizado    ← Vitest + Testing Library
INTEGRACIÓN    varias piezas juntas         ← Vitest, con cuidado
E2E            un flujo completo, navegador ← Playwright / Cypress
```

**La pirámide:** muchos unitarios (rápidos, baratos, precisos), algunos de
componente, pocos E2E (lentos, caros, pero prueban lo que el usuario hace de
verdad).

Invertirla —muchos E2E, pocos unitarios— produce suites lentas donde nadie
sabe qué falló.

---

### 📖 Mocks: la frontera, no el interior

```typescript
// ✅ Mockear la frontera de red
vi.mock("@/api/clima", () => ({
  obtenerClima: vi.fn(() => Promise.resolve([{ tempMax: 20 }]))
}));

// ❌ Mockear tu propia lógica
vi.mock("@/logica/viabilidad");   // eso es lo que querías probar
```

> **La trampa del mock excesivo:** si mockeas todo lo que la función toca, el
> test comprueba que llamaste a los mocks. Pasa siempre y no atrapa nada.
>
> Es la misma distinción de PS-3: la frontera se controla, el interior se
> prueba.

---

### 📖 Cobertura — la métrica que miente

```bash
npm run coverage
```

Te dice qué porcentaje de líneas ejecutaron tus tests.

**Y no dice nada sobre si esos tests sirven.**

```typescript
it("no falla", () => {
  procesarLote(datosCrudos);   // ejecuta 200 líneas
});                             // sin una sola afirmación
```

Cien por cien de cobertura de esa función. Cero valor.

> **Úsala al revés:** no como objetivo, sino para **encontrar lo que nadie
> probó**. Si un archivo con reglas de negocio tiene 0% de cobertura, ahí hay
> trabajo. Que tenga 90% no significa que esté bien probado.

---

### 📖 Cuándo NO escribir un test

Honestidad, porque el testing también se abusa:

```
✗ Código que va a cambiar la semana que viene
✗ Prototipos que aún no sabes si sobrevivirán
✗ Código sin ramas — un getter, un formateo trivial
✗ Cuando el test sería una copia de la implementación
```

Ese último es sutil:

```typescript
export const IVA = 0.19;
it("el IVA es 19%", () => { expect(IVA).toBe(0.19); });
```

Ese test se rompe cuando cambie el IVA, y no atrapa ningún bug. Es la
implementación escrita dos veces.

---

### 📖 Mini-ejercicio de comprensión

Tu suite tiene 85% de cobertura y todos los tests pasan. Al día siguiente, un
usuario reporta que puede reservar más cupos de los que hay.

¿Cómo es posible? Enumera al menos tres explicaciones.

---

### 🛠 EJERCICIOS DÍA 5

**Ejercicio 1** — mide

Ejecuta `npm run coverage` sobre tu proyecto. Anota los tres archivos con
menos cobertura.

**Ejercicio 2** — decide

De esos tres, decide cuáles merecen tests y cuáles no. Justifica cada
decisión. **Al menos uno debe quedar sin tests**, con su razón escrita.

**Ejercicio 3** — el mock justo

Testea una función que consulte el clima de PS-3. Mockea solo la llamada de
red, no la lógica de conversión ni la de viabilidad.

**Ejercicio 4** — el test que no debería existir

Busca en tu suite un test que no atraparía ningún bug. Bórralo y explica por
qué en el commit.

Borrar tests malos es tan valioso como escribir buenos.

---

**Cuando termines avísame — valido el Día 5.** ✅

---

## 🗓 DÍA 6 — PROYECTO DE LA SEMANA

### 🏆 Nexus Verificado

> No agregas funcionalidad. Construyes la red que avisa cuando algo se rompe.

---

### 📋 Lo que debe hacer

**1. Suite de regresión** — un test por cada bug documentado en tus `NOTAS.md`
de PS-1 a PS-4. Cada uno debe fallar si reintroduces el bug.

**2. Lógica de negocio cubierta** — viabilidad, cupos, IVA, validación,
permisos. Con sus casos borde.

**3. Componentes clave** — tarjeta, formulario en sus cuatro estados, estado
vacío.

**4. Un refactor documentado** — extrae lógica de al menos un Server Component
para poder testearla. Anota qué cambió.

**5. `PLAN_TESTS.md`** — qué testeaste, qué no, y **por qué no**.

Esa última parte importa tanto como la primera. Un plan que solo dice qué se
testeó no demuestra criterio.

---

### 📋 Requisitos técnicos

```
✅ npm test ejecuta toda la suite y pasa
✅ Cada test tiene un nombre que dice qué hace el sistema
✅ Al menos un test por bug histórico documentado
✅ Casos borde cubiertos donde hay umbrales
✅ Componentes buscados por rol, no por clase
✅ await en todo userEvent
✅ Mocks solo en las fronteras
✅ PLAN_TESTS.md con las decisiones de NO testear justificadas
❌ Sin tests sin afirmaciones
❌ Sin tests que dupliquen la implementación
❌ Sin buscar por clase CSS
❌ Sin cobertura como objetivo
```

---

### 📋 Estructura sugerida

```
src/
├── logica/
│   ├── viabilidad.ts
│   └── viabilidad.test.ts       ← junto al código que prueba
├── lib/
│   ├── formatos-cl.ts
│   └── formatos-cl.test.ts
└── componentes/
    ├── TarjetaExpedicion.tsx
    └── TarjetaExpedicion.test.tsx
vitest.config.mts
vitest.setup.ts
PLAN_TESTS.md
```

Los tests junto al código que prueban. Se encuentran solos y se mueven juntos.

---

### 💡 Las dos únicas pistas

**Pista 1** — Si al escribir un test necesitas mockear cuatro cosas, para. La
función hace demasiado. Extrae la parte pura y testea esa.

**Pista 2** — Para los cuatro estados del formulario, `beforeEach` te evita
repetir el `render`. Pero cuidado: el estado no debe filtrarse entre tests.
Testing Library limpia el DOM automáticamente; tus variables no.

---

### ✅ Criterios de aprobación

```
□ npm test pasa en verde
□ Rompes a propósito un cálculo → un test falla, y su nombre dice cuál
□ Cada bug histórico tiene su test de regresión
□ Los umbrales tienen test en el límite exacto
□ Ningún test busca por clase CSS
□ PLAN_TESTS.md justifica al menos tres decisiones de NO testear
□ Al menos un Server Component refactorizado, con la lógica testeada
□ Subido con commit descriptivo
```

**Verificación final — el sabotaje:**

Pide a alguien —o hazlo tú mañana, sin mirar— que introduzca **tres bugs
pequeños** en tu lógica de negocio. Ejecuta la suite.

```
· ¿Cuántos atrapó?
· De los que pasaron, ¿por qué no había test?
· ¿Los nombres de los tests que fallaron te dijeron dónde mirar?
```

Documenta el resultado. **Ese número es la medida real de tu suite**, mucho
más que el porcentaje de cobertura.

---

## 🔜 LO QUE VIENE

```
Despliegue en Vercel
   Único bloque que falta para que exista un portafolio con URL pública.
   Candidato natural para la Semana 19

E2E con Playwright
   Cubre lo que Vitest no puede: Server Components asíncronos y flujos
   completos. Tiene más sentido después de desplegar

Zustand
   Sigue esperando a que el dolor del contexto duela de verdad
```

---

> ### 📘 PRÓXIMA SEMANA
> Pendiente de definir. Candidato recomendado: despliegue.

---

*Semana 18 — Testing con Vitest*
*Formato v4 — Constitución v2.2 · Protocolo QA con Fases 6b y 6c*
*Óscar — Full Stack Developer en formación 🇨🇱*
