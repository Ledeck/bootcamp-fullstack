# 🔬 REPORTE QA — BOOTCAMP SEMANA 18

> Documento interno de auditoría. Contiene el PRODUCTO de cada fase, no su
> declaración (Enmienda 6).

---

```
ACTA DE GENERACIÓN
Fecha: 2026-08-06
Semana en curso de Óscar al generar: 06 (Día 2)
Distancia estimada hasta el uso: ~12 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes consultadas 2026-08-06:
   · nextjs.org/docs/app/guides/testing/vitest (OFICIAL, feb 2026)
   · dev.to/whoffagents — Vitest vs Jest Next.js 2026 (abril 2026)
   · wisp.blog — Vitest vs Jest Next.js (junio 2026)
   · coderfile.io/blog/vitest-vs-jest-2026 (marzo 2026)
   · pristren.com — Vitest unit testing guide (junio 2026)
   · nandann.com — React TS Vite Vitest setup (mayo 2026)
   · novasphereailab.com — Jest vs Vitest (enero 2026)
Referencia: Vitest · React Testing Library · Next.js 16
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

---

## FASE 0 — DELIMITACIÓN

### Por qué testing y por qué ahora

```
1. La Enmienda 14 elevó la VERIFICACIÓN a competencia transversal de
   primer orden en julio de 2026. Trece semanas después seguía sin
   semana propia. Era la deuda conceptual más antigua del sistema.

2. El argumento de secuencia que descartó testing en la Semana 17 ya
   no aplica. Entonces: "hace falta código estable que testear".
   Ahora, tras PS-4, el sistema es estable.

3. Óscar tiene CUATRO proyectos integradores con lógica real y bugs
   documentados. Esta semana no necesita código de ejemplo: usa el suyo.

4. El material posterior (despliegue, E2E) se apoya en tener suite.
```

### La decisión de diseño central

```
Esta semana NO enseña testing sobre código nuevo. Enseña testing sobre
el código que Óscar ya escribió, y sobre los bugs que ya cometió.

Sus cuatro errores de PS-1 (Object.entries sobre array, acc.precioBase
con acumulador 0, > en vez de <=, .length sobre un objeto) se convierten
en los cuatro primeros tests de regresión.

RAZÓN: un test de regresión sobre un bug propio se entiende sin
explicación. Un test sobre código ajeno es un ejercicio de sintaxis.
```

### Dentro del alcance

```
- Qué hace que un test valga la pena (Enmienda 14)
- Qué testear y qué no
- Vitest: describe, it, expect, y las afirmaciones frecuentes
- La estructura AAA y el nombre como documentación
- toBe vs toEqual — comparación por referencia
- Casos borde y valores límite
- Testing Library: render, screen, búsqueda por rol
- userEvent y su asincronía
- Mocks: la frontera, no el interior
- Los cuatro niveles y la pirámide
- Cobertura como diagnóstico, no como objetivo
- Cuándo NO escribir un test
```

### Fuera del alcance

| Excluido | Razón |
|---|---|
| Playwright / Cypress (E2E) | Semana propia. Tiene más sentido tras el despliegue |
| Jest | Se explica por qué no se elige, no se enseña |
| Tests de integración con base real | Requiere infraestructura de test; complejidad desproporcionada |
| Snapshot testing | Útil en casos concretos y muy fácil de abusar. Genera tests que nadie lee y que se actualizan sin pensar |
| Mutation testing | Nicho |
| TDD como metodología | Se enseña el test de regresión (escribir el test del bug primero), que es TDD donde más rinde, sin imponer el ciclo completo |
| Cobertura como objetivo | Se enseña la herramienta y se argumenta explícitamente en contra de la métrica |

### Prerrequisitos

```
Semana 03 → separación lógica/presentación       ✔ CLAVE — ver Fase 6
Semana 09 → TypeScript                            ✔ verificado
Semana 10-11 → React, componentes                 ✔ verificado
Semana 17 → formularios y sus cuatro estados      ✔ verificado
PS-1 a PS-4 → código propio Y BUGS DOCUMENTADOS   ✔ generados
                ⚠ dependencia FUERTE: sin NOTAS.md
                  de los proyectos, el Día 1 no funciona
```

---

## FASE 1 — INVESTIGACIÓN

| Afirmación | Fuente | Impacto |
|---|---|---|
| **Vitest es la elección en 2026.** *"No hay razón para elegir Jest en un proyecto nuevo"* | coderfile (marzo 2026) | Define la herramienta de la semana |
| Vitest superó a Jest en descargas para proyectos nuevos; Jest domina los existentes | coderfile | Justifica enseñar Vitest y mencionar Jest |
| API compatible: `describe`, `it`, `expect`, `beforeEach` idénticos | coderfile, dev.to | Lo aprendido sirve en proyectos con Jest |
| 10-20× más rápido al arrancar | dev.to (abril 2026) | Argumento de adopción |
| ESM nativo; Jest necesita configuración | dev.to | Relevante con Next.js |
| TypeScript sin `ts-jest` ni `babel-jest` | dev.to | Menos setup |
| Next.js usa SWC, no Vite, pero Vitest funciona con `@vitejs/plugin-react` + `jsdom` | pristren (junio 2026) | Setup correcto |
| Config en **`vitest.config.mts`**, con `vite-tsconfig-paths` | nextjs.org (oficial) | Extensión `.mts`, no `.ts` |
| **Vitest NO soporta Server Components asíncronos.** Next.js recomienda E2E para esos | **nextjs.org (oficial)** | **Define el alcance real de la semana** |
| Vitest cubre bien: componentes cliente, funciones utilitarias, lógica de negocio | wisp.blog (junio 2026) | Confirma el enfoque en `logica/` |
| Paquetes: `vitest @vitejs/plugin-react jsdom @testing-library/react @testing-library/jest-dom @testing-library/user-event` | dev.to, nandann | Bloque perecedero |

### El hallazgo que define la semana

```
La limitación de Server Components asíncronos NO es un inconveniente:
es la lección.

Si Vitest no puede testear un Server Component asíncrono, y la lógica
está DENTRO de ese componente, esa lógica no se puede probar.

La solución no es una herramienta mejor. Es separar la lógica.

Y Óscar lleva haciendo eso desde la Semana 3 —logica/ separado de la
presentación— por razones de claridad, sin saber que estaba habilitando
esto.

TESIS DE LA SEMANA:
"Si algo es difícil de testear, casi siempre es un problema de diseño,
no de testing."
```

### Hueco declarado de la Fase 1

```
NO se verificaron los números de versión de Vitest ni de Testing Library.
Se confirmó que Vitest es la elección vigente y su setup, no la versión.

El material NO afirma ningún número. Comprobar con npm view vitest version.
```

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ toBe compara por identidad (===); toEqual por contenido
✔ 0.1 + 0.2 !== 0.3 en coma flotante → toBeCloseTo
✔ expect(fn).toThrow() requiere una FUNCIÓN, no su resultado
✔ getBy* lanza si no encuentra; queryBy* devuelve null
✔ userEvent es asíncrono y requiere await
✔ vi.mock() se eleva antes de los imports
✔ screen consulta el documento entero, no solo lo renderizado
✔ Con globals: true no hace falta importar describe/it/expect
✔ La extensión de config es .mts
✔ Cobertura mide líneas ejecutadas, no calidad de afirmaciones
```

### Corrección aplicada

```
Formulación incorrecta (borrador):
  "Apunta a un 80% de cobertura"

Por qué era incorrecta:
  La cobertura mide qué líneas se ejecutaron, no si hay afirmaciones.
  Un test sin un solo expect() que llame a una función de 200 líneas
  produce 100% de cobertura de esa función y cero valor.

  Fijar un porcentaje como objetivo incentiva exactamente esos tests.
  Y contradice la Enmienda 14: "tests que atrapen algo real, no que
  suban la cobertura".

Formulación corregida:
  La cobertura se usa AL REVÉS — para encontrar qué nadie probó, no
  como meta. Con el ejemplo explícito del test sin afirmaciones.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ El Día 1 usa los bugs reales de Óscar como material
✔ El Día 3 revela la limitación de Server Components y la convierte en
   lección de diseño
✔ El Día 5 da permiso explícito para NO testear, con criterios
✔ El proyecto exige justificar las decisiones de NO testear
✔ Ningún día introduce herramienta antes de mostrar el problema
```

### Anclaje en trabajo previo — el más denso de todas las semanas

```
· Día 1 → los CUATRO bugs de PS-1, citados literalmente
· Día 1 → las anclas numéricas de PS-1 ($261.250, 8 expediciones,
          tarjeta) se reinterpretan como "el primer test que escribiste,
          solo que a mano"
· Día 1 → el caso del 50% EXACTO de PS-1 como ejemplo de caso borde
· Día 2 → toBe vs toEqual conecta con la comparación por referencia que
          Óscar descubrió con sort en PS-1
· Día 2 → calcularDesdeTotal de la Semana 15
· Día 3 → normalizarMonto("$45.000") de PS-2 como test de regresión
· Día 3 → validarReserva de PS-2
· Día 3 → LA SEPARACIÓN logica/ DE LA SEMANA 3 — el anclaje central
· Día 4 → los cuatro estados del formulario de la Semana 17
· Día 5 → "la frontera, no el interior" es la lección de PS-3
· Día 6 → los bugs documentados en NOTAS.md de PS-1 a PS-4
```

**El anclaje del Día 3 es el más valioso:** revela retroactivamente que una
decisión de arquitectura tomada por claridad, trece semanas antes, era la
condición para que esta semana sea posible.

### Ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — inventario PLAN_TESTS | Proyecto D6, requisito |
| D1 — catálogo de bugs | Proyecto D6, requisito |
| D1 — juzgar tres tests | Ninguno. **Justificado:** verificación (E14) |
| D2 — el entorno | Proyecto D6 |
| D2 — formatos-cl.test | Proyecto D6 |
| D2 — los cuatro bugs de PS-1 | Proyecto D6, requisito |
| D2 — la regla del 50% | Proyecto D6 (casos borde) |
| D3 — lógica de PS-2 | Proyecto D6 |
| D3 — refactor para testear | Proyecto D6, requisito |
| D3 — reglas de PS-4 | Proyecto D6 |
| D3 — juzgar suite con mocks | Ninguno. **Justificado:** verificación |
| D4 — tarjeta | Proyecto D6 |
| D4 — cuatro estados | Proyecto D6, requisito |
| D4 — estado vacío | Proyecto D6, requisito |
| D4 — buscar por rol | Proyecto D6, criterio de aprobación |
| D5 — medir cobertura | Proyecto D6 |
| D5 — decidir qué NO testear | Proyecto D6, requisito |
| D5 — el mock justo | Proyecto D6 |
| D5 — borrar un test malo | Ninguno. **Justificado:** criterio |

**Cero huérfanos sin justificar.**

---

## FASE 6b — CONFORMIDAD

Verificación automática:

```
Indentación impar:            0
Sentencias sin punto y coma:  0
Ocurrencias de == o !=:       0
```

```
□✔ Nombres en español: calcularPromedio, contarPersonas, alReservar,
     normalizarMonto, viabilidad
     ⚠ Excepción documentada: la API de Vitest y Testing Library
       (describe, it, expect, render, screen, getByRole) en inglés

□✔ .prettierrc conforme

□✔ Enmienda 14 — LA SEMANA ENTERA es esta enmienda. Además, cuatro
     ejercicios explícitos de juicio: D1 Ej.3, D3 Ej.4, D4
     mini-ejercicio, D5 Ej.4

□✔ Enmienda 17 — Cheat Sheet como guion, entregado por partes

□✔ Enmienda 19 — proyecto sobre el sistema propio, sin usuarios reales
```

---

## FASE 6c — COBERTURA TÉCNICA

| Técnica exigida | Cheat Sheet | Bootcamp | Estado |
|---|---|---|---|
| `describe` / `it` / `expect` | §1, §9 | D2 | ✅ |
| `toBe` vs `toEqual` | §4 | D2 | ✅ |
| `toBeCloseTo` | §4 | D2 (mini-ej.) | ✅ |
| `toThrow` con función | §4 | D2 | ✅ |
| Estructura AAA | §5 | D2 | ✅ |
| `render` / `screen` | §7, §9 | D4 | ✅ |
| `getByRole` y jerarquía | §7 | D4 | ✅ |
| `queryBy` para ausencia | §7 | D4 | ✅ |
| `userEvent` + await | §7, §9 | D4 | ✅ |
| `vi.fn()` / `vi.mock()` | §8, §9 | D3, D5 | ✅ |
| `beforeEach` | §9 (implícito) | D6 pista 2 | ✅ |
| `coverage` | §9 mención | D5 | ✅ |

**Cero huecos.** Todas las técnicas exigidas por ejercicios o por el proyecto
aparecen en ambos documentos.

Es la primera semana que pasa la Fase 6c sin correcciones. Las dos anteriores
(16 y 17) requirieron parches.

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS

```
RECHAZADA 1: "Escribe tests para todo tu código"

Razón: produce suites enormes, lentas y llenas de tests que nadie lee.
Contradice la Enmienda 14 directamente.

Reemplazo: el Día 1 establece el criterio "¿qué bug atraparía esto?", y
el Día 5 da permiso EXPLÍCITO para no testear, con cuatro casos
concretos. El proyecto EXIGE justificar tres decisiones de no testear.
```

```
RECHAZADA 2: "Apunta a un 80% de cobertura"

Razón: ver Fase 4.

Reemplazo: cobertura como diagnóstico, nunca como objetivo.
```

```
RECHAZADA 3: "Mockea las dependencias para aislar la unidad"

Razón: técnicamente cierto y desastroso como consejo general. Lleva al
mock excesivo, donde el test comprueba que llamaste a los mocks.

Reemplazo: "la frontera, no el interior", con el Ejercicio 4 del Día 3
que muestra una suite mockeada que pasa sin probar nada.
```

```
RECHAZADA 4: "Usa data-testid para encontrar elementos"

Razón: funciona y acopla el test a la implementación. Además pierde el
beneficio secundario de getByRole: un componente difícil de encontrar
por rol suele tener un problema de accesibilidad.

Reemplazo: jerarquía explícita de selectores, testid como último
recurso, y el Ejercicio 4 del Día 4 que obliga a migrar uno — con la
nota de que si no se puede, hay un problema de accesibilidad que
documentar.
```

```
RECHAZADA 5: "Vitest testea toda tu aplicación Next.js"

Razón: FALSO. La documentación oficial dice que no soporta Server
Components asíncronos.

Reemplazo: la limitación se declara, se explica, y se convierte en la
tesis de la semana sobre diseño.
```

### Ataques sin hallazgo

```
✔ ¿Se enseña Jest por inercia? No — se explica por qué no se elige
✔ ¿Algún día da la herramienta antes del problema? El D1 no menciona
  Vitest; el D3 revela la limitación al intentar usarla
✔ ¿El proyecto es verificable objetivamente? Sí, y de forma novedosa:
  el sabotaje de tres bugs mide la suite mejor que la cobertura
✔ ¿Hay secciones "cuándo NO"? El Día 5 entero
```

---

## ENMIENDA 10 — SINTAXIS NUEVA POR PESO

| Sintaxis | Peso | Entrega |
|---|---|---|
| `vi.fn()` / `vi.mock()` | **MEDIA** | Cuerpo del D3 y D5 + trampa (elevación) |
| `render` / `screen` | **MEDIA** | Cuerpo del D4 + trampa (documento entero) |
| `describe`/`it`/`expect` | **LIGERA** | D2 + trampa (globals) |
| `userEvent.click` | **LIGERA** | D4 + trampa (await) |

```
✔ Ninguna PESADA de contrabando
✔ Las dos MEDIA en el cuerpo, no en ejercicios
✔ Ninguna en el Día 1 — deliberado: el D1 no toca herramientas
```

---

## HALLAZGOS ABIERTOS

### 1. Versiones sin verificar

Declarado en la Fase 1. El material no afirma números.

### 2. La limitación de Server Components puede desaparecer

En doce meses, Vitest puede soportar Server Components asíncronos — la
documentación de Next.js lo describe como algo que *"está madurando"*.

**Si eso ocurre**, la sección de límites del Día 5 queda obsoleta. **La tesis
sobre diseño NO** — separar la lógica sigue siendo mejor arquitectura aunque
la herramienta mejore.

Verificar al usar.

### 3. Dependencia fuerte de los NOTAS.md de los proyectos

El Día 1 y el proyecto exigen los bugs documentados en PS-1 a PS-4. Si Óscar
no los documentó, esa parte se vacía.

**Mitigación:** los cuatro bugs de PS-1 están citados literalmente en el
material, así que hay al menos ese material garantizado.

### 4. E2E sigue sin semana

Vitest no cubre Server Components asíncronos ni flujos completos. Falta
Playwright.

**Recomendación:** después del despliegue, no antes. Testear flujos completos
tiene más sentido cuando hay algo desplegado que recorrer.

---

## ADVERTENCIA SOBRE LA VIGENCIA

```
CRÍTICO → versiones de Vitest y Testing Library
CRÍTICO → soporte de Server Components asíncronos (puede cambiar)
ALTO    → el formato de vitest.config.mts y los plugins
MEDIO   → la comparación Vitest/Jest (puede aparecer otra herramienta)
BAJO    → qué testear y qué no
BAJO    → la relación entre testabilidad y diseño
BAJO    → la pirámide de tests
BAJO    → cobertura como métrica engañosa
```

**Nota de precedencia:** si la documentación de Next.js o de Vitest contradice
este material, gana la documentación.

---

*Reporte QA Semana 18 — 2026-08-06*
*Constitución v2.2 · Fases 0-8 incluyendo 6b y 6c*
*Primera semana que pasa la Fase 6c sin correcciones*
