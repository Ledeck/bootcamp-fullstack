# 📄 CHEAT SHEET — SEMANA 18
## Testing · Vitest · Testing Library

> Guion de la clase de activación. Se entrega POR PARTES, día a día.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado y verificado: agosto 2026
Referencia: Vitest · React Testing Library · Next.js 16
REGENERAR antes de empezar la semana.
```

```bash
npm install -D vitest @vitejs/plugin-react jsdom \
  @testing-library/react @testing-library/jest-dom @testing-library/user-event \
  vite-tsconfig-paths
```

```typescript
// vitest.config.mts
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";
import tsconfigPaths from "vite-tsconfig-paths";

export default defineConfig({
  plugins: [tsconfigPaths(), react()],
  test: {
    environment: "jsdom",
    globals: true,
    setupFiles: "./vitest.setup.ts"
  }
});
```

```typescript
// vitest.setup.ts
import "@testing-library/jest-dom/vitest";
```

```json
{
  "scripts": {
    "test": "vitest",
    "test:run": "vitest run",
    "coverage": "vitest run --coverage"
  }
}
```

⚠ La extensión es **`.mts`**, no `.ts`. Es un módulo ES explícito.

### Por qué Vitest y no Jest

```
· API compatible: describe, it, expect, beforeEach — idénticos
· 10-20× más rápido al arrancar
· ESM nativo; Jest necesita configuración extra
· TypeScript sin ts-jest ni babel-jest
· En 2026 superó a Jest en descargas para proyectos nuevos
```

Jest sigue siendo válido en proyectos que ya lo usan. Para uno nuevo, no hay
razón para elegirlo.

**Qué verificar al llegar:** versiones, y si Vitest ya soporta Server
Components asíncronos (ver sección 6).

---

## 1. QUÉ ES UN TEST

Código que ejecuta tu código y comprueba que hace lo que dices.

```typescript
import { describe, it, expect } from "vitest";
import { formatearPrecio } from "@/lib/formatos-cl";

describe("formatearPrecio", () => {
  it("formatea con separador de miles chileno", () => {
    expect(formatearPrecio(450000)).toBe("$450.000");
  });
});
```

```
describe   agrupa tests relacionados
it         un caso concreto
expect     la afirmación
```

**Idea mental:** un test es una pregunta con respuesta conocida. Si la
respuesta cambia sin que tú lo decidas, algo se rompió.

---

## 2. LA REGLA QUE DEFINE LA SEMANA

> **Un test debe atrapar algo real.**
> No subir un porcentaje.

La Enmienda 14 lo dice así: *"escribir tests que atrapen algo real, no que
suban la cobertura"*.

Un test inútil típico:

```typescript
it("suma dos números", () => {
  expect(2 + 2).toBe(4);
});
```

Ese test comprueba que JavaScript funciona. Nunca va a fallar, nunca va a
avisarte de nada, y suma a la cobertura.

**El criterio:** antes de escribir un test, pregúntate *"¿qué bug atraparía
esto?"*. Si no hay respuesta, no lo escribas.

---

## 3. QUÉ TESTEAR Y QUÉ NO

```
✅ SÍ
   Lógica de negocio con reglas
   Transformación de datos
   Casos borde y valores límite
   Bugs que ya ocurrieron una vez
   Funciones puras

❌ NO
   Que la librería funcione (Prisma, Zod, React)
   Detalles de implementación (nombres de variables internas)
   Estilos y maquetación
   Código sin ramas ni decisiones
```

**El caso más rentable de todos:** cuando encuentres un bug, escribe primero
el test que lo reproduce. Luego arréglalo. Ese test impide que vuelva.

Se llama **test de regresión**, y es el que más valor tiene por línea.

---

## 4. AFIRMACIONES DE USO FRECUENTE

```typescript
expect(valor).toBe(5);                    // identidad — primitivos
expect(objeto).toEqual({ a: 1 });         // contenido — objetos y arrays
expect(array).toHaveLength(3);
expect(array).toContain("EXP001");
expect(valor).toBeNull();
expect(valor).toBeUndefined();
expect(valor).toBeTruthy();
expect(numero).toBeGreaterThan(0);
expect(numero).toBeCloseTo(0.3);          // decimales
expect(fn).toThrow("Sin cupos");
expect(promesa).resolves.toBe(5);
expect(promesa).rejects.toThrow();
```

> ⚠ **`toBe` vs `toEqual`.** `toBe` compara por identidad, como `===`. Con
> objetos falla aunque el contenido sea idéntico, porque son referencias
> distintas.
>
> ```typescript
> expect({ a: 1 }).toBe({ a: 1 });      // ❌ falla
> expect({ a: 1 }).toEqual({ a: 1 });   // ✅ pasa
> ```
>
> Es la comparación por referencia que descubriste con `sort` en PS-1.

> ⚠ **`toBeCloseTo` para decimales.** `0.1 + 0.2` no da exactamente `0.3` en
> coma flotante. `toBe` falla; `toBeCloseTo` no.

---

## 5. ESTRUCTURA DE UN TEST — AAA

```typescript
it("rechaza reserva que excede el cupo", () => {
  // Arrange — preparar
  const expedicion = { cupoMaximo: 6 };
  const ocupados = 4;

  // Act — ejecutar
  const resultado = puedeReservar(expedicion, ocupados, 3);

  // Assert — comprobar
  expect(resultado.permitido).toBe(false);
  expect(resultado.motivo).toBe("Solo quedan 2 cupos");
});
```

**El nombre del test es documentación.** Debe decir qué hace el sistema, no
qué función se llama.

```
❌ it("prueba puedeReservar")
❌ it("test 1")
✅ it("rechaza reserva que excede el cupo")
✅ it("acepta reserva que ocupa exactamente los cupos restantes")
```

Cuando un test falla, su nombre es lo primero que lees.

---

## 6. LOS LÍMITES — LO QUE VITEST NO PUEDE

Honestidad sobre el alcance, y es importante para tu proyecto:

```
✅ Funciones puras y lógica de negocio
✅ Componentes cliente
✅ Server Components SÍNCRONOS
❌ Server Components ASÍNCRONOS
```

La documentación de Next.js lo dice: **Vitest no soporta Server Components
asíncronos**, y recomienda pruebas E2E para esos.

**Qué significa para ti:** tu aplicación tiene mucho Server Component
asíncrono. Esos no se testean con Vitest.

**Y la buena noticia:** la lógica que hay dentro sí, **si está separada**.

```typescript
// ❌ No testeable — todo mezclado
export default async function Pagina() {
  const reservas = await prisma.reserva.findMany();
  const total = reservas.reduce((a, r) => a + r.personas, 0);
  return <div>{total}</div>;
}

// ✅ La lógica sale, y se testea sola
// logica/reservas.ts
export function contarPersonas(reservas: Reserva[]): number {
  return reservas.reduce((a, r) => a + r.personas, 0);
}
```

> **La conclusión de la semana:** si algo es difícil de testear, casi siempre
> es un problema de **diseño**, no de testing.
>
> Y tú llevas separando `logica/` de la presentación desde la Semana 3. Esa
> arquitectura no la elegiste pensando en tests — pero es exactamente lo que
> los hace posibles.

---

## 7. COMPONENTES — TESTING LIBRARY

```tsx
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { TarjetaExpedicion } from "./TarjetaExpedicion";

it("muestra el nombre y el precio formateado", () => {
  render(<TarjetaExpedicion nombre="Torres del Paine" precio={450000} />);

  expect(screen.getByText("Torres del Paine")).toBeInTheDocument();
  expect(screen.getByText("$450.000")).toBeInTheDocument();
});

it("avisa al pulsar Reservar", async () => {
  const alReservar = vi.fn();
  render(<TarjetaExpedicion nombre="X" precio={1} alReservar={alReservar} />);

  await userEvent.click(screen.getByRole("button", { name: /reservar/i }));

  expect(alReservar).toHaveBeenCalledOnce();
});
```

### La filosofía de Testing Library

> **Busca los elementos como lo haría un usuario, no como lo haría el código.**

```
getByRole("button", { name: /reservar/i })    ✅ preferido
getByLabelText("Correo")                       ✅
getByText("Torres del Paine")                  ✅
getByTestId("boton-reservar")                  ⚠ último recurso
container.querySelector(".btn-primary")        ❌ implementación
```

Buscar por clase CSS acopla el test al estilo: cambias una clase y el test
falla aunque la aplicación funcione igual.

Buscar por rol acopla el test a **lo que el usuario percibe**. Y de paso, un
componente fácil de encontrar por rol suele ser un componente accesible.

> ⚠ **Trampa:** `getBy*` lanza error si no encuentra. `queryBy*` devuelve
> `null`. Para comprobar que algo **no** está, usa `queryBy`:
>
> ```typescript
> expect(screen.queryByText("Error")).not.toBeInTheDocument();
> ```

> ⚠ **Trampa:** `userEvent` es asíncrono. Sin `await`, el test sigue antes de
> que el clic se procese.

---

## 8. MOCKS — Y CUÁNDO NO USARLOS

```typescript
import { vi } from "vitest";

const fn = vi.fn();
fn("hola");
expect(fn).toHaveBeenCalledWith("hola");

// Reemplazar un módulo entero
vi.mock("@/lib/prisma", () => ({
  default: { reserva: { findMany: vi.fn(() => []) } }
}));
```

**Cuándo mockear:**

```
✅ Llamadas de red
✅ Base de datos
✅ Fecha y hora (vi.useFakeTimers)
✅ Aleatoriedad
```

**Cuándo NO:**

```
❌ Tu propia lógica de negocio — eso es lo que quieres probar
❌ Tantas cosas que el test ya no prueba nada real
```

> ⚠ **La trampa del mock excesivo.** Si mockeas todo lo que la función toca,
> el test comprueba que llamaste a los mocks — no que el código funcione.
> Pasa siempre y no atrapa nada.
>
> **Regla:** mockea la frontera, nunca el interior. Es la misma distinción
> de PS-3.

---

## 9. SINTAXIS NUEVA DE ESTA SEMANA

### `describe` / `it` / `expect` · peso LIGERO

> ⚠ Con `globals: true` no hace falta importarlos. Sin esa opción, sí. Los
> ejemplos que veas por internet asumen cosas distintas.

### `vi.fn()` y `vi.mock()` · peso MEDIO

> ⚠ **Trampa:** `vi.mock()` se eleva al principio del archivo, antes de los
> imports. No puede usar variables declaradas después.

### `render` y `screen` · peso MEDIO

> ⚠ **Trampa:** `screen` consulta el documento entero, no solo lo que
> renderizaste. Con dos `render` en el mismo test, `getByText` puede
> encontrar dos coincidencias y fallar.

### `await userEvent.click()` · peso LIGERO

> ⚠ **Trampa:** siempre `await`. Es el error más común con Testing Library.

---

## 10. TABLA DE DECISIÓN

| Quieres probar | Herramienta |
|---|---|
| Una función pura | Vitest, sin nada más |
| Una regla de negocio | Vitest sobre `logica/` |
| Un componente cliente | Vitest + Testing Library |
| Un Server Component síncrono | Vitest + Testing Library |
| Un Server Component asíncrono | **E2E** — Vitest no puede |
| Un flujo completo de usuario | **E2E** — Playwright o Cypress |
| Que un bug no vuelva | Test de regresión |

---

## 11. FUERA DE ALCANCE

```
Playwright / Cypress      E2E — semana propia
Tests de integración con base de datos real
Snapshot testing          útil en casos concretos, fácil de abusar
Cobertura como objetivo   se menciona la herramienta, no la métrica
Mutation testing
```

---

*Cheat Sheet Semana 18 — Testing con Vitest*
*Prerrequisitos: Semana 03 (separación lógica/presentación) · 09 (TypeScript) · 10-11 (React) · 17 (Zod) · PS-1 a PS-4*
