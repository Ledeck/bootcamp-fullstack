# 📘 BOOTCAMP SEMANA 19
## Despliegue · Vercel · Producción

---

```
ACTA DE GENERACIÓN
Fecha de generación: 2026-08-06
Semana en curso de Óscar al generar: 06 (Día 2)
Distancia estimada hasta el uso: ~13 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes consultadas 2026-08-06:
   · vercel.com/kb/guide/nextjs-prisma-postgres (oficial, mayo 2026)
   · prisma.io/docs — Deploy to Vercel (oficial)
   · prisma.io/docs/guides/frameworks/nextjs (oficial)
   · dev.to/whoffagents — production checklist (abril 2026)
   · tczhong.com — Prisma on Vercel deploy learning notes (feb 2026)
   · tekraze.com — Deploy Next.js to Vercel (3 semanas)
   · eastondev.com — env vars, domains, monitoring
Referencia: Vercel · Next.js 16 · Prisma 7
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

---

> **Flujo de la semana:** el Cheat Sheet se entrega por partes, día a día.

---

## ⚠️ NOTA DE ALCANCE

Esta semana **cierra el roadmap generado**. Y cierra algo más concreto: la
Enmienda 19 fijó los proyectos de portafolio a partir de la Semana 12, y un
portafolio sin URL pública no es portafolio.

Nadie va a clonar tu repositorio para comprobar si funciona.

**Lo que NO es esta semana:** un tutorial de "conecta el repo y pulsa
Deploy". Eso son cinco minutos.

**Lo que sí es:** entender por qué algo funciona en tu máquina y no en
producción. Porque va a pasarte, y el mensaje de error no siempre dice dónde
mirar.

**Prerrequisito real:** Semanas 12, 14 y 16. Una aplicación con framework,
base de datos y autenticación es lo que hace que el despliegue tenga
problemas interesantes.

---

## 🗓 DÍA 1 — "FUNCIONA EN MI MÁQUINA"

### 🎯 Objetivo
Entender qué tiene tu máquina que el servidor no, y desplegar una vez.

---

### 📖 El problema real

Tu aplicación lleva ocho semanas funcionando. Corre en `localhost:3000`, se
conecta a una base de datos, tiene usuarios con sesión y formularios que
validan.

Y **nadie más puede verla**.

---

### 📖 ¿Cómo lo resolverías con lo que ya sabes?

El instinto es que desplegar es copiar tu carpeta a un servidor.

---

### 📖 Por qué eso no es lo que pasa

Vercel no copia tu carpeta. **Clona tu repositorio y reconstruye el proyecto
desde cero** en una máquina limpia.

Lo que tu máquina tiene y esa no:

```
· Tu versión de Node
· Un .env con secretos que nunca subiste
· Una base de datos a la que solo tú llegas
· node_modules con todo instalado, incluido lo de desarrollo
· Archivos que quizá están en .gitignore
· Restos de instalaciones anteriores que ya no recuerdas
```

**Cuando algo falle desplegado y funcione en local, la diferencia está en esa
lista.** Siempre.

> **Idea mental:** desplegar no es mover tu proyecto. Es demostrar que se
> puede reconstruir sin ti.

---

### 📖 El primer despliegue

```
1. Repositorio en GitHub, actualizado
2. vercel.com → Add New → Project → importar el repo
3. Vercel detecta Next.js solo
4. Deploy
```

**Va a fallar.** Casi seguro. Y eso es el material del Día 4.

Si por casualidad funciona, es porque tu aplicación todavía no depende de
nada externo. En cuanto entre la base de datos, fallará.

---

### 📖 Los tres entornos

```
DEVELOPMENT   tu máquina, .env.local
PREVIEW       cada rama y cada PR → URL propia
PRODUCTION    la rama principal → tu dominio
```

**Cada uno con sus propias variables.** Es la causa número uno de "funciona
en preview y falla en producción".

Y aquí conecta con la Semana 7: cada Pull Request genera una URL desplegada.
El flujo de ramas que aprendiste ahí pasa a tener consecuencia visible.

---

### 📖 Mini-ejercicio de comprensión

Tu `.env.local` tiene `DATABASE_URL` y funciona en local. Despliegas y el
build pasa, pero la web muestra un error 500 al cargar.

¿Qué pasó, y por qué el build no falló?

---

### 🛠 EJERCICIOS DÍA 1

**Ejercicio 1** — el inventario

Antes de desplegar, lista en `DESPLIEGUE.md` todo lo que tu aplicación
necesita para funcionar y **no está en el repositorio**.

**Ejercicio 2** — despliega

Conecta el repositorio y despliega. Documenta qué pasó: si falló, copia el
error completo. No lo arregles todavía.

**Ejercicio 3** — la prueba del clon limpio

En otra carpeta:

```bash
git clone <tu-repo> prueba-limpia
cd prueba-limpia
npm install
npm run build
```

Sin copiar el `.env`. ¿Funciona?

Eso es exactamente lo que hace Vercel. Documenta el resultado.

---

**Cuando termines avísame — valido el Día 1.** ✅

---

## 🗓 DÍA 2 — VARIABLES DE ENTORNO

### 🎯 Objetivo
Que la aplicación tenga lo que necesita, sin filtrar nada.

---

### 📖 El problema real

Tu `.env.local` tiene la cadena de la base, la clave de Clerk y quizá más
cosas. Ese archivo **no está en Git**, y con razón.

Entonces, ¿cómo llegan al servidor?

---

### 📖 Las variables en Vercel

```
Settings → Environment Variables
```

Para cada una eliges en qué entornos existe: Development, Preview,
Production, o los tres.

⚠ **Una variable definida solo en Production no existe en Preview.** Tu PR
falla mientras `main` funciona, y el error no dice que falte una variable.

---

### 📖 La regla del prefijo

```
NEXT_PUBLIC_*     va al navegador. Cualquiera puede leerla
sin prefijo       solo en el servidor
```

```
✅ NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY   diseñada para ser pública
❌ NEXT_PUBLIC_CLERK_SECRET_KEY        filtración
❌ NEXT_PUBLIC_DATABASE_URL            filtración grave
```

**Cómo comprobarlo:** despliega, abre la web, herramientas de desarrollo →
Sources, y busca en el bundle. Si tu secreto aparece, está expuesto para
siempre — hay que rotarlo, no basta con quitarlo.

---

### 📖 `.env.example` — el archivo que sí se sube

```
DATABASE_URL=
DIRECT_URL=
CLERK_SECRET_KEY=
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=
```

Nombres sin valores. Es lo primero que mira alguien que clona tu repositorio,
y es parte de lo que hace un proyecto presentable.

---

### 📖 Traerlas de vuelta

```bash
vercel env pull
```

Escribe un `.env.local` con las variables del entorno seleccionado. Sirve
para reproducir en tu máquina un problema que solo ocurre desplegado.

⚠ Por defecto trae las de Development. Para las de producción hay que
pedirlas explícitamente.

---

### 📖 Mini-ejercicio de comprensión

Un compañero pone `NEXT_PUBLIC_` a la clave secreta de Clerk "porque si no,
el componente no la encontraba".

Explica qué acaba de pasar y qué hay que hacer ahora — no basta con quitar el
prefijo.

---

### 🛠 EJERCICIOS DÍA 2

**Ejercicio 1** — todas las variables

Define en Vercel todas las que tu aplicación necesita, en los tres entornos.

**Ejercicio 2** — `.env.example`

Créalo y súbelo. Verifica que un clon limpio permite saber qué hace falta.

**Ejercicio 3** — la auditoría del bundle

Despliega, abre la web y busca en el código del navegador tus secretos. Ni
uno debe aparecer.

Documenta cómo lo comprobaste.

**Ejercicio 4** — rompe a propósito

Borra una variable de Preview, deja la de Production, y abre un PR.

Compara los dos despliegues. Documenta el mensaje de error y si te habría
llevado a la causa.

---

**Cuando termines avísame — valido el Día 2.** ✅

---

## 🗓 DÍA 3 — LA BASE DE DATOS EN PRODUCCIÓN

### 🎯 Objetivo
Que los datos vivan en un sitio al que Vercel llegue, con las migraciones
aplicadas.

---

### 📖 El problema real

**Vercel no aloja bases de datos.** Si la tuya corre en Docker en tu portátil,
el servidor no puede alcanzarla.

Si en la Semana 14 elegiste una base alojada, esta parte ya está resuelta. Si
elegiste local, aquí toca migrar.

---

### 📖 Las dos URLs

Varios proveedores entregan **dos** cadenas de conexión:

```prisma
datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")   // con pool → la aplicación
  directUrl = env("DIRECT_URL")     // sin pool → las migraciones
}
```

**Por qué dos:** una migración necesita una conexión estable y exclusiva; un
pool no sirve. La aplicación necesita lo contrario — muchas conexiones cortas.

⚠ Si defines `directUrl` y olvidas la variable en Vercel, el build falla con
un mensaje que **no menciona** `directUrl`.

---

### 📖 El pool y las funciones serverless

> Cada invocación de una función serverless **puede abrir una conexión
> nueva**. Con tráfico, la base agota las conexiones disponibles y la
> aplicación se cuelga.

Es el problema del singleton de la Semana 14, ahora a escala real. Allí eran
veinte recargas en caliente; aquí son usuarios de verdad.

El singleton ayuda dentro de una instancia. El pool del proveedor resuelve lo
demás. **Hacen falta los dos.**

---

### 📖 Las migraciones no se aplican solas

Este es el error que más sorprende: el build pasa, la aplicación carga, y al
consultar datos revienta porque **las tablas no existen**.

```json
{
  "scripts": {
    "vercel-build": "prisma generate && prisma migrate deploy && next build"
  }
}
```

```
prisma generate        crea el cliente. Siempre necesario en CI
prisma migrate deploy  aplica las pendientes. NO crea ninguna
next build             compila
```

⚠ **`migrate deploy`, no `migrate dev`.** El segundo puede crear migraciones y
pedir confirmación. En un servidor de build no hay nadie para responder.

---

### 📖 La base de Preview

⚠ **Vercel usa la misma `DATABASE_URL` para Preview y Production si no la
separas.**

Eso significa que **tus ramas de prueba escriben en la base de producción**.
Un PR con datos de prueba los deja en la base real.

**Solución:** una segunda base para Preview, con su variable marcada solo para
ese entorno.

---

### 📖 Mini-ejercicio de comprensión

Despliegas, el build pasa en verde, la portada carga bien. Entras a
`/reservas` y sale error 500.

En los logs: `The table 'public.Reserva' does not exist`.

¿Qué falta, y por qué el build no lo detectó?

---

### 🛠 EJERCICIOS DÍA 3

**Ejercicio 1** — base en producción

Crea una base alojada, obtén las dos URLs, y defínelas en Vercel.

**Ejercicio 2** — el script de build

Configura `vercel-build` con las tres partes. Despliega y verifica en el log
que las migraciones se aplicaron.

**Ejercicio 3** — base separada para Preview

Crea la segunda base y configura su variable solo para Preview.

Comprueba: crea una reserva desde un despliegue de preview y verifica que
**no** aparece en producción.

**Ejercicio 4** — la semilla en producción

Tu base de producción está vacía. Decide qué hacer: ¿ejecutas la semilla?
¿Cargas datos a mano? ¿La dejas vacía?

Justifica en `DESPLIEGUE.md`. No hay respuesta única — se evalúa el criterio.

---

**Cuando termines avísame — valido el Día 3.** ✅

---

## 🗓 DÍA 4 — CUANDO EL BUILD FALLA

### 🎯 Objetivo
Leer un log de build y llegar a la causa.

---

### 📖 El problema real

El build falla en Vercel. En local pasa sin problema. El log tiene doscientas
líneas y el error real está en una.

---

### 📖 Las cinco causas, por frecuencia

**1. El cliente de Prisma no se generó**

```
Error: @prisma/client did not initialize yet. Please run "prisma generate"
```

Vercel cachea `node_modules`. Si el cliente vive ahí y no se regenera, se usa
uno viejo o ninguno.

**2. La ruta generada no coincide con los imports**

Este merece atención, porque es el que más cuesta encontrar.

```prisma
generator client {
  output = "../src/generated/prisma"
}
```

```typescript
// ❌ importa de donde ya NO está
import { PrismaClient } from "@prisma/client";

// ✅
import { PrismaClient } from "@/generated/prisma/client";
```

**En local puede funcionar** por restos de instalaciones anteriores. En un
entorno limpio, no.

Hay un caso documentado de despliegues fallando repetidamente por esto, y la
conclusión del autor es la tesis de la semana:

> Los problemas no venían de un ajuste mágico de Vercel. Venían de **pequeñas
> inconsistencias** entre dónde se genera el código, desde dónde se importa, y
> qué supone el entorno de CI.

**3. Faltan variables de entorno**

El build pasa y la aplicación revienta al cargar.

**4. Errores de TypeScript**

`next build` comprueba tipos. Si desarrollabas ignorando el subrayado rojo,
aquí se detiene.

Es el Día 7 de la Semana 9: el editor avisa, no impide. `npx tsc --noEmit`
antes de desplegar te lo dice primero, y en tu máquina.

**5. Dependencias en el sitio equivocado**

Algo que el build necesita, declarado en `devDependencies`, con una
instalación de producción que las omite.

---

### 📖 Cómo leer un log

```
1. Ve al FINAL. El error real suele estar en las últimas líneas
2. Busca la primera línea que diga "Error" o "Failed"
3. Ignora el ruido: warnings de dependencias, avisos de versión
4. Si menciona un archivo, ábrelo
5. Si menciona un módulo que no encuentra, pregunta:
   ¿existe? ¿está en el sitio que dice el import?
```

> **Esto es competencia de verificación pura, Enmienda 14.** No estás
> escribiendo código: estás leyendo la salida de un sistema que no controlas y
> deduciendo qué pasó.

---

### 📖 Reproducir en local

El truco que ahorra despliegues:

```bash
rm -rf node_modules .next
npm ci
npm run build
```

`npm ci` instala exactamente lo del `package-lock.json`, desde cero. Es lo más
parecido a lo que hace Vercel.

Si falla aquí, fallará allá — y depurar en tu máquina es mucho más rápido.

---

### 📖 Mini-ejercicio de comprensión

```
Error: Cannot find module '@/generated/prisma/client'
```

Tres causas posibles. Enuméralas y di cómo distinguirías cuál es.

---

### 🛠 EJERCICIOS DÍA 4

**Ejercicio 1** — la reproducción local

Ejecuta la secuencia de limpieza y build. Documenta si falló y por qué.

**Ejercicio 2** — provoca cada fallo

Uno por uno, provoca al menos tres de las cinco causas. Despliega, copia el
mensaje, arréglalo.

Al terminar tendrás un catálogo de errores con su solución. Ese documento vale
más que el despliegue.

**Ejercicio 3** — el diagnóstico a ciegas

Guarda un log de un build fallido. Al día siguiente, sin mirar tus notas,
léelo e intenta llegar a la causa solo con el log.

¿Bastó? Si no, ¿qué información faltaba?

**Ejercicio 4** — juzga este script

```json
{
  "scripts": {
    "build": "next build",
    "postinstall": "prisma generate"
  }
}
```

Es una configuración común. ¿Qué problema tiene con las migraciones? ¿En qué
casos funcionaría igual?

---

**Cuando termines avísame — valido el Día 4.** ✅

---

## 🗓 DÍA 5 — DESPUÉS DEL DESPLIEGUE

### 🎯 Objetivo
Operar algo que está vivo.

---

### 📖 El problema real

Está desplegado. Un usuario dice que le sale error. Tú no ves nada raro.

---

### 📖 Los logs

```
Deployment → Building     el log del build
Deployment → Functions    errores en tiempo de ejecución
```

Un error 500 no muestra detalles al usuario — están en los logs.

⚠ **Nunca devuelvas el error crudo al usuario.** Puede contener estructura de
tu base de datos. Es la regla de la Semana 14 con `P2003`, ahora con
consecuencia pública.

---

### 📖 Los despliegues de preview

Cada Pull Request genera una URL propia. Ahí es donde el flujo de la Semana 7
rinde de verdad: abres un PR, revisas el cambio **funcionando**, y luego
fusionas.

Y si algo sale mal en producción, Vercel permite volver a un despliegue
anterior desde el panel. Es más rápido que arreglar en caliente.

---

### 📖 Dominios

`tu-proyecto.vercel.app` viene gratis. Para uno propio: Settings → Domains y
ajustar el DNS.

⚠ **Si usas Clerk, la URL de callback debe coincidir con el dominio de
producción.** Cambiar de dominio y olvidar esto rompe el login solo en
producción, y el error no menciona el dominio.

---

### 📖 La lista antes de cada despliegue

```
□ npm run build pasa en local
□ npx tsc --noEmit sin errores
□ npm test en verde
□ .env.local NO está en Git
□ .env.example actualizado
□ Variables definidas en los tres entornos
□ Ninguna clave secreta con NEXT_PUBLIC_
□ El build incluye prisma generate y migrate deploy
□ Los imports coinciden con el output configurado
□ Las URLs de callback coinciden con el dominio
```

**Diez comprobaciones, dos minutos.** Después de la tercera vez que un
despliegue falla por olvidar una, la lista deja de parecer burocracia.

---

### 📖 Mini-ejercicio de comprensión

Todo funciona en producción. Añades un dominio propio y el login deja de
funcionar — pero solo en producción; en preview sigue bien.

¿Qué pasó?

---

### 🛠 EJERCICIOS DÍA 5

**Ejercicio 1** — provoca y encuentra

Provoca un error 500 en producción a propósito. Encuéntralo en los logs.
Documenta cuánto tardaste y qué te llevó a él.

**Ejercicio 2** — el flujo con preview

Abre un PR con un cambio visible. Revisa la URL de preview, comprueba el
cambio, fusiona.

Es la Semana 7 con consecuencia real.

**Ejercicio 3** — la vuelta atrás

Despliega algo roto a propósito. Vuelve al despliegue anterior desde el panel.
Documenta cuánto tardó.

**Ejercicio 4** — la lista, en tu README

Adáptala a tu proyecto concreto. Si algo de la lista genérica no aplica,
quítalo y di por qué.

---

**Cuando termines avísame — valido el Día 5.** ✅

---

## 🗓 DÍA 6 — PROYECTO DE LA SEMANA

### 🏆 Nexus en Producción

> Todo lo que construiste desde la Semana 12 vive en tu máquina. Hoy sale.

---

### 📋 Lo que debe hacer

**1. Desplegado y funcionando** — URL pública, con base de datos en
producción, autenticación operativa y las migraciones aplicadas.

**2. Los tres entornos** configurados, con base separada para Preview.

**3. Cero secretos expuestos** — verificado inspeccionando el bundle.

**4. `DESPLIEGUE.md`** con:

```
La URL pública
Qué variables hace falta definir y para qué sirve cada una
El catálogo de errores que encontraste, con su solución
La lista de verificación adaptada a tu proyecto
```

**5. `README.md` presentable** — es lo que va a leer alguien que llegue a tu
repositorio. Qué hace, capturas, cómo ejecutarlo, decisiones técnicas.

---

### 📋 Requisitos técnicos

```
✅ URL pública que carga y funciona
✅ Registro, login y una operación completa funcionando en producción
✅ Migraciones aplicadas por el script de build
✅ Base separada para Preview
✅ .env.example versionado y completo
✅ .env.local fuera de Git, verificado
✅ Ningún secreto en el bundle del navegador
✅ Un PR con su despliegue de preview revisado
✅ README con capturas
❌ Sin claves secretas con NEXT_PUBLIC_
❌ Sin errores crudos mostrados al usuario
❌ Sin ramas de preview escribiendo en producción
```

---

### 💡 Las dos únicas pistas

**Pista 1** — Si el build falla y no encuentras la causa, reproduce en local
con `rm -rf node_modules .next && npm ci && npm run build`. Depurar en tu
máquina es mucho más rápido que esperar cada despliegue.

**Pista 2** — Con `output` personalizado en el generador de Prisma, revisa
**todos** los imports del cliente. Uno solo apuntando a `@prisma/client` tumba
el build, y en local puede funcionar por restos de instalaciones anteriores.

---

### ✅ Criterios de aprobación

```
□ La URL pública funciona desde otro dispositivo, con otra red
□ Alguien que no eres tú puede registrarse y usarla
□ Las migraciones se aplican solas en cada despliegue
□ Un PR genera preview y NO toca la base de producción
□ Ningún secreto aparece en el bundle
□ DESPLIEGUE.md permite a otra persona desplegarlo desde cero
□ El README se entiende sin conocer el proyecto
```

**Verificación final — el desconocido:**

Pásale la URL a alguien que no sepa nada del proyecto. Sin explicarle nada.

```
· ¿Entiende qué es?
· ¿Consigue registrarse y hacer algo?
· ¿Se rompió en algún sitio?
```

Documenta lo que observes. **Es la primera vez que alguien ajeno usa algo que
escribiste**, y esa información no la da ningún test.

---

## 🔜 LO QUE VIENE

Con esta semana el roadmap generado se cierra. Lo que queda son candidatos sin
fecha:

```
E2E con Playwright        cubre lo que Vitest no puede: Server Components
                          asíncronos y flujos completos. Ahora tiene sentido,
                          porque hay algo desplegado que recorrer

Zustand                   sigue esperando a que el dolor del contexto
                          duela de verdad

Optimización              imágenes, caché, Core Web Vitals. Con la
                          aplicación desplegada, ahora son medibles

XML, firma electrónica    la cuña tributaria, si algún día se valida
```

---

> ### 📘 PRÓXIMA SEMANA
> Sin definir. El roadmap generado termina aquí.
>
> Y hay algo que hacer antes de seguir generando: **tienes una aplicación
> desplegada**. La Enmienda 19 dice que los proyectos de portafolio empiezan
> en la Semana 12 — ya vas siete semanas tarde para tener uno propio.
>
> Puede que lo siguiente no sea otra semana de bootcamp.

---

*Semana 19 — Despliegue en Vercel*
*Formato v4 — Constitución v2.2 · Protocolo QA con Fases 6b y 6c*
*Óscar — Full Stack Developer en formación 🇨🇱*
