# 🔬 REPORTE QA — BOOTCAMP SEMANA 19

> Documento interno de auditoría. Contiene el PRODUCTO de cada fase, no su
> declaración (Enmienda 6).

---

```
ACTA DE GENERACIÓN
Fecha: 2026-08-06
Semana en curso de Óscar al generar: 06 (Día 2)
Distancia estimada hasta el uso: ~13 meses
Fases ejecutadas: 0, 1, 2, 3, 4, 5, 6, 6b, 6c, 7, 8
Fase 1 — fuentes consultadas 2026-08-06:
   · vercel.com/kb/guide/nextjs-prisma-postgres (OFICIAL, mayo 2026)
   · prisma.io/docs — Deploy to Vercel (OFICIAL)
   · prisma.io/docs/guides/frameworks/nextjs (OFICIAL)
   · dev.to/whoffagents — production checklist (abril 2026)
   · tczhong.com — Prisma on Vercel: deploy learning notes (feb 2026)
   · tekraze.com — Deploy Next.js to Vercel (3 semanas)
   · eastondev.com — env vars, domains, monitoring (jul 2026)
Referencia: Vercel · Next.js 16 · Prisma 7
Bloque perecedero: ALTO RIESGO
Constitución aplicada: v2.2 (enmiendas 1-19)
```

---

## FASE 0 — DELIMITACIÓN

### Por qué despliegue y por qué ahora

```
1. La Enmienda 19 fijó los proyectos de portafolio desde la Semana 12.
   Un portafolio sin URL pública NO es portafolio: nadie clona un
   repositorio para comprobar si funciona.

2. El dolor lleva ocho semanas acumulándose. Desde la Semana 12 todo
   corre en localhost. La 14 metió base de datos, la 16 secretos, la 17
   formularios. Nada ha salido de la máquina.

3. Es prerrequisito de lo que queda. E2E con Playwright tiene sentido
   sobre algo desplegado. La optimización solo es medible en producción.

4. Cierra el roadmap generado con la capacidad que la meta requiere:
   la Enmienda 11 dice "primer ingreso por desarrollo de software", y
   eso empieza por tener algo que enseñar.
```

### La decisión de diseño central

```
RECHAZADO: "conecta el repo y pulsa Deploy"
   Eso son cinco minutos y no da para semana.

ADOPTADO: la semana trata de POR QUÉ ALGO FUNCIONA EN TU MÁQUINA Y NO
   EN PRODUCCIÓN.

Justificación: la Fase 1 encontró un caso documentado de despliegues
fallando repetidamente cuya conclusión es exactamente esa tesis —
los problemas no venían de un ajuste de Vercel, sino de pequeñas
inconsistencias entre generación, imports y supuestos de CI.

Esa es una lección de ingeniería, no de plataforma. Sobrevive aunque
Vercel cambie.
```

### Dentro del alcance

```
- Qué tiene tu máquina que el servidor no
- Los tres entornos y sus variables independientes
- NEXT_PUBLIC_ y la filtración de secretos
- .env.example como documentación versionada
- Base de datos en producción: DATABASE_URL vs DIRECT_URL
- El pool de conexiones en serverless
- migrate deploy en el script de build
- Base separada para Preview
- Las cinco causas de que el build falle solo en Vercel
- Leer un log de build
- Reproducir el build de Vercel en local con npm ci
- Logs de runtime, preview deployments, rollback
- Dominios y su efecto sobre las URLs de callback
```

### Fuera del alcance

| Excluido | Razón |
|---|---|
| GitHub Actions / CI propio | Vercel ya despliega en cada push. Añadir CI sin necesidad es complejidad sin problema |
| Docker y autoalojado | Otra semana. Vercel es el objetivo declarado del stack |
| Edge runtime | Matiz de rendimiento sin problema medido |
| Analítica y monitorización | Producto aparte, de pago |
| Escalado y límites de plan | Sin tráfico real, es teoría |
| Estrategias de rollback | Se enseña el botón, no la estrategia |
| Optimización (imágenes, Core Web Vitals) | Merece semana propia, y solo es medible tras desplegar |

### Prerrequisitos

```
Semana 07 → ramas y PRs (los preview deployments los usan)   ✔ verificado
Semana 09 → tsc --noEmit; el Día 7 explica por qué el editor
              avisa pero no impide                            ✔ verificado
Semana 12 → Next.js                                           ✔ verificado
Semana 14 → Prisma, migraciones, el singleton                 ✔ verificado
              ⚠ dependencia FUERTE
Semana 16 → Clerk y sus variables secretas                    ✔ verificado
Semana 18 → tests que ejecutar antes de desplegar             ✔ verificado
```

---

## FASE 1 — INVESTIGACIÓN

| Afirmación | Fuente | Impacto |
|---|---|---|
| **Vercel no aloja bases de datos**; hace falta proveedor externo | dev.to, eastondev | Día 3 completo |
| Prisma Postgres está en el Marketplace de Vercel; añade `DATABASE_URL` automáticamente si se conecta desde Storage | vercel.com KB (oficial) | Opción recomendada |
| **Neon entrega dos URLs**: `DATABASE_URL` con pool y `DIRECT_URL` para migraciones | dev.to | Sección propia en el Día 3 |
| `directUrl` va en el bloque `datasource` del schema | dev.to | Ejemplo literal |
| **Vercel usa la misma `DATABASE_URL` para Preview y Production** si no se separa | prisma.io (oficial) | ⚠ Las ramas escriben en producción. Ejercicio 3 del Día 3 |
| En serverless, **cada invocación puede abrir una conexión nueva**; el pool es esencial | prisma.io (oficial) | Conecta con el singleton de la S14 |
| **Las migraciones NO se aplican solas.** `prisma migrate deploy` en el build | tekraze, dev.to | Día 3, causa de "la tabla no existe" |
| Script: `"vercel-build": "prisma generate && prisma migrate deploy && next build"` | dev.to | Literal |
| Alternativa: `postinstall: prisma generate` | prisma.io (oficial) | Ejercicio 4 del Día 4 lo pone a juzgar |
| **`output` personalizado + import de `@prisma/client` = build roto.** Error: *"@prisma/client did not initialize yet"* | tczhong (feb 2026) | **Causa nº2 del Día 4** |
| La conclusión: los fallos vienen de inconsistencias entre ruta de generación, imports y supuestos de CI — no de un ajuste de Vercel | tczhong | **TESIS DE LA SEMANA** |
| Vercel cachea dependencias entre despliegues | prisma.io (oficial) | Explica por qué el cliente puede quedar viejo |
| `vercel env pull` trae las variables a `.env.local` | vercel.com KB | Día 2 |
| Las URLs de callback deben coincidir con el dominio de producción | vercel.com KB | ⚠ Rompe el login solo en producción |
| Preview deployments por rama y por PR | github docs | Conecta con la Semana 7 |
| Vercel da `.vercel.app` gratis; dominio propio en Settings → Domains | dev.to, tekraze | Día 5 |
| Las variables se configuran por entorno (Development/Preview/Production) | github docs | Día 2 |

### El hallazgo que afecta al material anterior

```
⚠ IMPORTANTE PARA LA SEMANA 14

La causa nº2 del Día 4 —output personalizado con imports desalineados—
afecta DIRECTAMENTE a la configuración que enseña la Semana 14:

  generator client {
    provider = "prisma-client"
    output   = "../src/generated/prisma"   ← obligatorio en Prisma 7
  }

Esa configuración es CORRECTA. Pero es exactamente la que produce el
fallo si algún import quedó apuntando a @prisma/client.

La Semana 14 enseña el import correcto (@/generated/prisma/client), así
que el material es coherente. Pero un import olvidado en cualquier
archivo tumba el despliegue.

ACCIÓN: la Pista 2 del proyecto del Día 6 lo señala explícitamente.
No hace falta parchear la Semana 14.
```

### Hueco declarado de la Fase 1

```
NO se verificaron los límites del plan gratuito de Vercel ni los de los
proveedores de base de datos. El material no afirma ninguno.

Comprobar antes de usar: si el plan gratuito cubre el uso del proyecto.
```

---

## FASE 4 — REVISIÓN TÉCNICA

```
✔ Vercel reconstruye desde el repositorio, no copia la carpeta
✔ Las variables son independientes por entorno
✔ NEXT_PUBLIC_ mete la variable en el bundle del navegador
✔ Un secreto expuesto hay que ROTARLO, no basta con quitar el prefijo
✔ DATABASE_URL con pool; DIRECT_URL sin pool para migraciones
✔ migrate deploy no crea migraciones ni pide confirmación
✔ migrate dev puede pedir confirmación → inservible en CI
✔ npm ci instala desde el lock file, borrando node_modules antes
✔ next build ejecuta comprobación de tipos
✔ Los preview deployments comparten base con producción si no se separa
✔ Vercel cachea node_modules entre despliegues
```

### Corrección aplicada

```
Formulación incorrecta (borrador):
  "Conecta tu repositorio y Vercel se encarga del resto"

Por qué era incorrecta:
  Cierta para una aplicación estática. Falsa para una con base de datos,
  migraciones, autenticación y secretos — que es la de Óscar.

  Y produce el peor resultado posible: el alumno despliega, falla, y no
  tiene modelo mental para diagnosticar. Concluye que "Vercel es raro".

Formulación corregida:
  El Día 1 declara que el primer despliegue VA A FALLAR y que eso es el
  material del Día 4. El fallo pasa de sorpresa a contenido previsto.
```

---

## FASE 6 — CONSISTENCIA INTERNA

```
✔ El Día 1 anuncia que el despliegue fallará; el Día 4 lo recoge
✔ El Día 2 (variables) precede al Día 3 (base) — la base necesita variables
✔ El Día 4 reúne los fallos de los Días 1-3 en un catálogo diagnóstico
✔ El Día 5 cierra con la lista de verificación que resume los cuatro
✔ La tabla de diagnóstico de la Cheat Sheet §9 reúne toda la semana
```

### Anclaje en trabajo previo

```
· Día 1 → el flujo de ramas de la Semana 7 cobra consecuencia visible:
          cada PR genera una URL desplegada
· Día 3 → el pool en serverless es el singleton de la Semana 14 a
          escala real
· Día 3 → migrate deploy usa las migraciones versionadas de la S14
· Día 4 → "el editor avisa, no impide" es el Día 7 de la Semana 9
· Día 4 → la causa nº2 afecta a la configuración de la Semana 14
· Día 5 → no devolver errores crudos es la regla del P2003 de la S14,
          ahora con consecuencia pública
· Día 5 → las URLs de callback son de la Semana 16
· Día 6 → la lista de verificación incluye npm test, de la Semana 18
```

### Ejercicios huérfanos

| Ejercicio | Destino |
|---|---|
| D1 — inventario | Proyecto D6 (DESPLIEGUE.md) |
| D1 — desplegar | Proyecto D6 |
| D1 — clon limpio | Ninguno. **Justificado:** demostración |
| D2 — todas las variables | Proyecto D6, requisito |
| D2 — .env.example | Proyecto D6, requisito |
| D2 — auditoría del bundle | Proyecto D6, criterio de aprobación |
| D2 — romper Preview | Ninguno. **Justificado:** experiencia del fallo |
| D3 — base en producción | Proyecto D6, requisito |
| D3 — script de build | Proyecto D6, requisito |
| D3 — base separada | Proyecto D6, requisito |
| D3 — decidir la semilla | Ninguno. **Justificado:** criterio |
| D4 — reproducción local | Proyecto D6 (pista 1) |
| D4 — provocar tres fallos | Proyecto D6 (catálogo de errores) |
| D4 — diagnóstico a ciegas | Ninguno. **Justificado:** verificación (E14) |
| D4 — juzgar el script | Ninguno. **Justificado:** verificación (E14) |
| D5 — encontrar en logs | Proyecto D6 |
| D5 — flujo con preview | Proyecto D6, requisito |
| D5 — vuelta atrás | Ninguno. **Justificado:** operación |
| D5 — lista en el README | Proyecto D6, requisito |

**Cero huérfanos sin justificar.**

---

## FASE 6b — CONFORMIDAD

```
Indentación impar:        0
Ocurrencias de == o !=:   0
```

```
□✔ Nombres en español en prosa y documentación
     ⚠ Excepción: comandos, variables de entorno y claves de
       package.json son identificadores externos

□✔ Enmienda 14 — verificación
     D1 Ej.3 (clon limpio), D2 Ej.3 (auditar bundle), D2 Ej.4 (romper),
     D4 Ej.3 (diagnóstico a ciegas), D4 Ej.4 (juzgar script)
     Cinco ejercicios de juicio. El Día 4 entero es lectura de logs

□✔ Enmienda 17 — Cheat Sheet como guion

□✔ Enmienda 19 — el proyecto ES el portafolio. Coherente con la
     enmienda que motivó la semana
```

---

## FASE 6c — COBERTURA TÉCNICA

| Técnica | Cheat Sheet | Bootcamp | Estado |
|---|---|---|---|
| `vercel env pull` | §3, §8 | D2 | ✅ |
| `prisma migrate deploy` | §4, §8 | D3 | ✅ |
| `directUrl` | §4, §8 | D3 | ✅ |
| `vercel-build` | §4 | D3 | ✅ |
| `.env.example` | §3 | D2 | ✅ |
| `NEXT_PUBLIC_` | §3 | D2 | ✅ |
| `postinstall` | §5 | D4 Ej.4 | ✅ |
| Entornos y su separación | §2 | D2 | ✅ |
| **`npm ci`** | **§5b** | D4 | ✅ **corregido** |

### Hueco detectado y corregido

```
npm ci estaba en el cuerpo del Día 4 y en la Pista 1 del proyecto, pero
NO en el Cheat Sheet.

No era hueco estricto —se enseña antes de exigirse— pero el Cheat Sheet
es material de CONSULTA POSTERIOR (Enmienda 17) y una técnica que el
proyecto recomienda debería poder buscarse ahí.

CORRECCIÓN: sección 5b nueva, "Reproducir el build de Vercel en local",
con la diferencia npm install / npm ci y su trampa (falla si el lock
file está desincronizado).
```

---

## FASE 7 — AUDITORÍA ADVERSARIAL

### Formulaciones RECHAZADAS

```
RECHAZADA 1: "Conecta el repositorio y Vercel se encarga del resto"

Razón: ver Fase 4.

Reemplazo: el Día 1 predice el fallo y lo convierte en contenido.
```

```
RECHAZADA 2: "Copia tus variables de .env.local al panel de Vercel"

Razón: omite los tres entornos. El alumno las pone en Production, abre
un PR, el preview falla, y no entiende por qué si "ya están puestas".

Reemplazo: los tres entornos se enseñan ANTES de definir ninguna
variable, y el Ejercicio 4 del Día 2 obliga a provocar ese fallo exacto.
```

```
RECHAZADA 3: "Usa Vercel Postgres, es lo más fácil"

Razón: recomendación de producto sin criterio. Y el ecosistema de
proveedores cambia rápido — atarse a uno envejece mal.

Reemplazo: se enseña QUÉ necesita la aplicación (dos URLs, pool,
migraciones) y se mencionan varios proveedores sin elegir. El criterio
sobrevive al cambio de producto.
```

```
RECHAZADA 4: "Si el build falla, revisa la configuración de Vercel"

Razón: dirige la atención al sitio equivocado. La Fase 1 encontró un
caso documentado donde el problema NO estaba en Vercel sino en
inconsistencias del propio proyecto.

Reemplazo: las cinco causas ordenadas por frecuencia, ninguna de las
cuales es "un ajuste de Vercel". Más el método de reproducir en local.
```

```
RECHAZADA 5: "Quita el prefijo NEXT_PUBLIC_ y ya está seguro"

Razón: FALSO y peligroso. Si el secreto llegó al bundle, ya se
descargó. Está comprometido para siempre.

Reemplazo: se declara explícitamente que hay que ROTAR la clave, y el
mini-ejercicio del Día 2 pide precisamente eso.
```

### Ataques sin hallazgo

```
✔ ¿El material depende de que Vercel no cambie? La tesis (inconsistencias
  entre entornos) es de ingeniería, no de plataforma
✔ ¿Algún día da la solución antes del dolor? El D1 hace desplegar y fallar
✔ ¿El proyecto es verificable? Sí, y por alguien ajeno: la URL funciona
  desde otro dispositivo y otra red
✔ ¿Hay secciones "cuándo NO"? En la elección de proveedor y en la decisión
  sobre la semilla en producción
```

---

## ENMIENDA 10 — SINTAXIS NUEVA POR PESO

| Sintaxis | Peso | Entrega |
|---|---|---|
| `vercel env pull` | **LIGERA** | §3, §8 + trampa (entorno por defecto) |
| `prisma migrate deploy` | **LIGERA** | §4, §8 + trampa (migración a medias) |
| `directUrl` | **LIGERA** | §4, §8 + trampa (mensaje que no lo menciona) |
| `npm ci` | **LIGERA** | §5b + trampa (lock file) |

```
✔ Ninguna MEDIA ni PESADA. La semana es conceptual y de diagnóstico,
  no de sintaxis nueva — coherente con su naturaleza
✔ Ninguna en el Día 1
```

---

## HALLAZGOS ABIERTOS

### 1. Límites del plan gratuito sin verificar

Declarado en Fase 1. Ni los de Vercel ni los de los proveedores de base.

### 2. El ecosistema de proveedores es volátil

Prisma Postgres, Neon y Supabase pueden cambiar de condiciones o
desaparecer del Marketplace. **El material no se ata a ninguno** — enseña qué
necesita la aplicación. Ese enfoque envejece mejor.

### 3. La causa nº2 afecta a la Semana 14

El `output` personalizado de Prisma 7 es la configuración correcta y la que
produce el fallo si algún import quedó desalineado.

**No requiere parche** — la Semana 14 enseña el import correcto. Pero la
Pista 2 del proyecto lo señala.

### 4. El roadmap generado termina aquí

Diecinueve semanas y cuatro proyectos integradores. El pie de esta semana
plantea algo que conviene discutir: **la Enmienda 19 fijó los proyectos de
portafolio desde la Semana 12, y no hay ninguno.**

Puede que lo siguiente no sea otra semana de bootcamp.

---

## ADVERTENCIA SOBRE LA VIGENCIA

```
CRÍTICO → comandos de la CLI de Vercel y estructura del panel
CRÍTICO → planes gratuitos de Vercel y proveedores de base
ALTO    → nombres de variables que Vercel inyecta automáticamente
ALTO    → el Marketplace y qué proveedores ofrece
MEDIO   → la sintaxis de directUrl en el datasource
BAJO    → los tres entornos como concepto
BAJO    → NEXT_PUBLIC_ y la exposición de secretos
BAJO    → por qué las migraciones no se aplican solas
BAJO    → la tesis: los fallos vienen de inconsistencias entre entornos
```

**Nota de precedencia:** si la documentación de Vercel o Prisma contradice
este material, gana la documentación.

---

*Reporte QA Semana 19 — 2026-08-06*
*Constitución v2.2 · Fases 0-8 incluyendo 6b y 6c*
*Cierra el roadmap generado*
