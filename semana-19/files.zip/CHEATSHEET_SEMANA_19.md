# 📄 CHEAT SHEET — SEMANA 19
## Despliegue · Vercel · Producción

> Guion de la clase de activación. Se entrega POR PARTES, día a día.

---

## ⏱ BLOQUE PERECEDERO — verificar antes de usar

```
Generado y verificado: agosto 2026
Referencia: Vercel · Next.js 16 · Prisma 7
REGENERAR antes de empezar la semana.
```

```bash
npm i -g vercel
vercel login
vercel link          # conecta la carpeta con un proyecto de Vercel
vercel env pull      # trae las variables de producción a .env.local
```

⚠ El despliegue habitual **no usa la CLI**: se conecta el repositorio de
GitHub y Vercel despliega en cada push. La CLI sirve para traer variables y
para desplegar a mano cuando hace falta.

**Qué verificar al llegar:** los comandos de la CLI, el plan gratuito de
Vercel y sus límites, y si Prisma Postgres sigue en el Marketplace.

---

## 1. LA IDEA CENTRAL

> **"Funciona en mi máquina" no significa nada.**

Tu máquina tiene:

```
· Node en TU versión
· Variables en un .env que nadie más tiene
· Una base de datos a la que solo tú llegas
· node_modules con dependencias de desarrollo instaladas
· Archivos que quizá no subiste a Git
```

El servidor de Vercel tiene **el repositorio y nada más**. Si algo funciona
en local y falla desplegado, la diferencia está en esa lista.

**Idea mental:** desplegar no es copiar tu carpeta a internet. Es
**reconstruir tu proyecto desde cero** en una máquina que no sabe nada de ti.

---

## 2. LOS TRES ENTORNOS

Vercel maneja tres, y confundirlos es la causa número uno de fallos:

```
DEVELOPMENT   tu máquina, con .env.local
PREVIEW       cada rama y cada Pull Request → URL propia
PRODUCTION    la rama principal → tu dominio
```

**Cada uno tiene sus propias variables de entorno.** Una variable definida
solo en Production no existe en Preview, y el despliegue de tu PR falla
mientras el de `main` funciona.

> ⚠ **Trampa documentada:** Vercel usa la misma `DATABASE_URL` para Preview y
> Production si no la separas. Eso significa que **tus ramas de prueba
> escriben en la base de producción**.
>
> Solución: una segunda base para Preview, con su propia variable marcada
> solo para ese entorno.

---

## 3. VARIABLES DE ENTORNO

```
NEXT_PUBLIC_*     visible en el navegador. Cualquiera puede leerla
sin prefijo       solo en el servidor
```

⚠ **La regla que no se negocia:** una clave secreta **nunca** lleva
`NEXT_PUBLIC_`. Ese prefijo la mete en el bundle que se descarga el usuario.

```
✅ NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY   diseñada para ser pública
❌ NEXT_PUBLIC_CLERK_SECRET_KEY        filtración
❌ NEXT_PUBLIC_DATABASE_URL            filtración grave
```

### Traerlas a local

```bash
vercel env pull
```

Escribe un `.env.local` con las variables del entorno seleccionado. Útil para
reproducir un problema de producción en tu máquina.

⚠ Ese archivo **nunca** se sube a Git.

### `.env.example`

Un archivo **sí versionado** con los nombres pero sin los valores:

```
DATABASE_URL=
DIRECT_URL=
CLERK_SECRET_KEY=
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=
```

Sirve para saber qué hace falta sin filtrar nada. Es lo primero que mira
alguien que clona tu repositorio.

---

## 4. LA BASE DE DATOS EN PRODUCCIÓN

**Vercel no aloja bases de datos.** Necesitas un proveedor: Prisma Postgres
desde el Marketplace, Neon, Supabase u otro.

### Las dos URLs

Varios proveedores entregan **dos** cadenas de conexión, y confundirlas rompe
el despliegue:

```prisma
datasource db {
  provider  = "postgresql"
  url       = env("DATABASE_URL")   // con pool → para la aplicación
  directUrl = env("DIRECT_URL")     // sin pool → para migraciones
}
```

```
DATABASE_URL   pasa por un pool. La usan las funciones serverless
DIRECT_URL     conexión directa. La usan las migraciones
```

**Por qué hacen falta las dos:** las migraciones necesitan una conexión
estable y exclusiva; un pool no sirve. La aplicación necesita lo contrario.

### El problema del pool en serverless

> Cada invocación de una función serverless **puede abrir una conexión
> nueva**. Con tráfico, la base se queda sin conexiones disponibles y la
> aplicación se cuelga.

Es el mismo problema del singleton de la Semana 14, ahora a escala real. El
singleton ayuda dentro de una instancia; el pool del proveedor resuelve el
resto.

### Las migraciones no se aplican solas

```json
{
  "scripts": {
    "vercel-build": "prisma generate && prisma migrate deploy && next build"
  }
}
```

```
prisma generate        crea el cliente. SIEMPRE necesario en CI
prisma migrate deploy  aplica migraciones pendientes. NO crea nuevas
next build             compila la aplicación
```

⚠ **`migrate deploy`, no `migrate dev`.** El segundo puede crear migraciones
y pedir confirmación. En un servidor de build no hay nadie para responder.

---

## 5. POR QUÉ FALLA EL BUILD EN VERCEL Y NO EN LOCAL

Cinco causas, ordenadas por frecuencia.

### 1. El cliente de Prisma no se generó

```
Error: @prisma/client did not initialize yet. Please run "prisma generate"
```

Vercel cachea `node_modules`. Si el cliente vive ahí y no se regenera, se usa
uno viejo o ninguno.

**Solución:** `prisma generate` en el build, o un script `postinstall`.

### 2. La ruta del cliente generado no coincide con los imports

Este es sutil y está documentado como causa de despliegues que fallan una y
otra vez:

```prisma
generator client {
  output = "../src/generated/prisma"
}
```

```typescript
// ❌ importa de donde ya NO está
import { PrismaClient } from "@prisma/client";

// ✅ importa de donde se generó
import { PrismaClient } from "@/generated/prisma/client";
```

En local puede funcionar por restos de instalaciones anteriores. En un
entorno limpio, no.

> **La lección, y es la de toda la semana:** los fallos de despliegue no
> vienen de un ajuste mágico de Vercel. Vienen de **pequeñas
> inconsistencias** entre dónde se genera el código, desde dónde se importa,
> y qué supone el entorno de CI.

### 3. Faltan variables de entorno

El build pasa y la aplicación revienta al cargar. Casi siempre es una
variable mal escrita o definida solo en un entorno.

### 4. Errores de TypeScript que en local ignorabas

`next build` ejecuta la comprobación de tipos. Si desarrollabas ignorando el
subrayado rojo, aquí se detiene.

Es el Día 7 de la Semana 9: el editor avisa, no impide. `npx tsc --noEmit`
antes de desplegar te lo dice primero.

### 5. Dependencias en el sitio equivocado

Algo que usa el build declarado en `devDependencies` y una instalación de
producción que las omite.

---

## 5b. REPRODUCIR EL BUILD DE VERCEL EN LOCAL

El truco que ahorra despliegues fallidos:

```bash
rm -rf node_modules .next
npm ci
npm run build
```

```
npm install   respeta el package.json, puede resolver versiones distintas
npm ci        instala EXACTAMENTE lo del package-lock.json, desde cero
```

`npm ci` es lo que usa la mayoría de entornos de CI, Vercel incluido. Borra
`node_modules` antes de instalar, así que no arrastra restos.

**Si falla aquí, fallará allá.** Y depurar en tu máquina es mucho más rápido
que esperar un despliegue de dos minutos por cada intento.

> ⚠ **Trampa:** `npm ci` falla si `package-lock.json` no existe o está
> desincronizado con `package.json`. Eso no es un fallo del comando: es que
> tu lock file está mal, y Vercel te lo diría igual.

---

## 6. DESPUÉS DEL DESPLIEGUE

### Los logs

```
Deployment → Functions   errores en tiempo de ejecución
Deployment → Building    el log del build
```

Un error 500 en producción no muestra detalles al usuario — están en los logs.

⚠ Nunca devuelvas el mensaje de error crudo al usuario. Puede contener
estructura de tu base de datos. Es la regla de la Semana 14 con `P2003`.

### Los despliegues de preview

Cada Pull Request genera una URL propia. Sirve para revisar cambios sin
tocar producción, y es lo que hace que el flujo de la Semana 7 rinda de
verdad.

### Dominios

Vercel da `tu-proyecto.vercel.app` gratis. Para uno propio: Settings →
Domains, y ajustar el DNS.

⚠ Si usas Clerk, **la URL de callback tiene que coincidir con el dominio de
producción**. Cambiar de dominio y olvidar esto rompe el login solo en
producción.

---

## 7. LA LISTA DE VERIFICACIÓN

Antes de cada despliegue:

```
□ npm run build pasa en local
□ npx tsc --noEmit sin errores
□ npm test en verde
□ .env.local NO está en Git
□ .env.example actualizado
□ Todas las variables definidas en Vercel, en los tres entornos
□ Ninguna clave secreta con prefijo NEXT_PUBLIC_
□ El script de build incluye prisma generate y migrate deploy
□ Los imports del cliente de Prisma apuntan al output configurado
□ Las URLs de callback de Clerk coinciden con el dominio
```

---

## 8. SINTAXIS NUEVA DE ESTA SEMANA

### `vercel env pull` · peso LIGERO

Descarga las variables del proyecto a `.env.local`.

> ⚠ **Trampa:** descarga las del entorno seleccionado, por defecto
> Development. Para las de producción hay que pedirlas explícitamente.

### `prisma migrate deploy` · peso LIGERO

Aplica migraciones pendientes sin crear ninguna ni preguntar nada.

> ⚠ **Trampa:** si una migración falla a medias, la base queda en un estado
> intermedio y los siguientes despliegues fallan hasta resolverlo a mano.

### `directUrl` en el datasource · peso LIGERO

Segunda conexión, sin pool, para las migraciones.

> ⚠ **Trampa:** si defines `directUrl` y no defines la variable en Vercel, el
> build falla con un mensaje que no menciona `directUrl`.

---

## 9. TABLA DE DIAGNÓSTICO

| Síntoma | Causa probable |
|---|---|
| `@prisma/client did not initialize` | Falta `prisma generate` en el build |
| Build verde, la web revienta al cargar | Variable de entorno ausente o mal escrita |
| Funciona en Preview, falla en Production | Variable definida solo en un entorno |
| Error de tipos solo en Vercel | Ignorabas errores del editor en local |
| Tabla inexistente en producción | Falta `migrate deploy` en el build |
| Se agotan las conexiones a la base | Falta pool, o falta el singleton |
| El login falla solo en producción | URL de callback distinta del dominio |
| Import falla solo en Vercel | Ruta del cliente generado ≠ ruta importada |

---

## 10. FUERA DE ALCANCE

```
CI/CD con GitHub Actions      Vercel ya despliega en cada push
Docker y autoalojado          otra semana
Edge Functions y runtime edge  matiz de rendimiento
Analítica y monitorización     producto aparte
Escalado y límites de plan     sin el problema real, es teoría
Rollbacks avanzados            se menciona el botón, no la estrategia
```

---

*Cheat Sheet Semana 19 — Despliegue en Vercel*
*Prerrequisitos: Semana 07 (Git y PRs) · 09 (tsc --noEmit) · 12 (Next.js) · 14 (Prisma) · 16 (Clerk) · 18 (tests)*
